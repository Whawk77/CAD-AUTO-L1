using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CadAuto.Core.Geometry;
using CadAuto.Core.Model;
using CadAuto.Core.Planning;
using CadAuto.Core.Recognition;
using CadAuto.Core.Rules;

namespace CadAuto.Core.Tests
{
    internal static partial class Program
    {
        private static int _passedTests;
        private static int _selectedTests;
        private static readonly List<Tuple<string, string>> FailedTests = new List<Tuple<string, string>>();
        private static readonly List<Tuple<string, Action>> RegisteredTests = new List<Tuple<string, Action>>();
        private static readonly HashSet<string> P0Tests = new HashSet<string>
        {
            nameof(RectangularOutlineKeepsOverallDimensions),
            nameof(ChamferedEnvelopeDropsSplitStructureFragments),
            nameof(OverallDimensionsUseBoundaryGripPoints),
            nameof(ConcaveHoleDatumUsesRealOutlineIntersections),
            nameof(DuplicateSegmentsAreSuppressedWithDiagnostic),
            nameof(ZeroAndMicroSegmentsDoNotEmitDimensions),
            nameof(GeometryToleranceControlsMicroSegments),
            nameof(InvalidDatumCoordinateIsSkippedWithDiagnostic),
            nameof(InvalidSlotDatumIsSkippedWithDiagnostic),
            nameof(OverallWinsDuplicatePreferenceEvenAgainstTolerance),
            nameof(LocalGeometryOnOverallEnvelopeSuppressesOnlyEligibleRoles)
        };
        private static readonly HashSet<string> P1Tests = new HashSet<string>
        {
            nameof(Production73x20EnvelopeDimensionsAreSuppressed),
            nameof(MirroredEnvelopeStructureWidthsAreBothSuppressed),
            nameof(StructureWidthsThatPartitionOverallAreSuppressed),
            nameof(ProjectedCrossLevelStructureWidthsDoNotPartitionOverall),
            nameof(GeometricMirrorOwnershipPrefersContourBackedCandidate),
			nameof(SameSideClosedChainSuppressesCrossLevelProjection),
			nameof(ProjectedThreePieceHorizontalChainKeepsRealSteps),
			nameof(TopClosedChainDropsUnbackedBodyRemainder),
			nameof(TopClosedChainKeepsRealStepsDropsUnbackedBody),
			nameof(TopClosedChainWithoutDatumDropsOppositeBody),
			nameof(BottomClosedChainWithoutDatumDropsOppositeBody),
			nameof(RightClosedChainWithoutDatumDropsOppositeBody),
			nameof(MultiPieceStructureOverallRemainderDropsLongBody),
			nameof(BottomMultiLevelStepsKeepFeatureChainDropBodyRemainder),
			nameof(BottomCrossLevelLedgeSnapWhenOutlineSegmentResolvesTop),
			nameof(LeftMultiPieceStepsSurviveOrphanTipOnTallOverall),
			nameof(BottomClosedChainFlippedKeepsShorterEnd75Drops90),
			nameof(TopCrossAxisStructWidth8IsRejected),
			nameof(RightSplitHeights56And72AreOrphanTipsOn215),
			nameof(TopDisconnectedSecondary87WithMajor120IsSuppressed),
			nameof(RightResidual72WithLeftMajor120IsSuppressed),
			nameof(Rotated215Notch50And75SurviveOnLeftAndRight),
			nameof(ProjectedThreePieceVerticalChainKeepsRealHeights),
			nameof(OrthogonalRotatedVerticalChainKeepsRealWidths),
			nameof(FullWidthSideSeamsDoNotCreateStructureHeights),
			nameof(MirroredProjectedChainNormalizesStructureSelection),
			nameof(Test2BottomContourChainKeepsTwoRealWidths),
			nameof(RotatedTest2PreservesLocalSemanticSignature),
			nameof(RotationSignature_OuterStepOverallStructureIsStable),
			nameof(RotationSignature_ClosedChainStructureIsStable),
			nameof(RotationSignature_F215GoldenMultisetFourWayEqual),
			nameof(RotationSignature_F215CadGoldenMultisetFourWayEqual),
			nameof(F215CadRotatedKeeps42Drops32Stub),
			nameof(RotationSignature_F338GoldenMultisetFourWayEqual),
			nameof(RotationSignature_F338CadGoldenMultisetFourWayEqual),
			nameof(CadLastRunGrooveSnapsToWallClearWidthFourWay),
			nameof(RotationSignature_Stair3GoldenMultisetFourWayEqual),
			nameof(RotationSignature_LBoss257GoldenMultisetFourWayEqual),
			nameof(SteppedPlateReplacesThinStepRisersWithComplement53),
			nameof(CNotchPlateKeepsTopEnvelopeBodyWidth120),
			nameof(AnnotationCaseOverlayDropsMaxEndResidual),
			nameof(AnnotationCaseStrategyMatchesSquareAndFilletCoveringChains),
			nameof(AnnotationCaseStrategyDoesNotDropLoneResidual),
			nameof(StepGroovePlacesOnSameSideAsOuterStepFourWay),
			nameof(CrossSideStructureWidthsThatCloseOverallChainAreSuppressed),
            nameof(InteriorHorizontalOutlineSegmentPrefersNonCrossingSide),
            nameof(TopEnvelopeHorizontalSegmentStaysTop),
            nameof(BottomEnvelopeHorizontalSegmentStaysBottom),
            nameof(BottomBodyWidthNotDroppedByLongestExtension),
            nameof(BottomOuterContourStepKeeps20AndSuppresses70Body),
            nameof(OutlineSegmentBodyLengthClosedByStepIsSuppressed),
            nameof(DatumRootedLeftOuterEnvelopeDimensionsAreSuppressed),
            nameof(DatumRootedBottomAndLeftOuterEnvelopeDimensionsAreSuppressed),
            nameof(DatumRootedBottomEnvelopeStepAndArcResidualAreSuppressed),
            nameof(StructureWidthThatPartitionsOverallWithOutlineSegmentIsSuppressed),
            nameof(ThreeStructureWidthsThatPartitionOverallAreSuppressed),
            nameof(LocalTopStructureWidthIsKeptWhenNotPartitioningOverall),
            nameof(RightArmHeightOnOverallMaxXIsSuppressed),
            nameof(StructureCoverageEligibilityIgnoresSourceLabels),
            nameof(StructureCoverageProtectsIndependentRequirements),
            nameof(StructureCoverageRequiresLiveProvidersAndEvidence),
            nameof(StructureCoverageTracksMissingProviders),
            nameof(PinDatumFamilyKeepsOneSide),
            nameof(PinDatumSideIsInheritedOnAllFourSides),
            nameof(FirstPinDatumAlignmentRejectsOverlappingIntervals),
            nameof(DatumPinVerticalPreferenceOnlyChangesSelectedGroup),
            nameof(DatumPinVerticalPreferenceDefaultsToAutomatic),
            nameof(DatumPinHorizontalPreferenceOnlyChangesSelectedGroup),
            nameof(DatumPinLayoutOrientationUsesSelectedGroup),
            nameof(HorizontalPreferenceKeepsContinuousDatumChain),
            nameof(CollinearExteriorBranchFragmentsUseTopology),
            nameof(CollinearExteriorBranchFragmentsProtectRequirements),
            nameof(OutlineTopologyNonExteriorEntitiesUseYellowArrows),
            nameof(ObliqueBoundaryInformationMatchesUserScheme),
            nameof(ObliqueBoundaryInformationProtectsEqualProjections),
            nameof(ObliqueBoundaryInformationFallsBackAndAuditsMissingProviders),
            nameof(SeparatePinGroupsKeepIndependentSides),
            nameof(OuterBoundaryOwnershipRejectsInternalTopFrame),
            nameof(ChamferComplementRequiresBoundaryWalk),
            nameof(BoundarySelectionCannotRestoreInternalEdges),
            nameof(UnverifiedAttachmentRemainsUnknown),
            nameof(LProfileChamferedArmResidualUsesBoundarySequence),
            nameof(LProfileChamferedArmResidualRequiresChamferDefinition),
            nameof(LProfileAnnotationRulesUseTopology),
            nameof(LProfileFarEndCornerUsesAdjacentVerticalChain),
            nameof(LProfileOuterContourAnnotationRulesUseTopology),
            nameof(LProfileTopologyRejectionIsDiagnostic),
            nameof(RoundedRectangleOuterContourIsNotLProfile),
            nameof(LShapeTowerTopWidthIsKeptDespiteArmTopOutlineSegment),
            nameof(BottomStepWidthOnOverallEnvelopeIsSuppressed),
            nameof(BottomProtrusionSuppressesOuterWidthAndInnerLedge),
            nameof(BottomFilletedProtrusionWidthIsSuppressed),
            nameof(ChamferedTopStepUsesCompositeDimensions),
            nameof(LeftStepStructureHeightsPreferOverRightOutlineSegments),
            nameof(RightStepStructureHeightsPreferOverLeftOutlineSegments),
            nameof(OrphanRightOuterStructureHeightTipsAreSuppressed),
			nameof(PartialEnvelopeStructureHeightSurvivesOrphanTipSuppression),
			nameof(HoleAndPinChainsUseSideFacingCenterlineEndpoints),
			nameof(MultipleSlotGroupsFormContinuousChains),
			nameof(ChamferSideSlotChainUsesChamferSideDatum),
			nameof(LowerChamferSlotChainUsesBottomPlacement),
			nameof(VerticalSlotDatumUsesLayoutFacingChamferPoint),
			nameof(FilletedOuterDatumUsesLayoutFacingFilletEndpoint),
			nameof(FilletedSlotGridKeepsContinuousVerticalChain)
		};
        private static readonly HashSet<string> P3Tests = new HashSet<string>
        {
            nameof(ParallelDatumStacksKeepNestedDimensionsSeparated),
            nameof(ContinuousExtensionPolicyNeverBreaksOrDeduplicates),
            nameof(ExtensionGeometrySegmentsAllFourSides),
            nameof(ExtensionSharingRequiresFamilyAndRealPoint),
            nameof(SingletonAlignmentIsNotProof),
            nameof(OutlineTopologyCapturesActualBoundaryWalk),
            nameof(OutlineTopologyDoesNotCloseGaps),
            nameof(OutlineTopologyReportsAmbiguousComponents),
            nameof(OutlineTopologyExportsArcsAndEscapesText),
            nameof(DatumRoughnessFollowsToleranceAndVisibleExtensionLine),
            nameof(OverallRemainsOutermostAfterLayoutAlignment),
            nameof(OverallCompactsToOnePhysicalSpacing),
            nameof(EffectiveSpanControlsHorizontalStacking),
            nameof(SharedArrowEndpointUsesStrictSpanOrder),
            nameof(StructureAlignmentKeyAlignsAdjacentSegmentsOnSameLevel),
            nameof(SlotChainAlignmentKeyAlignsEdgeLocationAndCenterDistance),
			nameof(NonPinHorizontalHoleChainSharesAlignmentKey),
            nameof(EffectiveSpanControlsVerticalStacking),
            nameof(NearEqualEffectiveSpansUseSemanticTieBreak),
            nameof(LayoutBlocksUseBottomV203SpanOrder),
            nameof(RootedLayoutBlockSurvivesLegacyLaneProcessing),
            nameof(RootedLaneChoosesNearestSafeFiniteSegmentCoordinate),
            nameof(RootedAlignmentStaysOutsideOuterContour),
            nameof(LooseChainFormsOneEffectiveSpanBlock),
            nameof(NestedLooseHoleSpansStackOnSeparateLayers),
            nameof(DisconnectedLooseChainsRemainSeparateBlocks),
            nameof(OverlappingRootedIntervalsSplitIntoSeparateLeftBlocks),
            nameof(OverlappingDatumAndPinIntervalsSplitIntoSeparateBlocks),
            nameof(IndependentLocalAndGlobalDimensionsMayShareLogicalLevel),
            nameof(IsolatedShortPinGroupTransferUsesInnerSpanOrder),
            nameof(DimensionDiagnosticsRecordFinalPlacement),
			nameof(PreferredSideLooseChainCanRebalance),
            nameof(PinGroupAnchoredLooseHolePreservesPreferredSide),
            nameof(FormattedDimensionTextLengthIgnoresControlCodes),
            nameof(FittingVerticalLocalTextStaysCentered),
            nameof(HardTextOverlapSlidesVerticalDatumOnSameSide),
            nameof(HardTextOverlapSlidesHorizontalDatumOnSameSide),
            nameof(NonOverlappingDatumTextDoesNotSlide),
            nameof(ShortVerticalLocalTextClearsArrowheads),
            nameof(FittingHorizontalTextStaysCenteredDespiteNeighborArrow),
            nameof(ShortHorizontalLocalTextClearsArrowheads),
            nameof(ShortVerticalChainTextAvoidsNeighborArrowheads),
            nameof(PinAlignmentGroupsRespectSideAndOrientation),
            nameof(RootedDatumChainMergesTransitiveAlignmentLanes),
            nameof(PinAlignmentAnchorFallsBackWithStableOrdering),
            nameof(PinAlignmentGroupMovesTogetherOnConflict),
            nameof(PinAlignmentGroupAvoidsResolvedCoordinateConflicts),
            nameof(PinAlignmentKeySplitsStrictHorizontalOverlapsIntoLanes),
            nameof(PinAlignmentKeySplitsStrictVerticalOverlapsIntoLanes),
            nameof(FunctionalHoleAlignmentUsesSeparateSameOrientationLane),
            nameof(FunctionalHoleAlignmentPreservesV198Stacking),
            nameof(FunctionalHoleAlignmentLaneSurvivesOutwardPromotion),
            nameof(FunctionalHoleBeyondPinChainStacksOutsideDatumChain),
			nameof(LocalFunctionalHolesStraddlingDatumStayInsideDatumLocation),
			nameof(TinyPinGroupGapStaysInsideAlignedFunctionalHolesOnLeft),
            nameof(PreferredSideLockedHoleLocationUsesLocalBoundary),
			nameof(LeftHoleLocalBoundaryDoesNotUseInnerHoleColumn),
            nameof(ExplicitLocalLooseChainUsesNearbyConcaveBoundary),
            nameof(HoleLocationDimensionsUseSegmentedExtensionLines),
            nameof(HoleCalloutsUsePinClustersAndFitText)
        };

        private static int Main(string[] args)
        {
            string filter = args.Length > 0 ? args[0] : null;
            try
            {
                if (filter == "--runner-self-check")
                {
                    CheckRunner();
                    Console.WriteLine("Runner self-check passed.");
                    return 0;
                }
                if (filter == "--ablation-snapshot")
                {
                    return WriteAblationSnapshot(args[1]);
                }
                if (filter == "--ablation")
                {
                    return RunAblation(args[1], args[2]);
                }
                if (filter == "--ablation-self-check")
                {
                    return CheckAblation();
                }
                RunTest(nameof(RectangularOutlineKeepsOverallDimensions), RectangularOutlineKeepsOverallDimensions);
                RunTest(nameof(ChamferedEnvelopeDropsSplitStructureFragments), ChamferedEnvelopeDropsSplitStructureFragments);
                RunTest(nameof(DatumRoughnessFollowsToleranceAndVisibleExtensionLine), DatumRoughnessFollowsToleranceAndVisibleExtensionLine);
                RunTest(nameof(ClosedPathRecognitionBuildsOutline), ClosedPathRecognitionBuildsOutline);
                RunTest(nameof(ChamferedOutlineKeepsOverallDimensions), ChamferedOutlineKeepsOverallDimensions);
                RunTest(nameof(MultipleChamfersKeepOverallDimensions), MultipleChamfersKeepOverallDimensions);
                RunTest(nameof(MirroredChamferPreservesRecognition), MirroredChamferPreservesRecognition);
                RunTest(nameof(FilletedOutlineKeepsOverallDimensions), FilletedOutlineKeepsOverallDimensions);
                RunTest(nameof(OverallDimensionsUseBoundaryGripPoints), OverallDimensionsUseBoundaryGripPoints);
                RunTest(nameof(ArcEnvelopeUsesRealInteriorGripPoint), ArcEnvelopeUsesRealInteriorGripPoint);
                RunTest(nameof(NegativeBulgeArcUsesRealInteriorGripPoint), NegativeBulgeArcUsesRealInteriorGripPoint);
                RunTest(nameof(DisconnectedOutlineCanUseVerifiedRealGrips), DisconnectedOutlineCanUseVerifiedRealGrips);
                RunTest(nameof(TranslatedOutlinePreservesOverallSemantics), TranslatedOutlinePreservesOverallSemantics);
                RunTest(nameof(RotatedOutlineUsesRealEnvelopeGrips), RotatedOutlineUsesRealEnvelopeGrips);
                RunTest(nameof(DuplicateSegmentsAreSuppressedWithDiagnostic), DuplicateSegmentsAreSuppressedWithDiagnostic);
                RunTest(nameof(ZeroAndMicroSegmentsDoNotEmitDimensions), ZeroAndMicroSegmentsDoNotEmitDimensions);
                RunTest(nameof(GeometryToleranceControlsMicroSegments), GeometryToleranceControlsMicroSegments);
                RunTest(nameof(ConcaveHoleDatumUsesRealOutlineIntersections), ConcaveHoleDatumUsesRealOutlineIntersections);
                RunTest(nameof(OverallWinsDuplicatePreferenceEvenAgainstTolerance), OverallWinsDuplicatePreferenceEvenAgainstTolerance);
                RunTest(nameof(LocalGeometryOnOverallEnvelopeSuppressesOnlyEligibleRoles), LocalGeometryOnOverallEnvelopeSuppressesOnlyEligibleRoles);
				RunTest(nameof(OverallRemainsOutermostAfterLayoutAlignment), OverallRemainsOutermostAfterLayoutAlignment);
				RunTest(nameof(OverallCompactsToOnePhysicalSpacing), OverallCompactsToOnePhysicalSpacing);
				RunTest(nameof(EffectiveSpanControlsHorizontalStacking), EffectiveSpanControlsHorizontalStacking);
				RunTest(nameof(SharedArrowEndpointUsesStrictSpanOrder), SharedArrowEndpointUsesStrictSpanOrder);
				RunTest(nameof(StructureAlignmentKeyAlignsAdjacentSegmentsOnSameLevel), StructureAlignmentKeyAlignsAdjacentSegmentsOnSameLevel);
				RunTest(nameof(SlotChainAlignmentKeyAlignsEdgeLocationAndCenterDistance), SlotChainAlignmentKeyAlignsEdgeLocationAndCenterDistance);
				RunTest(nameof(NonPinHorizontalHoleChainSharesAlignmentKey), NonPinHorizontalHoleChainSharesAlignmentKey);
				RunTest(nameof(OutlineSegmentsThatPartitionOverallAreSuppressed), OutlineSegmentsThatPartitionOverallAreSuppressed);
				RunTest(nameof(ThreeOutlineSegmentsThatPartitionOverallAreSuppressed), ThreeOutlineSegmentsThatPartitionOverallAreSuppressed);
				RunTest(nameof(OutlineSegmentOnOverallEnvelopeIsSuppressed), OutlineSegmentOnOverallEnvelopeIsSuppressed);
				RunTest(nameof(StructureDuplicateOfEnvelopeOutlineSegmentIsSuppressed), StructureDuplicateOfEnvelopeOutlineSegmentIsSuppressed);
				RunTest(nameof(EnvelopeStructureSameSideCollinearDuplicateIsSuppressed), EnvelopeStructureSameSideCollinearDuplicateIsSuppressed);
				RunTest(nameof(StructureSameIntervalAsOppositeEnvelopeTipIsKept), StructureSameIntervalAsOppositeEnvelopeTipIsKept);
				RunTest(nameof(MirroredEnvelopeStructureWidthsAreBothSuppressed), MirroredEnvelopeStructureWidthsAreBothSuppressed);
				RunTest(nameof(Production73x20EnvelopeDimensionsAreSuppressed), Production73x20EnvelopeDimensionsAreSuppressed);
				RunTest(nameof(InnerOutlineSegmentMatchingEnvelopeTipIsSuppressed), InnerOutlineSegmentMatchingEnvelopeTipIsSuppressed);
				RunTest(nameof(CompleteOverallPartitionIntervalsAreDetected), CompleteOverallPartitionIntervalsAreDetected);
				RunTest(nameof(GreedyDeadEndStillFindsValidOverallPartitionChain), GreedyDeadEndStillFindsValidOverallPartitionChain);
				RunTest(nameof(SnapToOriginPointIsNotTreatedAsNotFound), SnapToOriginPointIsNotTreatedAsNotFound);
				RunTest(nameof(SnapKeepsOriginalPointWhenNoCandidateExists), SnapKeepsOriginalPointWhenNoCandidateExists);
				RunTest(nameof(LegalComplementaryPartitionAllowsSnapAndSuppress), LegalComplementaryPartitionAllowsSnapAndSuppress);
				RunTest(nameof(OverlappingSpanSumDoesNotAllowComplementarySnap), OverlappingSpanSumDoesNotAllowComplementarySnap);
				RunTest(nameof(GappedSpanSumDoesNotAllowComplementarySnap), GappedSpanSumDoesNotAllowComplementarySnap);
				RunTest(nameof(NumericComplementLocalStructuresDoNotSnapOrSuppress), NumericComplementLocalStructuresDoNotSnapOrSuppress);
				RunTest(nameof(OverlappingIntervalsDoNotFormOverallPartition), OverlappingIntervalsDoNotFormOverallPartition);
				RunTest(nameof(GappedIntervalsDoNotFormOverallPartition), GappedIntervalsDoNotFormOverallPartition);
				RunTest(nameof(OutOfBoundsIntervalsDoNotFormOverallPartition), OutOfBoundsIntervalsDoNotFormOverallPartition);
				RunTest(nameof(NumericallyComplementaryStructureIntervalsDoNotPartitionOverall), NumericallyComplementaryStructureIntervalsDoNotPartitionOverall);
				RunTest(nameof(EffectiveSpanControlsVerticalStacking), EffectiveSpanControlsVerticalStacking);
				RunTest(nameof(NearEqualEffectiveSpansUseSemanticTieBreak), NearEqualEffectiveSpansUseSemanticTieBreak);
				RunTest(nameof(LayoutBlocksUseBottomV203SpanOrder), LayoutBlocksUseBottomV203SpanOrder);
				RunTest(nameof(RootedLayoutBlockSurvivesLegacyLaneProcessing), RootedLayoutBlockSurvivesLegacyLaneProcessing);
				RunTest(nameof(RootedLaneChoosesNearestSafeFiniteSegmentCoordinate), RootedLaneChoosesNearestSafeFiniteSegmentCoordinate);
				RunTest(nameof(RootedAlignmentStaysOutsideOuterContour), RootedAlignmentStaysOutsideOuterContour);
				RunTest(nameof(LooseChainFormsOneEffectiveSpanBlock), LooseChainFormsOneEffectiveSpanBlock);
				RunTest(nameof(NestedLooseHoleSpansStackOnSeparateLayers), NestedLooseHoleSpansStackOnSeparateLayers);
				RunTest(nameof(DisconnectedLooseChainsRemainSeparateBlocks), DisconnectedLooseChainsRemainSeparateBlocks);
				RunTest(nameof(OverlappingRootedIntervalsSplitIntoSeparateLeftBlocks), OverlappingRootedIntervalsSplitIntoSeparateLeftBlocks);
				RunTest(nameof(OverlappingDatumAndPinIntervalsSplitIntoSeparateBlocks), OverlappingDatumAndPinIntervalsSplitIntoSeparateBlocks);
				RunTest(nameof(IndependentLocalAndGlobalDimensionsMayShareLogicalLevel), IndependentLocalAndGlobalDimensionsMayShareLogicalLevel);
				RunTest(nameof(IsolatedShortPinGroupTransferUsesInnerSpanOrder), IsolatedShortPinGroupTransferUsesInnerSpanOrder);
				RunTest(nameof(OutlineTopologyCapturesActualBoundaryWalk), OutlineTopologyCapturesActualBoundaryWalk);
				RunTest(nameof(OutlineTopologyDoesNotCloseGaps), OutlineTopologyDoesNotCloseGaps);
				RunTest(nameof(OutlineTopologyReportsAmbiguousComponents), OutlineTopologyReportsAmbiguousComponents);
				RunTest(nameof(OutlineTopologyExportsArcsAndEscapesText), OutlineTopologyExportsArcsAndEscapesText);
				RunTest(nameof(DimensionDiagnosticsRecordFinalPlacement), DimensionDiagnosticsRecordFinalPlacement);
				RunTest(nameof(PreferredSideLooseChainCanRebalance), PreferredSideLooseChainCanRebalance);
				RunTest(nameof(PinGroupAnchoredLooseHolePreservesPreferredSide), PinGroupAnchoredLooseHolePreservesPreferredSide);
				RunTest(nameof(RuleEvidenceRejectsReassignmentAndRenderSuppressionStaysCompatible), RuleEvidenceRejectsReassignmentAndRenderSuppressionStaysCompatible);
				RunTest(nameof(FormattedDimensionTextLengthIgnoresControlCodes), FormattedDimensionTextLengthIgnoresControlCodes);
				RunTest(nameof(FittingVerticalLocalTextStaysCentered), FittingVerticalLocalTextStaysCentered);
				RunTest(nameof(HardTextOverlapSlidesVerticalDatumOnSameSide), HardTextOverlapSlidesVerticalDatumOnSameSide);
				RunTest(nameof(HardTextOverlapSlidesHorizontalDatumOnSameSide), HardTextOverlapSlidesHorizontalDatumOnSameSide);
				RunTest(nameof(NonOverlappingDatumTextDoesNotSlide), NonOverlappingDatumTextDoesNotSlide);
				RunTest(nameof(ShortVerticalLocalTextClearsArrowheads), ShortVerticalLocalTextClearsArrowheads);
				RunTest(nameof(FittingHorizontalTextStaysCenteredDespiteNeighborArrow), FittingHorizontalTextStaysCenteredDespiteNeighborArrow);
				RunTest(nameof(ShortHorizontalLocalTextClearsArrowheads), ShortHorizontalLocalTextClearsArrowheads);
				RunTest(nameof(ShortVerticalChainTextAvoidsNeighborArrowheads), ShortVerticalChainTextAvoidsNeighborArrowheads);
                RunTest(nameof(InvalidDatumCoordinateIsSkippedWithDiagnostic), InvalidDatumCoordinateIsSkippedWithDiagnostic);
                RunTest(nameof(InvalidSlotDatumIsSkippedWithDiagnostic), InvalidSlotDatumIsSkippedWithDiagnostic);
                RunTest(nameof(AxisSegmentBetweenTwoChamfersIsRecognized), AxisSegmentBetweenTwoChamfersIsRecognized);
                RunTest(nameof(ChamferSuppressesAdjacentLocalLinearDimensions), ChamferSuppressesAdjacentLocalLinearDimensions);
                RunTest(nameof(NonFortyFiveSlopeIsNotChamfer), NonFortyFiveSlopeIsNotChamfer);
                RunTest(nameof(VerticalStructurePointsCreateStepWidths), VerticalStructurePointsCreateStepWidths);
                RunTest(nameof(StructureWidthsThatPartitionOverallAreSuppressed), StructureWidthsThatPartitionOverallAreSuppressed);
				RunTest(nameof(ProjectedCrossLevelStructureWidthsDoNotPartitionOverall), ProjectedCrossLevelStructureWidthsDoNotPartitionOverall);
				RunTest(nameof(GeometricMirrorOwnershipPrefersContourBackedCandidate), GeometricMirrorOwnershipPrefersContourBackedCandidate);
				RunTest(nameof(SameSideClosedChainSuppressesCrossLevelProjection), SameSideClosedChainSuppressesCrossLevelProjection);
				RunTest(nameof(ProjectedThreePieceHorizontalChainKeepsRealSteps), ProjectedThreePieceHorizontalChainKeepsRealSteps);
				RunTest(nameof(TopClosedChainDropsUnbackedBodyRemainder), TopClosedChainDropsUnbackedBodyRemainder);
				RunTest(nameof(TopClosedChainKeepsRealStepsDropsUnbackedBody), TopClosedChainKeepsRealStepsDropsUnbackedBody);
				RunTest(nameof(TopClosedChainWithoutDatumDropsOppositeBody), TopClosedChainWithoutDatumDropsOppositeBody);
				RunTest(nameof(BottomClosedChainWithoutDatumDropsOppositeBody), BottomClosedChainWithoutDatumDropsOppositeBody);
				RunTest(nameof(RightClosedChainWithoutDatumDropsOppositeBody), RightClosedChainWithoutDatumDropsOppositeBody);
				RunTest(nameof(MultiPieceStructureOverallRemainderDropsLongBody), MultiPieceStructureOverallRemainderDropsLongBody);
				RunTest(nameof(BottomMultiLevelStepsKeepFeatureChainDropBodyRemainder), BottomMultiLevelStepsKeepFeatureChainDropBodyRemainder);
				RunTest(nameof(BottomCrossLevelLedgeSnapWhenOutlineSegmentResolvesTop), BottomCrossLevelLedgeSnapWhenOutlineSegmentResolvesTop);
				RunTest(nameof(LeftMultiPieceStepsSurviveOrphanTipOnTallOverall), LeftMultiPieceStepsSurviveOrphanTipOnTallOverall);
				RunTest(nameof(BottomClosedChainFlippedKeepsShorterEnd75Drops90), BottomClosedChainFlippedKeepsShorterEnd75Drops90);
				RunTest(nameof(TopCrossAxisStructWidth8IsRejected), TopCrossAxisStructWidth8IsRejected);
				RunTest(nameof(RightSplitHeights56And72AreOrphanTipsOn215), RightSplitHeights56And72AreOrphanTipsOn215);
				RunTest(nameof(TopDisconnectedSecondary87WithMajor120IsSuppressed), TopDisconnectedSecondary87WithMajor120IsSuppressed);
				RunTest(nameof(RightResidual72WithLeftMajor120IsSuppressed), RightResidual72WithLeftMajor120IsSuppressed);
				RunTest(nameof(Rotated215Notch50And75SurviveOnLeftAndRight), Rotated215Notch50And75SurviveOnLeftAndRight);
				RunTest(nameof(ProjectedThreePieceVerticalChainKeepsRealHeights), ProjectedThreePieceVerticalChainKeepsRealHeights);
				RunTest(nameof(OrthogonalRotatedVerticalChainKeepsRealWidths), OrthogonalRotatedVerticalChainKeepsRealWidths);
				RunTest(nameof(FullWidthSideSeamsDoNotCreateStructureHeights), FullWidthSideSeamsDoNotCreateStructureHeights);
				RunTest(nameof(MirroredProjectedChainNormalizesStructureSelection), MirroredProjectedChainNormalizesStructureSelection);
				RunTest(nameof(Test2BottomContourChainKeepsTwoRealWidths), Test2BottomContourChainKeepsTwoRealWidths);
				RunTest(nameof(RotatedTest2PreservesLocalSemanticSignature), RotatedTest2PreservesLocalSemanticSignature);
				RunTest(nameof(RotationSignature_OuterStepOverallStructureIsStable), RotationSignature_OuterStepOverallStructureIsStable);
				RunTest(nameof(RotationSignature_ClosedChainStructureIsStable), RotationSignature_ClosedChainStructureIsStable);
				RunTest(nameof(RotationSignature_F215GoldenMultisetFourWayEqual), RotationSignature_F215GoldenMultisetFourWayEqual);
				RunTest(nameof(RotationSignature_F215CadGoldenMultisetFourWayEqual), RotationSignature_F215CadGoldenMultisetFourWayEqual);
				RunTest(nameof(F215CadRotatedKeeps42Drops32Stub), F215CadRotatedKeeps42Drops32Stub);
				RunTest(nameof(RotationSignature_F338GoldenMultisetFourWayEqual), RotationSignature_F338GoldenMultisetFourWayEqual);
				RunTest(nameof(RotationSignature_F338CadGoldenMultisetFourWayEqual), RotationSignature_F338CadGoldenMultisetFourWayEqual);
				RunTest(nameof(CadLastRunGrooveSnapsToWallClearWidthFourWay), CadLastRunGrooveSnapsToWallClearWidthFourWay);
				RunTest(nameof(RotationSignature_Stair3GoldenMultisetFourWayEqual), RotationSignature_Stair3GoldenMultisetFourWayEqual);
				RunTest(nameof(RotationSignature_LBoss257GoldenMultisetFourWayEqual), RotationSignature_LBoss257GoldenMultisetFourWayEqual);
				RunTest(nameof(SteppedPlateReplacesThinStepRisersWithComplement53), SteppedPlateReplacesThinStepRisersWithComplement53);
				RunTest(nameof(CNotchPlateKeepsTopEnvelopeBodyWidth120), CNotchPlateKeepsTopEnvelopeBodyWidth120);
				RunTest(nameof(AnnotationCaseOverlayDropsMaxEndResidual), AnnotationCaseOverlayDropsMaxEndResidual);
				RunTest(nameof(AnnotationCaseSnapshotRequiresSuccessfulCurrentDocumentRun), AnnotationCaseSnapshotRequiresSuccessfulCurrentDocumentRun);
				RunTest(nameof(AnnotationCaseStrategyMatchesSquareAndFilletCoveringChains), AnnotationCaseStrategyMatchesSquareAndFilletCoveringChains);
				RunTest(nameof(AnnotationCaseStrategyDoesNotDropLoneResidual), AnnotationCaseStrategyDoesNotDropLoneResidual);
				RunTest(nameof(StepGroovePlacesOnSameSideAsOuterStepFourWay), StepGroovePlacesOnSameSideAsOuterStepFourWay);
				RunTest(nameof(CrossSideStructureWidthsThatCloseOverallChainAreSuppressed), CrossSideStructureWidthsThatCloseOverallChainAreSuppressed);
                RunTest(nameof(InteriorHorizontalOutlineSegmentPrefersNonCrossingSide), InteriorHorizontalOutlineSegmentPrefersNonCrossingSide);
                RunTest(nameof(TopEnvelopeHorizontalSegmentStaysTop), TopEnvelopeHorizontalSegmentStaysTop);
                RunTest(nameof(BottomEnvelopeHorizontalSegmentStaysBottom), BottomEnvelopeHorizontalSegmentStaysBottom);
                RunTest(nameof(BottomBodyWidthNotDroppedByLongestExtension), BottomBodyWidthNotDroppedByLongestExtension);
                RunTest(nameof(BottomStructureRejectsCrossAxisProjection), BottomStructureRejectsCrossAxisProjection);
                RunTest(nameof(BottomOuterContourStepKeeps20AndSuppresses70Body), BottomOuterContourStepKeeps20AndSuppresses70Body);
                RunTest(nameof(TranslatedOuterContourStepKeepsRuleDecision), TranslatedOuterContourStepKeepsRuleDecision);
                RunTest(nameof(OutlineSegmentBodyLengthClosedByStepIsSuppressed), OutlineSegmentBodyLengthClosedByStepIsSuppressed);
                RunTest(nameof(DatumRootedLeftOuterEnvelopeDimensionsAreSuppressed), DatumRootedLeftOuterEnvelopeDimensionsAreSuppressed);
                RunTest(nameof(DatumRootedBottomAndLeftOuterEnvelopeDimensionsAreSuppressed), DatumRootedBottomAndLeftOuterEnvelopeDimensionsAreSuppressed);
                RunTest(nameof(DatumRootedBottomEnvelopeStepAndArcResidualAreSuppressed), DatumRootedBottomEnvelopeStepAndArcResidualAreSuppressed);
                RunTest(nameof(StructureWidthThatPartitionsOverallWithOutlineSegmentIsSuppressed), StructureWidthThatPartitionsOverallWithOutlineSegmentIsSuppressed);
                RunTest(nameof(ThreeStructureWidthsThatPartitionOverallAreSuppressed), ThreeStructureWidthsThatPartitionOverallAreSuppressed);
                RunTest(nameof(LocalTopStructureWidthIsKeptWhenNotPartitioningOverall), LocalTopStructureWidthIsKeptWhenNotPartitioningOverall);
                RunTest(nameof(RightArmHeightOnOverallMaxXIsSuppressed), RightArmHeightOnOverallMaxXIsSuppressed);
                RunTest(nameof(StructureCoverageEligibilityIgnoresSourceLabels), StructureCoverageEligibilityIgnoresSourceLabels);
                RunTest(nameof(StructureCoverageProtectsIndependentRequirements), StructureCoverageProtectsIndependentRequirements);
                RunTest(nameof(StructureCoverageRequiresLiveProvidersAndEvidence), StructureCoverageRequiresLiveProvidersAndEvidence);
                RunTest(nameof(StructureCoverageTracksMissingProviders), StructureCoverageTracksMissingProviders);
                RunTest(nameof(PinDatumFamilyKeepsOneSide), PinDatumFamilyKeepsOneSide);
                RunTest(nameof(PinDatumSideIsInheritedOnAllFourSides), PinDatumSideIsInheritedOnAllFourSides);
                RunTest(nameof(FirstPinDatumAlignmentRejectsOverlappingIntervals), FirstPinDatumAlignmentRejectsOverlappingIntervals);
                RunTest(nameof(DatumPinVerticalPreferenceOnlyChangesSelectedGroup), DatumPinVerticalPreferenceOnlyChangesSelectedGroup);
                RunTest(nameof(DatumPinVerticalPreferenceDefaultsToAutomatic), DatumPinVerticalPreferenceDefaultsToAutomatic);
                RunTest(nameof(DatumPinVerticalPreferenceSurvivesFrameTransform), DatumPinVerticalPreferenceSurvivesFrameTransform);
                RunTest(nameof(DatumPinHorizontalPreferenceOnlyChangesSelectedGroup), DatumPinHorizontalPreferenceOnlyChangesSelectedGroup);
                RunTest(nameof(DatumPinLayoutOrientationUsesSelectedGroup), DatumPinLayoutOrientationUsesSelectedGroup);
                RunTest(nameof(HorizontalPreferenceKeepsContinuousDatumChain), HorizontalPreferenceKeepsContinuousDatumChain);
                RunTest(nameof(CollinearExteriorBranchFragmentsUseTopology), CollinearExteriorBranchFragmentsUseTopology);
                RunTest(nameof(CollinearExteriorBranchFragmentsProtectRequirements), CollinearExteriorBranchFragmentsProtectRequirements);
                RunTest(nameof(OutlineTopologyNonExteriorEntitiesUseYellowArrows), OutlineTopologyNonExteriorEntitiesUseYellowArrows);
                RunTest(nameof(ObliqueBoundaryInformationMatchesUserScheme), ObliqueBoundaryInformationMatchesUserScheme);
                RunTest(nameof(ObliqueBoundaryInformationProtectsEqualProjections), ObliqueBoundaryInformationProtectsEqualProjections);
                RunTest(nameof(ObliqueBoundaryInformationFallsBackAndAuditsMissingProviders), ObliqueBoundaryInformationFallsBackAndAuditsMissingProviders);
                RunTest(nameof(SeparatePinGroupsKeepIndependentSides), SeparatePinGroupsKeepIndependentSides);
                RunTest(nameof(ParallelDatumStacksKeepNestedDimensionsSeparated), ParallelDatumStacksKeepNestedDimensionsSeparated);
                RunTest(nameof(ContinuousExtensionPolicyNeverBreaksOrDeduplicates), ContinuousExtensionPolicyNeverBreaksOrDeduplicates);
                RunTest(nameof(ExtensionGeometrySegmentsAllFourSides), ExtensionGeometrySegmentsAllFourSides);
                RunTest(nameof(ExtensionSharingRequiresFamilyAndRealPoint), ExtensionSharingRequiresFamilyAndRealPoint);
                RunTest(nameof(SingletonAlignmentIsNotProof), SingletonAlignmentIsNotProof);
                RunTest(nameof(OuterBoundaryOwnershipRejectsInternalTopFrame), OuterBoundaryOwnershipRejectsInternalTopFrame);
                RunTest(nameof(ChamferComplementRequiresBoundaryWalk), ChamferComplementRequiresBoundaryWalk);
                RunTest(nameof(BoundarySelectionCannotRestoreInternalEdges), BoundarySelectionCannotRestoreInternalEdges);
                RunTest(nameof(UnverifiedAttachmentRemainsUnknown), UnverifiedAttachmentRemainsUnknown);
                RunTest(nameof(LProfileChamferedArmResidualUsesBoundarySequence), LProfileChamferedArmResidualUsesBoundarySequence);
                RunTest(nameof(LProfileChamferedArmResidualRequiresChamferDefinition), LProfileChamferedArmResidualRequiresChamferDefinition);
                RunTest(nameof(LProfileAnnotationRulesUseTopology), LProfileAnnotationRulesUseTopology);
                RunTest(nameof(LProfileFarEndCornerUsesAdjacentVerticalChain), LProfileFarEndCornerUsesAdjacentVerticalChain);
                RunTest(nameof(LProfileOuterContourAnnotationRulesUseTopology), LProfileOuterContourAnnotationRulesUseTopology);
                RunTest(nameof(LProfileTopologyRejectionIsDiagnostic), LProfileTopologyRejectionIsDiagnostic);
                RunTest(nameof(RoundedRectangleOuterContourIsNotLProfile), RoundedRectangleOuterContourIsNotLProfile);
                RunTest(nameof(LShapeTowerTopWidthIsKeptDespiteArmTopOutlineSegment), LShapeTowerTopWidthIsKeptDespiteArmTopOutlineSegment);
                RunTest(nameof(BottomStepWidthOnOverallEnvelopeIsSuppressed), BottomStepWidthOnOverallEnvelopeIsSuppressed);
				RunTest(nameof(BottomProtrusionSuppressesOuterWidthAndInnerLedge), BottomProtrusionSuppressesOuterWidthAndInnerLedge);
				RunTest(nameof(BottomFilletedProtrusionWidthIsSuppressed), BottomFilletedProtrusionWidthIsSuppressed);
				RunTest(nameof(ChamferedTopStepUsesCompositeDimensions), ChamferedTopStepUsesCompositeDimensions);
                RunTest(nameof(LeftStepStructureHeightsPreferOverRightOutlineSegments), LeftStepStructureHeightsPreferOverRightOutlineSegments);
                RunTest(nameof(RightStepStructureHeightsPreferOverLeftOutlineSegments), RightStepStructureHeightsPreferOverLeftOutlineSegments);
                RunTest(nameof(HorizontalStructurePointsCreateStepHeights), HorizontalStructurePointsCreateStepHeights);
                RunTest(nameof(DiagonalFragmentsDoNotCreateStructureDimensions), DiagonalFragmentsDoNotCreateStructureDimensions);
                RunTest(nameof(BottomInclinedStructurePointsRequireInnerGrooveChamfer), BottomInclinedStructurePointsRequireInnerGrooveChamfer);
                RunTest(nameof(SideInclinedStructurePointsRequireInnerGrooveChamfer), SideInclinedStructurePointsRequireInnerGrooveChamfer);
                RunTest(nameof(RightStructureHeightDuplicatingOverallHeightIsSuppressed), RightStructureHeightDuplicatingOverallHeightIsSuppressed);
                RunTest(nameof(LeftStructureHeightDuplicatingOverallHeightIsSuppressed), LeftStructureHeightDuplicatingOverallHeightIsSuppressed);
                RunTest(nameof(LeftStructureComplementaryRemainderIsRemovedLikeRight), LeftStructureComplementaryRemainderIsRemovedLikeRight);
                RunTest(nameof(OrphanRightOuterStructureHeightTipsAreSuppressed), OrphanRightOuterStructureHeightTipsAreSuppressed);
                RunTest(nameof(PartialEnvelopeStructureHeightSurvivesOrphanTipSuppression), PartialEnvelopeStructureHeightSurvivesOrphanTipSuppression);
                RunTest(nameof(TwoArcSlotIsRecognized), TwoArcSlotIsRecognized);
                RunTest(nameof(SingleArcSlotIsRecognized), SingleArcSlotIsRecognized);
                RunTest(nameof(SlotDimensionsUseCenterAndDatumChainsWithoutPins), SlotDimensionsUseCenterAndDatumChainsWithoutPins);
                RunTest(nameof(HolesAreGroupedByHorizontalRows), HolesAreGroupedByHorizontalRows);
                RunTest(nameof(NormalHolesLocateFromOutlineDatum), NormalHolesLocateFromOutlineDatum);
				RunTest(nameof(CenterlineEndpointIsAllowedForHolePositioning), CenterlineEndpointIsAllowedForHolePositioning);
				RunTest(nameof(HoleAndPinChainsUseSideFacingCenterlineEndpoints), HoleAndPinChainsUseSideFacingCenterlineEndpoints);
				RunTest(nameof(SingleArcSlotDatumUsesBottomCenterlineEndpoint), SingleArcSlotDatumUsesBottomCenterlineEndpoint);
				RunTest(nameof(HoleGripUsesNearCenterlineStubNotFarAxisEnd), HoleGripUsesNearCenterlineStubNotFarAxisEnd);
				RunTest(nameof(BottomHoleGripUsesLowerHoleCenterlineInColumn), BottomHoleGripUsesLowerHoleCenterlineInColumn);
				RunTest(nameof(OffsetColumnDoesNotStealLowerHoleCenterline), OffsetColumnDoesNotStealLowerHoleCenterline);
				RunTest(nameof(PinGroupBasePinLocatesHolesAs14And16), PinGroupBasePinLocatesHolesAs14And16);
				RunTest(nameof(TopLeftRightHoleGripsUsePlacementSideHoleCenterline), TopLeftRightHoleGripsUsePlacementSideHoleCenterline);
				RunTest(nameof(DoubleArcSlotDatumUsesCenterlineAndOutlineEndpoints), DoubleArcSlotDatumUsesCenterlineAndOutlineEndpoints);
				RunTest(nameof(MultipleSlotGroupsFormContinuousChains), MultipleSlotGroupsFormContinuousChains);
				RunTest(nameof(ChamferSideSlotChainUsesChamferSideDatum), ChamferSideSlotChainUsesChamferSideDatum);
				RunTest(nameof(LowerChamferSlotChainUsesBottomPlacement), LowerChamferSlotChainUsesBottomPlacement);
				RunTest(nameof(VerticalSlotDatumUsesLayoutFacingChamferPoint), VerticalSlotDatumUsesLayoutFacingChamferPoint);
				RunTest(nameof(FilletedOuterDatumUsesLayoutFacingFilletEndpoint), FilletedOuterDatumUsesLayoutFacingFilletEndpoint);
				RunTest(nameof(FilletedSlotGridKeepsContinuousVerticalChain), FilletedSlotGridKeepsContinuousVerticalChain);
				RunTest(nameof(PinGroupsPlanBaseAndPairDistances), PinGroupsPlanBaseAndPairDistances);
				RunTest(nameof(PinAlignmentGroupsRespectSideAndOrientation), PinAlignmentGroupsRespectSideAndOrientation);
				RunTest(nameof(RootedDatumChainMergesTransitiveAlignmentLanes), RootedDatumChainMergesTransitiveAlignmentLanes);
				RunTest(nameof(PinAlignmentAnchorFallsBackWithStableOrdering), PinAlignmentAnchorFallsBackWithStableOrdering);
				RunTest(nameof(PinAlignmentGroupMovesTogetherOnConflict), PinAlignmentGroupMovesTogetherOnConflict);
				RunTest(nameof(PinAlignmentGroupAvoidsResolvedCoordinateConflicts), PinAlignmentGroupAvoidsResolvedCoordinateConflicts);
				RunTest(nameof(PinAlignmentKeySplitsStrictHorizontalOverlapsIntoLanes), PinAlignmentKeySplitsStrictHorizontalOverlapsIntoLanes);
				RunTest(nameof(PinAlignmentKeySplitsStrictVerticalOverlapsIntoLanes), PinAlignmentKeySplitsStrictVerticalOverlapsIntoLanes);
				RunTest(nameof(EquivalentPinGroupTransfersSuppressAcrossDebugOwners), EquivalentPinGroupTransfersSuppressAcrossDebugOwners);
				RunTest(nameof(FunctionalHolesAttachToPinGroup), FunctionalHolesAttachToPinGroup);
				RunTest(nameof(HoleBetweenPinPairAttachesAsFunctionalHole), HoleBetweenPinPairAttachesAsFunctionalHole);
				RunTest(nameof(FunctionalHoleAlignmentUsesSeparateSameOrientationLane), FunctionalHoleAlignmentUsesSeparateSameOrientationLane);
				RunTest(nameof(FunctionalHoleAlignmentPreservesV198Stacking), FunctionalHoleAlignmentPreservesV198Stacking);
				RunTest(nameof(FunctionalHoleAlignmentLaneSurvivesOutwardPromotion), FunctionalHoleAlignmentLaneSurvivesOutwardPromotion);
				RunTest(nameof(FunctionalHoleBeyondPinChainStacksOutsideDatumChain), FunctionalHoleBeyondPinChainStacksOutsideDatumChain);
				RunTest(nameof(LocalFunctionalHolesStraddlingDatumStayInsideDatumLocation), LocalFunctionalHolesStraddlingDatumStayInsideDatumLocation);
				RunTest(nameof(TinyPinGroupGapStaysInsideAlignedFunctionalHolesOnLeft), TinyPinGroupGapStaysInsideAlignedFunctionalHolesOnLeft);
				RunTest(nameof(Dl01TopStructureFunctionalHoleDatumChainOrder), Dl01TopStructureFunctionalHoleDatumChainOrder);
                RunTest(nameof(PreferredSideLockedHoleLocationUsesLocalBoundary), PreferredSideLockedHoleLocationUsesLocalBoundary);
				RunTest(nameof(LeftHoleLocalBoundaryDoesNotUseInnerHoleColumn), LeftHoleLocalBoundaryDoesNotUseInnerHoleColumn);
                RunTest(nameof(ExplicitLocalLooseChainUsesNearbyConcaveBoundary), ExplicitLocalLooseChainUsesNearbyConcaveBoundary);
                RunTest(nameof(LooseHolesUseChainDimensions), LooseHolesUseChainDimensions);
                RunTest(nameof(ConcentricLooseHolesShareOneLocationDimension), ConcentricLooseHolesShareOneLocationDimension);
                RunTest(nameof(HoleLocationDimensionsUseSegmentedExtensionLines), HoleLocationDimensionsUseSegmentedExtensionLines);
                RunTest(nameof(HoleCalloutsGroupByRowsWithoutPins), HoleCalloutsGroupByRowsWithoutPins);
                RunTest(nameof(HoleCalloutsUsePinClustersAndFitText), HoleCalloutsUsePinClustersAndFitText);
                RunTest(nameof(ThreeViewFirstAngleKeepsLengthAndHeightOnFrontAndWidthOnTop), ThreeViewFirstAngleKeepsLengthAndHeightOnFrontAndWidthOnTop);
                RunTest(nameof(ThreeViewPinChainStaysOnTheViewThatShowsThePins), ThreeViewPinChainStaysOnTheViewThatShowsThePins);
                RunTest(nameof(TwoViewTopAndLeftSplitLengthHeightAndWidth), TwoViewTopAndLeftSplitLengthHeightAndWidth);
                RunTest(nameof(MismatchedViewEnvelopesDoNotAssign), MismatchedViewEnvelopesDoNotAssign);
                ValidateTestRegistration();
                RunRegisteredTests(filter);
                Console.WriteLine("CadAuto.Core.Tests: " + _passedTests + "/" + _selectedTests + " passed.");
                foreach (Tuple<string, string> failure in FailedTests)
                {
                    Console.WriteLine("FAILED " + failure.Item1 + " :: " + failure.Item2);
                }
                return FailedTests.Count == 0 ? 0 : 1;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ex);
                return 1;
            }
        }

        private static void RunTest(string name, Action test)
        {
            RegisteredTests.Add(Tuple.Create(name, test));
        }

        private static void ValidateTestRegistration()
        {
            IGrouping<string, Tuple<string, Action>> duplicate = RegisteredTests
                .GroupBy(test => test.Item1, StringComparer.Ordinal)
                .FirstOrDefault(group => group.Count() > 1);
            if (duplicate != null)
            {
                throw new InvalidOperationException("Duplicate test registration: " + duplicate.Key);
            }

            var priorityMemberships = P0Tests.Select(name => Tuple.Create(name, "P0"))
                .Concat(P1Tests.Select(name => Tuple.Create(name, "P1")))
                .Concat(P3Tests.Select(name => Tuple.Create(name, "P3")))
                .ToList();
            IGrouping<string, Tuple<string, string>> overlap = priorityMemberships
                .GroupBy(test => test.Item1, StringComparer.Ordinal)
                .FirstOrDefault(group => group.Count() > 1);
            if (overlap != null)
            {
                throw new InvalidOperationException(
                    "Test appears in multiple priority sets: "
                    + overlap.Key
                    + " ("
                    + string.Join(", ", overlap.Select(test => test.Item2))
                    + ")");
            }

            var registeredNames = new HashSet<string>(
                RegisteredTests.Select(test => test.Item1),
                StringComparer.Ordinal);
            Tuple<string, string> unregistered = priorityMemberships
                .FirstOrDefault(test => !registeredNames.Contains(test.Item1));
            if (unregistered != null)
            {
                throw new InvalidOperationException(
                    unregistered.Item2 + " test is not registered: " + unregistered.Item1);
            }
        }

        private static void RunRegisteredTests(string filter)
        {
            if (!string.IsNullOrEmpty(filter)
                && !RegisteredTests.Any(test => MatchesFilter(test.Item1, GetTestPriority(test.Item1), filter)))
            {
                throw new InvalidOperationException("No registered tests matched filter: " + filter);
            }

            for (int priority = 0; priority <= 3; priority++)
            {
                List<Tuple<string, Action>> tests = RegisteredTests
                    .Where(test => GetTestPriority(test.Item1) == priority)
                    .Where(test => MatchesFilter(test.Item1, priority, filter))
                    .ToList();
                if (tests.Count == 0)
                {
                    continue;
                }
                _selectedTests += tests.Count;
                Console.WriteLine("START P" + priority + " count=" + tests.Count);
                int failedInTier = 0;
                foreach (Tuple<string, Action> test in tests)
                {
                    try
                    {
                        test.Item2();
                    }
                    catch (Exception ex)
                    {
                        failedInTier++;
                        FailedTests.Add(Tuple.Create(test.Item1, ex.Message));
                        Console.WriteLine("FAIL P" + priority + " " + test.Item1 + " :: " + ex.Message);
                        if (priority == 0)
                        {
                            // P0 invariants are prerequisites for every later tier; abort the run.
                            Console.WriteLine("TIER FAIL P0 aborting remaining tiers.");
                            ReportUnexecutedTiers(priority, filter);
                            return;
                        }
                        continue;
                    }
                    _passedTests++;
                    Console.WriteLine("PASS P" + priority + " " + test.Item1);
                }
                if (failedInTier == 0)
                {
                    Console.WriteLine("TIER PASS P" + priority + " count=" + tests.Count);
                }
                else
                {
                    Console.WriteLine("TIER FAIL P" + priority + " failed=" + failedInTier);
                    ReportUnexecutedTiers(priority, filter);
                    return;
                }
            }
        }

        private static void ReportUnexecutedTiers(int failedPriority, string filter)
        {
            for (int priority = failedPriority + 1; priority <= 3; priority++)
            {
                int count = RegisteredTests.Count(test => GetTestPriority(test.Item1) == priority
                    && MatchesFilter(test.Item1, priority, filter));
                if (count > 0)
                    Console.WriteLine("TIER NOT RUN P" + priority + " count=" + count + " blocked by P" + failedPriority);
            }
        }

        // Standalone mode: synthetic actions exercise the real runner without production geometry.
        private static void CheckRunner()
        {
            string[][] names = { P0Tests.Take(2).ToArray(), P1Tests.Take(2).ToArray(),
                new[] { "RunnerSyntheticFirst", "RunnerSyntheticSecond" }, P3Tests.Take(2).ToArray() };
            TextWriter output = Console.Out;
            try
            {
                for (int failureTier = -1; failureTier <= 3; failureTier++)
                {
                    RegisteredTests.Clear();
                    FailedTests.Clear();
                    _passedTests = _selectedTests = 0;
                    var visited = new List<string>();
                    for (int tier = 0; tier <= 3; tier++)
                    {
                        int currentTier = tier;
                        foreach (string testName in names[tier])
                        {
                            string name = testName;
                            RunTest(name, () =>
                            {
                                visited.Add(name);
                                if (currentTier == failureTier) throw new Exception("synthetic failure");
                            });
                        }
                    }
                    var log = new StringWriter();
                    Console.SetOut(log);
                    RunRegisteredTests(null);
                    int executed = failureTier < 0 ? 8 : (failureTier == 0 ? 1 : (failureTier + 1) * 2);
                    Assert(visited.SequenceEqual(names.SelectMany(group => group).Take(executed)), "Runner order/stop mismatch");
                    Assert(FailedTests.Count == (failureTier < 0 ? 0 : (failureTier == 0 ? 1 : 2)), "Runner failure count mismatch");
                    for (int tier = failureTier + 1; failureTier >= 0 && tier <= 3; tier++)
                        Assert(log.ToString().Contains("TIER NOT RUN P" + tier), "Missing unexecuted tier");
                    if (failureTier == -1)
                    {
                        visited.Clear();
                        RunRegisteredTests("P2");
                        Assert(visited.SequenceEqual(names[2]), "Priority filter mismatch");
                        visited.Clear();
                        RunRegisteredTests(names[2][0]);
                        Assert(visited.SequenceEqual(new[] { names[2][0] }), "Name filter mismatch");
                        bool rejected = false;
                        try { RunRegisteredTests("__no_matching_test__"); }
                        catch (InvalidOperationException) { rejected = true; }
                        Assert(rejected, "Unknown filter must fail");
                    }
                }
            }
            finally
            {
                Console.SetOut(output);
                RegisteredTests.Clear();
                FailedTests.Clear();
                _passedTests = _selectedTests = 0;
            }
        }

        private static bool MatchesFilter(string name, int priority, string filter)
        {
            if (string.IsNullOrEmpty(filter))
            {
                return true;
            }
            if (filter.Equals("P" + priority, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
            return name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static int GetTestPriority(string name)
        {
            if (P0Tests.Contains(name))
            {
                return 0;
            }
            if (P1Tests.Contains(name))
            {
                return 1;
            }
            if (P3Tests.Contains(name))
            {
                return 3;
            }
            return 2;
        }

        private static void DatumRoughnessFollowsToleranceAndVisibleExtensionLine()
        {
            var datum = new Datum2D { DatumHole = new HoleFeature2D { Kind = HoleKind2D.Pin } };
            for (int mode = 0; mode < 4; mode++)
            {
                datum.DatumHoleLocationUseToleranceX = (mode & 1) != 0;
                datum.DatumHoleLocationUseToleranceY = (mode & 2) != 0;
                foreach (DimensionKind kind in Enum.GetValues(typeof(DimensionKind)))
                {
                    bool expected = (kind == DimensionKind.DatumHoleLocationX && (mode & 1) != 0)
                        || (kind == DimensionKind.DatumHoleLocationY && (mode & 2) != 0);
                    Assert(DimensionLayoutRules.ShouldAddDatumRoughness(datum, kind) == expected,
                        "roughness must follow the selected axis only, never pin spacing or other toleranced dimensions");
                }
            }
            datum.DatumHole = null;
            Assert(!DimensionLayoutRules.ShouldAddDatumRoughness(datum, DimensionKind.DatumHoleLocationX)
                && !DimensionLayoutRules.ShouldAddDatumRoughness(null, DimensionKind.DatumHoleLocationY),
                "automatic datum tolerance without a selected datum pin must not insert roughness");

            var origin = new Point2D(87682.82948477, 16542.81444545);
            foreach (double angle in new[] { 0.0, Math.PI / 2.0, Math.PI / 6.0, 7.0 * Math.PI / 6.0 })
            {
                foreach (double sign in new[] { -1.0, 1.0 })
                {
                    double nx = -Math.Sin(angle), ny = Math.Cos(angle);
                    Func<double, double, Point2D> pointAt = (across, along) => new Point2D(
                        origin.X + Math.Cos(angle) * across + nx * sign * along,
                        origin.Y + Math.Sin(angle) * across + ny * sign * along);
                    var lines = new[]
                    {
                        new Segment2D(pointAt(0.0, 2.0), pointAt(0.0, 11.0)),
                        new Segment2D(pointAt(10.0, -50.0), pointAt(10.0, 11.0)), // longer hole-side extension
                        new Segment2D(pointAt(0.0, 10.0), pointAt(40.0, 10.0)), // dimension line
                        new Segment2D(pointAt(0.0, 10.0), pointAt(0.0, 10.5)) // short arrow detail
                    };
                    Assert(DimensionLayoutRules.TryGetDatumRoughnessPlacement(origin, angle, lines,
                        0.001, out var point, out var rotation), "visible datum extension should accept roughness");
                    Assert(point.DistanceTo(pointAt(0.0, 6.5)) < 1E-6,
                        "insertion point must be the visible datum-side extension midpoint on all four sides and rotated drawings");
                    Assert(Math.Abs(Math.Cos(rotation) * ny - Math.Sin(rotation) * nx) < 1E-6,
                        "roughness block must rotate parallel to the extension line");
                    lines[0] = new Segment2D(pointAt(0.0, 6.0), pointAt(0.0, 11.0));
                    Assert(DimensionLayoutRules.TryGetDatumRoughnessPlacement(origin, angle, lines,
                        0.001, out point, out rotation)
                        && point.DistanceTo(pointAt(0.0, 8.5)) < 1E-6,
                        "fixed extension length must keep the marker inside the shortened visible segment");
                }
            }
            // Run 20260922133332794: DatumX nominal gap is only 0.00000013.
            // A native visible overhang must still accept the S marker.
            var overhang = new Segment2D(new Point2D(origin.X, origin.Y - 0.05), new Point2D(origin.X, origin.Y - 1.25));
            Assert(DimensionLayoutRules.TryGetDatumRoughnessPlacement(origin, 0.0, new[] { overhang },
                0.001, out var stubPoint, out var ignoredRotation)
                && stubPoint.DistanceTo(new Point2D(origin.X, origin.Y - 0.65)) < 1E-6,
                "a zero nominal gap must not discard the actual rendered datum extension");
            Assert(!DimensionLayoutRules.TryGetDatumRoughnessPlacement(origin, 0.0, new[]
                { new Segment2D(new Point2D(origin.X + 10.0, origin.Y), new Point2D(origin.X + 10.0, origin.Y - 40.0)) },
                0.001, out stubPoint, out ignoredRotation), "never substitute the hole-side extension when the datum side is absent");
            Assert(!DimensionLayoutRules.TryGetDatumRoughnessPlacement(origin, 0.0, null,
                0.001, out stubPoint, out ignoredRotation), "no rendered extension must not receive a floating marker");

            var crowdedExtension = new Segment2D(new Point2D(0.0, 0.0), new Point2D(20.0, 0.0));
            var crowdedMidpoint = new Point2D(10.0, 0.0);
            var clearOfText = DimensionLayoutRules.ClearDatumRoughnessFromDimensionText(
                crowdedMidpoint, crowdedExtension, new Point2D(40.0, 12.0), 0.0, 6.0, 4.0);
            Assert(clearOfText.DistanceTo(crowdedMidpoint) < 1E-6,
                "a roughness marker already clear of the dimension text stays on the extension midpoint");
            var shifted = DimensionLayoutRules.ClearDatumRoughnessFromDimensionText(
                crowdedMidpoint, crowdedExtension, new Point2D(10.0, 1.0), 0.0, 8.0, 4.0);
            Assert(Math.Abs(shifted.Y) < 1E-6 && shifted.X > 18.0,
                "a roughness marker on the extension slides along the line until it clears the dimension text");

            OutlineFeature2D outline = CreateRectangle(100.0, 50.0);
            Assert(DimensionLayoutRules.SelectDatumRoughnessBlockName(
                new Point2D(0.0, 25.0), new Point2D(40.0, 25.0),
                new Segment2D(new Point2D(0.0, 10.0), new Point2D(0.0, 40.0)), outline.Segments, 0.001)
                == DimensionLayoutRules.DatumRoughnessBlockName,
                "a datum extension parallel to the left contour end uses the upright roughness block");
            Assert(DimensionLayoutRules.SelectDatumRoughnessBlockName(
                new Point2D(50.0, 50.0), new Point2D(50.0, 20.0),
                new Segment2D(new Point2D(20.0, 50.0), new Point2D(70.0, 50.0)), outline.Segments, 0.001)
                == DimensionLayoutRules.DatumRoughnessBlockName,
                "a datum extension parallel to the top contour end uses the upright roughness block");
            Assert(DimensionLayoutRules.SelectDatumRoughnessBlockName(
                new Point2D(100.0, 20.0), new Point2D(40.0, 20.0),
                new Segment2D(new Point2D(100.0, 5.0), new Point2D(100.0, 35.0)), outline.Segments, 0.001)
                == DimensionLayoutRules.DatumRoughnessDownBlockName,
                "a datum extension parallel to the right contour end uses the downward roughness block");
            Assert(DimensionLayoutRules.SelectDatumRoughnessBlockName(
                new Point2D(30.0, 0.0), new Point2D(30.0, 20.0),
                new Segment2D(new Point2D(10.0, 0.0), new Point2D(55.0, 0.0)), outline.Segments, 0.001)
                == DimensionLayoutRules.DatumRoughnessDownBlockName,
                "a datum extension parallel to the bottom contour end uses the downward roughness block");
            Assert(Math.Abs(DimensionLayoutRules.ApplyDatumRoughnessEndRotation(0.0,
                new Point2D(50.0, 50.0), new Point2D(50.0, 20.0),
                new Segment2D(new Point2D(20.0, 50.0), new Point2D(70.0, 50.0)), outline.Segments, 0.001)) < 1E-6,
                "the top-end upright block keeps the extension rotation");
            Assert(Math.Abs(DimensionLayoutRules.ApplyDatumRoughnessEndRotation(0.0,
                new Point2D(30.0, 0.0), new Point2D(30.0, 20.0),
                new Segment2D(new Point2D(10.0, 0.0), new Point2D(55.0, 0.0)), outline.Segments, 0.001) - Math.PI) < 1E-6,
                "the bottom-end downward block is rotated 180 degrees");
            Assert(Math.Abs(DimensionLayoutRules.ApplyDatumRoughnessEndRotation(Math.PI / 2.0,
                new Point2D(100.0, 20.0), new Point2D(40.0, 20.0),
                new Segment2D(new Point2D(100.0, 5.0), new Point2D(100.0, 35.0)), outline.Segments, 0.001) - 3.0 * Math.PI / 2.0) < 1E-6,
                "the right-end block is rotated 180 degrees clockwise from the extension angle");
            double contourRotation = Math.PI / 9.0;
            OutlineFeature2D rotated = RotateOutline(outline, contourRotation);
            Assert(DimensionLayoutRules.SelectDatumRoughnessBlockName(
                RotatePoint(new Point2D(0.0, 25.0), contourRotation), RotatePoint(new Point2D(40.0, 25.0), contourRotation),
                new Segment2D(RotatePoint(new Point2D(0.0, 10.0), contourRotation), RotatePoint(new Point2D(0.0, 40.0), contourRotation)),
                rotated.Segments, 0.001) == DimensionLayoutRules.DatumRoughnessBlockName,
                "a rotated left contour end still uses the upright roughness block");
            Assert(DimensionLayoutRules.SelectDatumRoughnessBlockName(
                RotatePoint(new Point2D(30.0, 0.0), contourRotation), RotatePoint(new Point2D(30.0, 20.0), contourRotation),
                new Segment2D(RotatePoint(new Point2D(10.0, 0.0), contourRotation), RotatePoint(new Point2D(55.0, 0.0), contourRotation)),
                rotated.Segments, 0.001) == DimensionLayoutRules.DatumRoughnessDownBlockName,
                "a rotated bottom contour end still uses the downward roughness block");
        }

        private static void ChamferedEnvelopeDropsSplitStructureFragments()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var planner = new DimensionPlanner(config);
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 118.0,
                MaxY = 40.0
            };
            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(10.0, 0.0), "bottom-left");
            AddSegment(outline, new Point2D(10.0, 0.0), new Point2D(113.0, 0.0), "bottom-body");
            AddSegment(outline, new Point2D(113.0, 0.0), new Point2D(118.0, 5.0), "chamfer");
            AddSegment(outline, new Point2D(118.0, 5.0), new Point2D(118.0, 40.0), "right");
            AddSegment(outline, new Point2D(118.0, 40.0), new Point2D(0.0, 40.0), "top");
            AddSegment(outline, new Point2D(0.0, 40.0), new Point2D(0.0, 0.0), "left");
            AddSegment(outline, new Point2D(10.0, 0.0), new Point2D(10.0, 15.0), "groove");
            outline.Chamfers.Add(new ChamferFeature2D
            {
                StartPoint = new Point2D(113.0, 0.0),
                EndPoint = new Point2D(118.0, 5.0),
                DeltaX = 5.0,
                DeltaY = 5.0,
                Value = 5.0
            });
            var plan = new DimensionPlan();
            var overallWidth = new PlannedDimension
            {
                Kind = DimensionKind.OverallWidth,
                Orientation = DimensionOrientation.Horizontal,
                Side = DimensionSide.Bottom,
                FirstPoint = new Point2D(0.0, 0.0),
                SecondPoint = new Point2D(118.0, 0.0),
                DebugRole = "OverallWidth"
            };
            var overallHeight = new PlannedDimension
            {
                Kind = DimensionKind.OverallHeight,
                Orientation = DimensionOrientation.Vertical,
                Side = DimensionSide.Left,
                FirstPoint = new Point2D(0.0, 0.0),
                SecondPoint = new Point2D(0.0, 40.0),
                DebugRole = "OverallHeight"
            };
            var bottomTen = new PlannedDimension
            {
                Kind = DimensionKind.Normal,
                Orientation = DimensionOrientation.Horizontal,
                Side = DimensionSide.Bottom,
                FirstPoint = new Point2D(0.0, 0.0),
                SecondPoint = new Point2D(10.0, 0.0),
                DebugRole = "BottomStructWidth"
            };
            var bottomBody = new PlannedDimension
            {
                Kind = DimensionKind.Normal,
                Orientation = DimensionOrientation.Horizontal,
                Side = DimensionSide.Bottom,
                FirstPoint = new Point2D(10.0, 0.0),
                SecondPoint = new Point2D(113.0, 0.0),
                DebugRole = "BottomStructWidth"
            };
            var rightHeight = new PlannedDimension
            {
                Kind = DimensionKind.Normal,
                Orientation = DimensionOrientation.Vertical,
                Side = DimensionSide.Right,
                FirstPoint = new Point2D(118.0, 5.0),
                SecondPoint = new Point2D(118.0, 40.0),
                DebugRole = "RightStructHeight"
            };
            plan.Add(overallWidth);
            plan.Add(overallHeight);
            plan.Add(bottomTen);
            plan.Add(bottomBody);
            plan.Add(rightHeight);
            planner.SuppressLocalGeometryOnOverallEnvelope(plan, outline);
            Assert(plan.Dimensions.Contains(overallWidth) && plan.Dimensions.Contains(overallHeight),
                "overall width and height stay when the envelope edge is completed by a chamfer");
            Assert(!plan.Dimensions.Contains(bottomTen) && !plan.Dimensions.Contains(bottomBody),
                "collinear bottom fragments on a chamfer-completed outer edge must be suppressed");
            Assert(!plan.Dimensions.Contains(rightHeight),
                "right height that only omits a chamfer must be suppressed");

            var step = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 60.0, MaxY = 40.0 };
            AddSegment(step, new Point2D(0.0, 0.0), new Point2D(60.0, 0.0), "bottom");
            AddSegment(step, new Point2D(60.0, 0.0), new Point2D(60.0, 20.0), "right-step");
            AddSegment(step, new Point2D(60.0, 20.0), new Point2D(30.0, 20.0), "ledge");
            AddSegment(step, new Point2D(30.0, 20.0), new Point2D(30.0, 40.0), "riser");
            AddSegment(step, new Point2D(30.0, 40.0), new Point2D(0.0, 40.0), "top");
            AddSegment(step, new Point2D(0.0, 40.0), new Point2D(0.0, 0.0), "left");
            var stepPlan = new DimensionPlan();
            var stepHeight = new PlannedDimension
            {
                Kind = DimensionKind.Normal,
                Orientation = DimensionOrientation.Vertical,
                Side = DimensionSide.Right,
                FirstPoint = new Point2D(60.0, 0.0),
                SecondPoint = new Point2D(60.0, 20.0),
                DebugRole = "RightStructHeight"
            };
            stepPlan.Add(new PlannedDimension
            {
                Kind = DimensionKind.OverallHeight,
                Orientation = DimensionOrientation.Vertical,
                Side = DimensionSide.Left,
                FirstPoint = new Point2D(0.0, 0.0),
                SecondPoint = new Point2D(0.0, 40.0),
                DebugRole = "OverallHeight"
            });
            stepPlan.Add(stepHeight);
            planner.SuppressLocalGeometryOnOverallEnvelope(stepPlan, step);
            Assert(stepPlan.Dimensions.Contains(stepHeight),
                "a real right step shorter than overall height must stay");
        }

        private static void RectangularOutlineKeepsOverallDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(100.0, 50.0);
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            AssertHasDimension(plan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0, "rectangle overall width");
            AssertHasDimension(plan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 50.0, "rectangle overall height");
        }

        private static void AxisSegmentBetweenTwoChamfersIsRecognized()
        {
            const double tolerance = 0.001;
            var vertical = new Segment2D(new Point2D(0.0, 1.0), new Point2D(0.0, 9.0));
            var lower = new Segment2D(new Point2D(-1.0, 0.0), vertical.Start);
            var upper = new Segment2D(vertical.End, new Point2D(-1.0, 10.0));
            var unrelated = new Segment2D(new Point2D(5.0, 0.0), new Point2D(5.0, 10.0));
            var verticalOutline = new OutlineFeature2D();
            verticalOutline.Segments.AddRange(new[] { lower, vertical, upper, unrelated });
            verticalOutline.Chamfers.Add(new ChamferFeature2D { StartPoint = lower.Start, EndPoint = lower.End, SourceSegment = lower });
            verticalOutline.Chamfers.Add(new ChamferFeature2D { StartPoint = upper.Start, EndPoint = upper.End, SourceSegment = upper });

            Assert(OutlineGeometryQuery.IsAxisSegmentBetweenTwoChamfers(verticalOutline, vertical, tolerance),
                "vertical line between two chamfers must be recognized");
            Assert(!OutlineGeometryQuery.IsAxisSegmentBetweenTwoChamfers(verticalOutline, unrelated, tolerance),
                "an unrelated vertical line must not be recognized");

            var horizontal = new Segment2D(new Point2D(1.0, 0.0), new Point2D(9.0, 0.0));
            var left = new Segment2D(new Point2D(0.0, -1.0), horizontal.Start);
            var right = new Segment2D(horizontal.End, new Point2D(10.0, -1.0));
            var horizontalOutline = new OutlineFeature2D();
            horizontalOutline.Segments.AddRange(new[] { left, horizontal, right });
            horizontalOutline.Chamfers.Add(new ChamferFeature2D { StartPoint = left.Start, EndPoint = left.End, SourceSegment = left });
            horizontalOutline.Chamfers.Add(new ChamferFeature2D { StartPoint = right.Start, EndPoint = right.End, SourceSegment = right });

            Assert(OutlineGeometryQuery.IsAxisSegmentBetweenTwoChamfers(horizontalOutline, horizontal, tolerance),
                "horizontal line between two chamfers must be recognized");
            horizontalOutline.Chamfers.RemoveAt(1);
            Assert(!OutlineGeometryQuery.IsAxisSegmentBetweenTwoChamfers(horizontalOutline, horizontal, tolerance),
                "both chamfers are required");
        }

        private static void ChamferedOutlineKeepsOverallDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateTopRightChamferedOutline();
            new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(outline.Chamfers.Count == 1, "expected one chamfer");
            AssertHasDimension(plan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0, "chamfer overall width");
            AssertHasDimension(plan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 50.0, "chamfer overall height");
        }

        private static void MultipleChamfersKeepOverallDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };
            AddSegment(outline, new Point2D(10.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 40.0), "right");
            AddSegment(outline, new Point2D(100.0, 40.0), new Point2D(90.0, 50.0), "top-right-chamfer");
            AddSegment(outline, new Point2D(90.0, 50.0), new Point2D(0.0, 50.0), "top");
            AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 10.0), "left");
            AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(10.0, 0.0), "bottom-left-chamfer");
            new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(outline.Chamfers.Count == 2, "expected two recognized outer chamfers");
            Assert(plan.Dimensions.Count(d => d.Kind == DimensionKind.OverallWidth) == 1,
                "multiple chamfers must retain exactly one overall width");
            Assert(plan.Dimensions.Count(d => d.Kind == DimensionKind.OverallHeight) == 1,
                "multiple chamfers must retain exactly one overall height");
            AssertHasDimension(plan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0, "multiple-chamfer overall width");
            AssertHasDimension(plan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 50.0, "multiple-chamfer overall height");
        }

        private static void MirroredChamferPreservesRecognition()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = -100.0,
                MinY = 25.0,
                MaxX = 0.0,
                MaxY = 75.0
            };
            AddSegment(outline, new Point2D(-100.0, 25.0), new Point2D(0.0, 25.0), "bottom");
            AddSegment(outline, new Point2D(0.0, 25.0), new Point2D(0.0, 75.0), "right");
            AddSegment(outline, new Point2D(0.0, 75.0), new Point2D(-90.0, 75.0), "top");
            AddSegment(outline, new Point2D(-90.0, 75.0), new Point2D(-100.0, 65.0), "mirrored-chamfer");
            AddSegment(outline, new Point2D(-100.0, 65.0), new Point2D(-100.0, 25.0), "left");
            new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(outline.Chamfers.Count == 1, "mirroring must not change chamfer recognition");
            AssertHasDimension(plan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0, "mirrored overall width");
            AssertHasDimension(plan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 50.0, "mirrored overall height");
        }

        private static void FilletedOutlineKeepsOverallDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var segments = new[]
            {
                new Segment2D(new Point2D(0.0, 0.0), new Point2D(100.0, 0.0)) { SourceKey = "bottom" },
                new Segment2D(new Point2D(100.0, 0.0), new Point2D(100.0, 40.0)) { SourceKey = "right" },
                new Segment2D(new Point2D(90.0, 50.0), new Point2D(0.0, 50.0)) { SourceKey = "top" },
                new Segment2D(new Point2D(0.0, 50.0), new Point2D(0.0, 0.0)) { SourceKey = "left" }
            };
            var arcs = new[]
            {
                new Arc2D
                {
                    Start = new Point2D(100.0, 40.0),
                    End = new Point2D(90.0, 50.0),
                    Center = new Point2D(90.0, 40.0),
                    Radius = 10.0,
                    Bulge = Math.Tan(Math.PI / 8.0),
                    SourceKey = "top-right-fillet"
                }
            };
            var outline = new FeatureRecognizer2D(config).RecognizeOutlineFromSegments(segments, arcs);
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(outline.Fillets.Count == 1, "expected one connected outline fillet");
            AssertHasDimension(plan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0, "filleted overall width");
            AssertHasDimension(plan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 50.0, "filleted overall height");
        }

        private static void ChamferSuppressesAdjacentLocalLinearDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateTopRightChamferedOutline();
            new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(!plan.Dimensions.Any(d => d.Kind == DimensionKind.Normal && d.SourceKey == "right-local"),
                "right vertical local dimension adjacent to chamfer should be suppressed");
            Assert(!plan.Dimensions.Any(d => d.Kind == DimensionKind.Normal && d.SourceKey == "top-local"),
                "top horizontal local dimension adjacent to chamfer should be suppressed");
        }

        private static void OverallDimensionsUseBoundaryGripPoints()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(0.0, 50.0), "left");
            AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(100.0, 50.0), "top");
            AddSegment(outline, new Point2D(100.0, 50.0), new Point2D(100.0, 20.0), "right");
            AddSegment(outline, new Point2D(100.0, 20.0), new Point2D(80.0, 0.0), "slope-right");
            AddSegment(outline, new Point2D(80.0, 0.0), new Point2D(20.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(0.0, 10.0), "slope-left");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
            var width = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallWidth);
            var height = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallHeight);

            Assert(Math.Abs(width.FirstPoint.X - 0.0) <= 0.001 && Math.Abs(width.FirstPoint.Y - 10.0) <= 0.001,
                "overall width should use lowest left-boundary vertex");
            Assert(Math.Abs(width.SecondPoint.X - 100.0) <= 0.001 && Math.Abs(width.SecondPoint.Y - 20.0) <= 0.001,
                "overall width should use lowest right-boundary vertex");
            Assert(Math.Abs(height.FirstPoint.X - 20.0) <= 0.001 && Math.Abs(height.FirstPoint.Y - 0.0) <= 0.001,
                "overall height should use leftmost bottom-boundary vertex");
            Assert(Math.Abs(height.SecondPoint.X - 0.0) <= 0.001 && Math.Abs(height.SecondPoint.Y - 50.0) <= 0.001,
                "overall height should use leftmost top-boundary vertex");
        }

		private static void ArcEnvelopeUsesRealInteriorGripPoint()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 100.0,
				MinY = 200.0,
				MaxX = 140.0,
				MaxY = 240.0
			};
			AddSegment(outline, new Point2D(100.0, 200.0), new Point2D(140.0, 200.0), "bottom");
			AddSegment(outline, new Point2D(140.0, 200.0), new Point2D(140.0, 220.0), "right");
			AddSegment(outline, new Point2D(100.0, 220.0), new Point2D(100.0, 200.0), "left");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(140.0, 220.0),
				End = new Point2D(100.0, 220.0),
				Center = new Point2D(120.0, 220.0),
				Radius = 20.0,
				Bulge = 1.0,
				SourceKey = "top-arc"
			});

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var height = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallHeight);
			var topGrip = height.FirstPoint.Y > height.SecondPoint.Y ? height.FirstPoint : height.SecondPoint;

			Assert(Math.Abs(topGrip.X - 120.0) <= 0.001 && Math.Abs(topGrip.Y - 240.0) <= 0.001,
				"overall height should use the real interior arc extremum");
			Assert(OutlineGeometryQuery.IsPointOnBoundary(topGrip, outline, config.GeometryTolerance),
				"arc extremum should be verified on the real outline arc");
		}

        private static void NegativeBulgeArcUsesRealInteriorGripPoint()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 100.0,
                MinY = 200.0,
                MaxX = 140.0,
                MaxY = 240.0
            };
            AddSegment(outline, new Point2D(100.0, 200.0), new Point2D(140.0, 200.0), "bottom");
            AddSegment(outline, new Point2D(140.0, 200.0), new Point2D(140.0, 220.0), "right");
            AddSegment(outline, new Point2D(100.0, 220.0), new Point2D(100.0, 200.0), "left");
            outline.Arcs.Add(new Arc2D
            {
                Start = new Point2D(100.0, 220.0),
                End = new Point2D(140.0, 220.0),
                Center = new Point2D(120.0, 220.0),
                Radius = 20.0,
                Bulge = -1.0,
                SourceKey = "clockwise-top-arc"
            });

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
            var height = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallHeight);
            var topGrip = height.FirstPoint.Y > height.SecondPoint.Y ? height.FirstPoint : height.SecondPoint;

            Assert(Math.Abs(topGrip.X - 120.0) <= 0.001 && Math.Abs(topGrip.Y - 240.0) <= 0.001,
                "negative bulge must preserve the real clockwise arc extremum");
            Assert(OutlineGeometryQuery.IsPointOnBoundary(topGrip, outline, config.GeometryTolerance),
                "negative-bulge extremum must lie on the real arc");
        }

		private static void DisconnectedOutlineCanUseVerifiedRealGrips()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 100.0,
				MinY = 100.0,
				MaxX = 200.0,
				MaxY = 200.0
			};
			AddSegment(outline, new Point2D(100.0, 110.0), new Point2D(100.0, 180.0), "left-fragment");
			AddSegment(outline, new Point2D(200.0, 120.0), new Point2D(200.0, 190.0), "right-fragment");
			AddSegment(outline, new Point2D(120.0, 100.0), new Point2D(180.0, 100.0), "bottom-fragment");
			AddSegment(outline, new Point2D(110.0, 200.0), new Point2D(190.0, 200.0), "top-fragment");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Count(d => d.Kind == DimensionKind.OverallWidth) == 1,
				"verified disconnected geometry should retain one overall width");
			Assert(plan.Dimensions.Count(d => d.Kind == DimensionKind.OverallHeight) == 1,
				"verified disconnected geometry should retain one overall height");
		}

        private static void TranslatedOutlinePreservesOverallSemantics()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangleAt(1000.0, -500.0, 120.0, 70.0);
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
            var width = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallWidth);
            var height = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallHeight);

            Assert(width.Side == DimensionSide.Bottom && Math.Abs(GetSpan(width) - 120.0) <= 0.001,
                "translated overall width must keep bottom-side full-envelope semantics");
            Assert(height.Side == DimensionSide.Left && Math.Abs(GetSpan(height) - 70.0) <= 0.001,
                "translated overall height must keep left-side full-envelope semantics");
            Assert(Math.Abs(Math.Min(width.FirstPoint.X, width.SecondPoint.X) - 1000.0) <= 0.001
                && Math.Abs(Math.Max(width.FirstPoint.X, width.SecondPoint.X) - 1120.0) <= 0.001,
                "translated overall width must use translated MinX and MaxX");
            Assert(OutlineGeometryQuery.IsPointOnBoundary(width.FirstPoint, outline, config.GeometryTolerance)
                && OutlineGeometryQuery.IsPointOnBoundary(width.SecondPoint, outline, config.GeometryTolerance)
                && OutlineGeometryQuery.IsPointOnBoundary(height.FirstPoint, outline, config.GeometryTolerance)
                && OutlineGeometryQuery.IsPointOnBoundary(height.SecondPoint, outline, config.GeometryTolerance),
                "translated overall grips must remain on real geometry");
        }

        private static void RotatedOutlineUsesRealEnvelopeGrips()
        {
            var config = DimensionRuleConfig.CreateDefault();
            double angle = Math.PI / 6.0;
            var localPoints = new[]
            {
                new Point2D(0.0, 0.0),
                new Point2D(100.0, 0.0),
                new Point2D(100.0, 50.0),
                new Point2D(0.0, 50.0)
            };
            var points = localPoints.Select(point => new Point2D(
                300.0 + point.X * Math.Cos(angle) - point.Y * Math.Sin(angle),
                -200.0 + point.X * Math.Sin(angle) + point.Y * Math.Cos(angle))).ToArray();
            var outline = new FeatureRecognizer2D(config).RecognizeOutlineFromClosedPath(points);
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
            var width = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallWidth);
            var height = plan.Dimensions.Single(d => d.Kind == DimensionKind.OverallHeight);

            Assert(Math.Abs(plan.CoordinateFrame.Angle - angle) <= 0.001,
                "rotated outline must infer its local principal frame");
            Assert(Math.Abs(GetSpan(width) - 100.0) <= 0.001,
                "rotated overall width must use the local-frame span");
            Assert(Math.Abs(GetSpan(height) - 50.0) <= 0.001,
                "rotated overall height must use the local-frame span");
            Assert(OutlineGeometryQuery.IsPointOnBoundary(plan.CoordinateFrame.ToWorld(width.FirstPoint), outline, config.GeometryTolerance)
                && OutlineGeometryQuery.IsPointOnBoundary(plan.CoordinateFrame.ToWorld(width.SecondPoint), outline, config.GeometryTolerance)
                && OutlineGeometryQuery.IsPointOnBoundary(plan.CoordinateFrame.ToWorld(height.FirstPoint), outline, config.GeometryTolerance)
                && OutlineGeometryQuery.IsPointOnBoundary(plan.CoordinateFrame.ToWorld(height.SecondPoint), outline, config.GeometryTolerance),
                "rotated overall grips must transform back to actual WCS geometry");
        }

        private static void DuplicateSegmentsAreSuppressedWithDiagnostic()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(100.0, 50.0);
            AddSegment(outline, new Point2D(40.0, 10.0), new Point2D(40.0, 30.0), "duplicate-a");
            AddSegment(outline, new Point2D(40.0, 10.0), new Point2D(40.0, 30.0), "duplicate-b");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
            var matching = plan.Dimensions.Where(d => d.Orientation == DimensionOrientation.Vertical
                && Math.Abs(Math.Min(d.FirstPoint.Y, d.SecondPoint.Y) - 10.0) <= 0.001
                && Math.Abs(Math.Max(d.FirstPoint.Y, d.SecondPoint.Y) - 30.0) <= 0.001).ToList();

            Assert(matching.Count == 1, "overlapping duplicate segments must emit only one measured dimension");
            var suppressed = plan.Diagnostics.DimensionCandidates.Single(candidate => candidate.IsSuppressed
                && candidate.SuppressedReason == "DuplicateMeasuredDimension"
                && (candidate.SourceFeatureId == "duplicate-a" || candidate.SourceFeatureId == "duplicate-b"));
            Assert(!suppressed.IsSelected && suppressed.DecisionStatus == "Suppressed"
                && suppressed.DecisionReason == "DuplicateMeasuredDimension",
                "duplicate suppression must retain an explicit diagnostic decision");
            Assert(Math.Abs(suppressed.MeasurementMinimum - 10.0) <= 0.001
                && Math.Abs(suppressed.MeasurementMaximum - 30.0) <= 0.001,
                "suppressed diagnostic must preserve its measured interval");
            var finalWidth = plan.Diagnostics.FinalDimensions.Single(candidate => candidate.Kind == DimensionKind.OverallWidth.ToString());
            var finalHeight = plan.Diagnostics.FinalDimensions.Single(candidate => candidate.Kind == DimensionKind.OverallHeight.ToString());
            Assert(finalWidth.IsSelected && finalHeight.IsSelected
                && finalWidth.DecisionStatus == "Selected" && finalHeight.DecisionStatus == "Selected"
                && finalWidth.DecisionReason == "RequiredOverallDimension"
                && finalHeight.DecisionReason == "RequiredOverallDimension",
                "diagnostic final dimensions must retain exactly one width and height overall");
            Assert(plan.Diagnostics.DimensionCandidates.Where(candidate => !candidate.IsSuppressed)
                .All(candidate => candidate.IsSelected && candidate.DecisionStatus == "Selected" && !string.IsNullOrEmpty(candidate.DecisionReason)),
                "every unsuppressed candidate must have an explicit selected decision");
        }

        private static void ZeroAndMicroSegmentsDoNotEmitDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(100.0, 50.0);
            AddSegment(outline, new Point2D(10.0, 10.0), new Point2D(10.0, 10.0), "zero-length");
            AddSegment(outline, new Point2D(20.0, 10.0), new Point2D(20.0, 10.0005), "micro-length");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(!plan.Dimensions.Any(d => d.SourceKey == "zero-length" || d.SourceKey == "micro-length"),
                "zero and sub-tolerance segments must not emit dimensions");
            Assert(plan.Dimensions.All(d => GetSpan(d) > config.GeometryTolerance),
                "final dimension plan must not contain zero or sub-tolerance dimensions");
        }

        private static void GeometryToleranceControlsMicroSegments()
        {
            var config = DimensionRuleConfig.CreateDefault();
            config.GeometryTolerance = 0.01;
            var outline = CreateRectangle(100.0, 50.0);
            AddSegment(outline, new Point2D(20.0, 10.0), new Point2D(20.0, 10.005), "below-tolerance");
            AddSegment(outline, new Point2D(30.0, 10.0), new Point2D(30.0, 10.02), "above-tolerance");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(!plan.Dimensions.Any(d => d.SourceKey == "below-tolerance"),
                "segment below configured precision must be ignored");
            Assert(plan.Dimensions.Any(d => d.SourceKey == "above-tolerance"),
                "segment above configured precision must remain dimensionable");
        }

		private static void ConcaveHoleDatumUsesRealOutlineIntersections()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 100.0,
				MinY = 100.0,
				MaxX = 200.0,
				MaxY = 200.0
			};
			AddSegment(outline, new Point2D(100.0, 100.0), new Point2D(200.0, 100.0), "bottom");
			AddSegment(outline, new Point2D(200.0, 100.0), new Point2D(200.0, 200.0), "right");
			AddSegment(outline, new Point2D(200.0, 200.0), new Point2D(160.0, 200.0), "top");
			AddSegment(outline, new Point2D(160.0, 200.0), new Point2D(160.0, 140.0), "inner-right");
			AddSegment(outline, new Point2D(160.0, 140.0), new Point2D(100.0, 140.0), "shoulder");
			AddSegment(outline, new Point2D(100.0, 140.0), new Point2D(100.0, 100.0), "left");
			var datum = Datum2D.FromOutline(outline);
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				CreateHole(180.0, 170.0, 8.0, HoleKind2D.Normal)
			});
			var horizontal = plan.Dimensions.Single(d => d.DebugRole == "HoleDatumX");
			var vertical = plan.Dimensions.Single(d => d.DebugRole == "HoleDatumY");

			Assert(Math.Abs(horizontal.FirstPoint.X - 100.0) <= 0.001 && Math.Abs(horizontal.FirstPoint.Y - 140.0) <= 0.001,
				"horizontal datum should preserve its X datum and use the nearest real outline point on that datum line");
			Assert(Math.Abs(vertical.FirstPoint.X - 180.0) <= 0.001 && Math.Abs(vertical.FirstPoint.Y - 100.0) <= 0.001,
				"vertical datum should preserve its Y datum and use the real bottom outline intersection");
			Assert(Math.Abs(horizontal.SecondPoint.X - horizontal.FirstPoint.X - 80.0) <= 0.001,
				"real grip correction must not change the horizontal datum measurement");
			Assert(horizontal.FirstPointMustLieOnOutline && vertical.FirstPointMustLieOnOutline,
				"outline-referenced hole dimensions should carry post-validation metadata");
			Assert(vertical.PreservePreferredSide,
				"vertical datum-to-hole location must stay on the nearest real outline side");
		}

		private static void OverallWinsDuplicatePreferenceEvenAgainstTolerance()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			var overall = new DimensionDeduplicationItem
			{
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(100.0, 0.0),
				Kind = DimensionKind.OverallWidth,
				ForceOuterLevel = true
			};
			var functional = new DimensionDeduplicationItem
			{
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(100.0, 0.0),
				Kind = DimensionKind.DatumHoleLocationX,
				OverrideText = config.DatumHoleLocationToleranceText
			};

			Assert(rules.CompareDuplicatePreference(overall, functional) > 0,
				"overall width must outrank a toleranced functional dimension");
			Assert(rules.CompareDuplicatePreference(functional, overall) < 0,
				"duplicate preference must be symmetric for overall protection");
		}

		private static void LocalGeometryOnOverallEnvelopeSuppressesOnlyEligibleRoles()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 50.0
			};
			var plan = new DimensionPlan();
			var suppressed = new[]
			{
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(10.0, 50.0), new Point2D(30.0, 50.0), "TopStructWidth"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Bottom,
					new Point2D(30.0, 0.0), new Point2D(60.0, 0.0), "BottomStructWidth"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Vertical, DimensionSide.Left,
					new Point2D(0.0, 10.0), new Point2D(0.0, 30.0), "LeftStructHeight"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Vertical, DimensionSide.Right,
					new Point2D(100.0, 20.0), new Point2D(100.0, 45.0), "RightStructHeight"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(70.0, 0.0), new Point2D(90.0, 0.0), "TopChamferedStepWidth"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Vertical, DimensionSide.Right,
					new Point2D(100.0, 0.0), new Point2D(100.0, 50.0), "RightChamferedStepHeight"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Bottom,
					new Point2D(5.0, 0.0), new Point2D(15.0, 0.0), "OutlineSegment")
			};
			foreach (PlannedDimension dimension in suppressed)
			{
				plan.Add(dimension);
			}
			var overallWidth = CreateTestDimension(DimensionKind.OverallWidth, DimensionOrientation.Horizontal, DimensionSide.Bottom,
				new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "OverallWidth");
			var overallHeight = CreateTestDimension(DimensionKind.OverallHeight, DimensionOrientation.Vertical, DimensionSide.Left,
				new Point2D(0.0, 0.0), new Point2D(0.0, 50.0), "OverallHeight");
			var internalStructure = CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Top,
				new Point2D(10.0, 40.0), new Point2D(30.0, 40.0), "TopStructWidth");
			var slotDatum = CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Bottom,
				new Point2D(0.0, 0.0), new Point2D(20.0, 0.0), "SlotDatumH");
			var functional = CreateTestDimension(DimensionKind.HoleLocation, DimensionOrientation.Horizontal, DimensionSide.Bottom,
				new Point2D(20.0, 0.0), new Point2D(40.0, 0.0), "FunctionalHole");
			foreach (PlannedDimension dimension in new[] { overallWidth, overallHeight, internalStructure, slotDatum, functional })
			{
				plan.Add(dimension);
			}

			planner.SuppressLocalGeometryOnOverallEnvelope(plan, outline);

			Assert(suppressed.All(d => !plan.Dimensions.Contains(d)),
				"all four-axis local geometry dimensions on the outer envelope must be suppressed");
			Assert(suppressed.All(d => plan.Diagnostics.DimensionCandidates.Any(c =>
					c.Id == d.DiagnosticId && c.SuppressedReason == "LocalGeometryOnOverallEnvelope")),
				"suppressed envelope-local candidates must record LocalGeometryOnOverallEnvelope");
			Assert(plan.Dimensions.Contains(overallWidth) && plan.Dimensions.Contains(overallHeight)
					&& plan.Dimensions.Contains(internalStructure) && plan.Dimensions.Contains(slotDatum)
					&& plan.Dimensions.Contains(functional),
				"overall, internal structure, slot datum and functional dimensions must remain");
		}

		private static void OverallRemainsOutermostAfterLayoutAlignment()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem
				{
					FirstPoint = new Point2D(0.0, 0.0),
					SecondPoint = new Point2D(100.0, 0.0),
					Span = 100.0,
					Kind = DimensionKind.OverallWidth,
					ForceOuterLevel = true
				},
				new DimensionLayoutItem
				{
					FirstPoint = new Point2D(-25.0, -100.0),
					SecondPoint = new Point2D(125.0, -100.0),
					Span = 150.0,
					Kind = DimensionKind.HoleLocation,
					PreferFeatureLocalPlacement = true
				}
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Bottom, outline, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var overall = placements.Single(item => item.Index == 0);
			var local = placements.Single(item => item.Index == 1);

			Assert(overall.Level > local.Level, "overall dimension must remain on the outermost stacking level");
			double overallCoordinate = new DimensionLayoutRules(config).GetDimLineCoordinate(dimensions[0], DimensionSide.Bottom, outline, overall.Offset);
			double localCoordinate = new DimensionLayoutRules(config).GetDimLineCoordinate(dimensions[1], DimensionSide.Bottom, outline, local.Offset);
			Assert(overallCoordinate < localCoordinate, "overall dimension must remain physically outside feature-local dimensions");
		}

		private static void OverallCompactsToOnePhysicalSpacing()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var dimensions = new List<DimensionLayoutItem>();
			for (int i = 0; i < 4; i++)
			{
				dimensions.Add(new DimensionLayoutItem
				{
					FirstPoint = new Point2D(0.0, i * 5.0),
					SecondPoint = new Point2D(50.0, i * 5.0),
					Span = 50.0,
					Kind = DimensionKind.HoleLocation,
					PreferFeatureLocalPlacement = true
				});
			}
			dimensions.Add(new DimensionLayoutItem
			{
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(100.0, 0.0),
				Span = 100.0,
				Kind = DimensionKind.OverallWidth,
				ForceOuterLevel = true
			});
			var rules = new DimensionLayoutRules(config);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Bottom, outline, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var overall = placements.Single(item => item.Index == 4);
			var otherCoordinates = placements
				.Where(item => item.Index != 4)
				.Select(item => item.DimLineCoordinateOverride ?? rules.GetDimLineCoordinate(dimensions[item.Index], DimensionSide.Bottom, outline, item.Offset))
				.ToList();
			double overallCoordinate = rules.GetDimLineCoordinate(dimensions[4], DimensionSide.Bottom, outline, overall.Offset);

			Assert(Math.Abs((otherCoordinates.Min() - overallCoordinate) - 5.0) <= config.GeometryTolerance,
				"overall dimensions must compact to exactly one physical stacking interval beyond the actual outermost dimension");
		}

		private static void EffectiveSpanControlsHorizontalStacking()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.OverallWidth, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(100.0, 0.0), Span = 100.0, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(10.0, 0.0), Span = 10.0, ReadingLevel = DimensionReadingLevel.DatumTransfer },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(20.0, 0.0), Span = 20.0, ReadingLevel = DimensionReadingLevel.IntraGroup },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(80.0, 0.0), Span = 80.0, ReadingLevel = DimensionReadingLevel.LocalSpacing }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Bottom, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);

			Assert(placements.Single(item => item.Index == 1).Level < placements.Single(item => item.Index == 2).Level,
				"the shorter horizontal datum transfer must stay inside the longer intra-group span");
			Assert(placements.Single(item => item.Index == 2).Level < placements.Single(item => item.Index == 3).Level,
				"effective span must outrank semantic reading level for non-equal horizontal spans");
			Assert(placements.Single(item => item.Index == 3).Level < placements.Single(item => item.Index == 0).Level,
				"the forced horizontal overall dimension must remain outermost");
		}

		private static void SharedArrowEndpointUsesStrictSpanOrder()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(200.0, 100.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(0.0, 100.0), SecondPoint = new Point2D(73.0, 100.0), Span = 73.0, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "TopStructWidth" },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(73.0, 100.0), SecondPoint = new Point2D(160.554, 100.0), Span = 87.554, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "TopStructWidth" }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Top, outline, 2.5, 1.0, 5.0, 6.5, isHorizontal: true).ToDictionary(item => item.Index);

			Assert(placements[0].Level < placements[1].Level,
				$"adjacent dimensions that share an arrow endpoint must keep the shorter span physically inside the longer span (levels {placements[0].Level}/{placements[1].Level})");
			Assert(placements.Values.All(placement => placement.PhysicalOrderValidated),
				"shared-endpoint span ordering must pass physical-order validation");
		}

		private static void StructureAlignmentKeyAlignsAdjacentSegmentsOnSameLevel()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(200.0, 100.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(0.0, 100.0), SecondPoint = new Point2D(73.0, 100.0), Span = 73.0, AlignmentKey = "Structure:T:H", AlignmentPriority = 70, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "TopStructWidth" },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(73.0, 100.0), SecondPoint = new Point2D(160.554, 100.0), Span = 87.554, AlignmentKey = "Structure:T:H", AlignmentPriority = 70, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "TopStructWidth" }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Top, outline, 2.5, 1.0, 5.0, 6.5, isHorizontal: true).ToDictionary(item => item.Index);

			Assert(placements[0].Level == placements[1].Level,
				$"adjacent structure segments that share an alignment key must stay on the same stacking level (levels {placements[0].Level}/{placements[1].Level})");
			Assert(placements[0].LayoutBlockType == "RootedAlignmentLane" && placements[1].LayoutBlockType == "RootedAlignmentLane",
				"structure alignment key members must form a rooted alignment lane");
			Assert(placements[0].LayoutBlockId == placements[1].LayoutBlockId,
				"adjacent structure segments must share one rooted layout block");
		}

		/// <summary>
		/// U-slot edge location (SlotChainV 10) + inter-slot center distance (SlotChainV 15)
		/// are one continuous locating chain and must share AlignmentKey / same stacking level.
		/// </summary>
		private static void SlotChainAlignmentKeyAlignsEdgeLocationAndCenterDistance()
		{
			var config = DimensionRuleConfig.CreateDefault();
			// Layout-only: same key as planner will emit for a left vertical slot chain.
			var outline = CreateRectangle(100.0, 50.0);
			const string slotChainKey = "SlotChain:L:V:50";
			var dimensions = new[]
			{
				// Edge → first U-slot (SCV2 style)
				new DimensionLayoutItem
				{
					Kind = DimensionKind.Normal,
					FirstPoint = new Point2D(50.0, 0.0),
					SecondPoint = new Point2D(50.0, 10.0),
					Span = 10.0,
					AlignmentKey = slotChainKey,
					AlignmentPriority = 80,
					ReadingLevel = DimensionReadingLevel.LocalSpacing,
					SourceFeatureId = "SlotChainV"
				},
				// First U-slot → second U-slot center distance (SCV1 style)
				new DimensionLayoutItem
				{
					Kind = DimensionKind.Normal,
					FirstPoint = new Point2D(50.0, 10.0),
					SecondPoint = new Point2D(50.0, 25.0),
					Span = 15.0,
					AlignmentKey = slotChainKey,
					AlignmentPriority = 80,
					ReadingLevel = DimensionReadingLevel.LocalSpacing,
					SourceFeatureId = "SlotChainV"
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.OverallHeight,
					FirstPoint = new Point2D(0.0, 0.0),
					SecondPoint = new Point2D(0.0, 50.0),
					Span = 50.0,
					ForceOuterLevel = true,
					ReadingLevel = DimensionReadingLevel.Overall,
					SourceFeatureId = "OverallHeight"
				}
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Left, outline, 2.5, 1.0, 5.0, 5.0, isHorizontal: false).ToDictionary(item => item.Index);

			Assert(placements[0].Level == placements[1].Level,
				$"slot edge location and inter-slot center distance must share one stacking level (levels {placements[0].Level}/{placements[1].Level})");
			Assert(placements[0].LayoutBlockType == "RootedAlignmentLane" && placements[1].LayoutBlockType == "RootedAlignmentLane",
				"slot chain members must form a rooted alignment lane");
			Assert(placements[0].LayoutBlockId == placements[1].LayoutBlockId,
				"slot chain members must share one rooted layout block");
			Assert(placements[2].Level > placements[0].Level,
				"overall height must remain outside the slot chain lane");

			// Planner emits the same key for continuous vertical slot anchors.
			var outline2 = CreateRectangle(100.0, 50.0);
			var datum = Datum2D.FromOutline(outline2);
			var slots = new[]
			{
				new SlotFeature2D
				{
					GroupId = "U1",
					FirstCenter = new Point2D(50.0, 10.0),
					SecondCenter = new Point2D(70.0, 10.0),
					Radius = 5.0,
					CenterDistance = 20.0
				},
				new SlotFeature2D
				{
					GroupId = "U2",
					FirstCenter = new Point2D(50.0, 25.0),
					SecondCenter = new Point2D(70.0, 25.0),
					Radius = 5.0,
					CenterDistance = 20.0
				}
			};
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline2, datum, new HoleFeature2D[0], slots);
			var chain = plan.Dimensions.Where(d => d.DebugRole == "SlotChainV").ToList();
			Assert(chain.Count >= 2, "expected vertical slot chain segments (edge location + center distance)");
			Assert(chain.All(d => !string.IsNullOrEmpty(d.AlignmentKey) && d.AlignmentKey.StartsWith("SlotChain:L:V:", StringComparison.Ordinal)),
				"SlotChainV members must carry SlotChain:L:V alignment keys");
			Assert(chain.Select(d => d.AlignmentKey).Distinct().Count() == 1,
				"edge location and inter-slot distance on one column must share one AlignmentKey");
			Assert(chain.All(d => d.AlignmentPriority == 80),
				"slot chain alignment priority must be 80");
		}

		private static void OutlineSegmentsThatPartitionOverallAreSuppressed()
		{
			// Collinear bottom edge split into 25 + 232 = overall 257 (repro of ASD4 bottom).
			// Raw OutlineSegment pair restates overall and must not remain selected.
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 257.0,
				MaxY = 20.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(25.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(257.0, 0.0), "bottom-right");
			AddSegment(outline, new Point2D(257.0, 0.0), new Point2D(257.0, 20.0), "right");
			AddSegment(outline, new Point2D(257.0, 20.0), new Point2D(0.0, 20.0), "top");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 257.0) <= config.GeometryTolerance),
				"overall width 257 must remain");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment"
					&& d.Side == DimensionSide.Bottom),
				"bottom OutlineSegment dims that partition overall must not remain selected");
			var suppressedBottom = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "OutlineSegment"
					&& c.PlacementSide == DimensionSide.Bottom.ToString()
					&& c.IsSuppressed)
				.ToList();
			Assert(suppressedBottom.Count >= 2
					&& suppressedBottom.Any(c => Math.Abs(c.Value - 25.0) <= config.GeometryTolerance)
					&& suppressedBottom.Any(c => Math.Abs(c.Value - 232.0) <= config.GeometryTolerance),
				"both 25 and 232 OutlineSegments must be suppressed");
			Assert(suppressedBottom.All(c => c.SuppressedReason == "LocalGeometryOnOverallEnvelope"),
				"partition OutlineSegments must record the higher-priority outer-envelope reason");
		}

		/// <summary>
		/// Repro GEN|OutlineSegment1/2/3|GB|B|L*: bottom collinear 9+11+71 = overall 91.
		/// Pairwise sums are not overall, but the 3-piece chain covers overall and must suppress all.
		/// </summary>
		private static void ThreeOutlineSegmentsThatPartitionOverallAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 91.0,
				MaxY = 20.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(9.0, 0.0), "bottom-a");
			AddSegment(outline, new Point2D(9.0, 0.0), new Point2D(20.0, 0.0), "bottom-b");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(91.0, 0.0), "bottom-c");
			AddSegment(outline, new Point2D(91.0, 0.0), new Point2D(91.0, 20.0), "right");
			AddSegment(outline, new Point2D(91.0, 20.0), new Point2D(0.0, 20.0), "top");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 91.0) <= config.GeometryTolerance),
				"overall width 91 must remain");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment" && d.Side == DimensionSide.Bottom),
				"bottom OutlineSegments 9+11+71 that partition overall must not remain selected");
			var suppressedBottom = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "OutlineSegment"
					&& c.PlacementSide == DimensionSide.Bottom.ToString()
					&& c.IsSuppressed
					&& c.SuppressedReason == "LocalGeometryOnOverallEnvelope")
				.ToList();
			Assert(suppressedBottom.Count >= 3
					&& suppressedBottom.Any(c => Math.Abs(c.Value - 9.0) <= config.GeometryTolerance)
					&& suppressedBottom.Any(c => Math.Abs(c.Value - 11.0) <= config.GeometryTolerance)
					&& suppressedBottom.Any(c => Math.Abs(c.Value - 71.0) <= config.GeometryTolerance),
				"all three OutlineSegments 9, 11, 71 must record the outer-envelope suppression reason");

			// Helper: multi-interval chain detection.
			var rules = new DimensionDeduplicationRules(config);
			var chain = new[]
			{
				Tuple.Create(0.0, 9.0),
				Tuple.Create(9.0, 20.0),
				Tuple.Create(20.0, 91.0)
			};
			Assert(rules.FormsCompleteOverallPartitionChain(chain, 0.0, 91.0),
				"9+11+71 intervals must form a complete overall partition chain");
			Assert(!rules.FormsCompleteOverallPartitionChain(
					new[] { Tuple.Create(0.0, 9.0), Tuple.Create(9.0, 20.0) }, 0.0, 91.0),
				"partial chain that does not reach overall max must not be treated as partition");
		}

		/// <summary>
		/// Option 1: outer-envelope OutlineSegment fragment (e.g. right-end 10 on overall 75)
		/// must suppress when Overall already exists — even if it does not complete a partition chain
		/// (middle piece removed by chamfer / left gap).
		/// </summary>
		private static void OutlineSegmentOnOverallEnvelopeIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 75.0,
				MaxY = 40.0
			};
			// Bottom: short left (chamfer-like 5), long mid 60, right tip 10 — overall 75.
			// Even if mid is not a complete partition partner, right tip 10 lies on envelope.
			AddSegment(outline, new Point2D(0.0, 5.0), new Point2D(5.0, 0.0), "chamfer-bl");
			AddSegment(outline, new Point2D(5.0, 0.0), new Point2D(65.0, 0.0), "bottom-mid");
			AddSegment(outline, new Point2D(65.0, 0.0), new Point2D(75.0, 0.0), "bottom-right-tip");
			AddSegment(outline, new Point2D(75.0, 0.0), new Point2D(75.0, 40.0), "right");
			AddSegment(outline, new Point2D(75.0, 40.0), new Point2D(0.0, 40.0), "top");
			AddSegment(outline, new Point2D(0.0, 40.0), new Point2D(0.0, 5.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 75.0) <= config.GeometryTolerance),
				"overall width 75 must remain");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment"
					&& d.Orientation == DimensionOrientation.Horizontal
					&& d.Side == DimensionSide.Bottom
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 10.0) <= config.GeometryTolerance),
				"bottom envelope OutlineSegment tip 10 must not remain selected when Overall exists");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "OutlineSegment"
					&& c.PlacementSide == DimensionSide.Bottom.ToString()
					&& Math.Abs(c.Value - 10.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& (c.SuppressedReason == "LocalGeometryOnOverallEnvelope"
						|| c.SuppressedReason == "OutlineSegmentOnOverallEnvelope"
						|| c.SuppressedReason == "OutlineSegmentOverallPartition"
						|| c.SuppressedReason == "SuppressedByCornerFeature")),
				"bottom envelope OutlineSegment 10 must be suppressed (envelope/partition/corner)");
		}

		/// <summary>
		/// Same geometry as envelope OS tip 10: BottomStructWidth 10 must also suppress
		/// (duplicate candidate of the outer-envelope fragment).
		/// </summary>
		private static void StructureDuplicateOfEnvelopeOutlineSegmentIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 75.0,
				MaxY = 40.0
			};
			AddSegment(outline, new Point2D(0.0, 5.0), new Point2D(5.0, 0.0), "chamfer-bl");
			AddSegment(outline, new Point2D(5.0, 0.0), new Point2D(65.0, 0.0), "bottom-mid");
			AddSegment(outline, new Point2D(65.0, 0.0), new Point2D(75.0, 0.0), "bottom-right-tip");
			AddSegment(outline, new Point2D(75.0, 0.0), new Point2D(75.0, 40.0), "right");
			AddSegment(outline, new Point2D(75.0, 40.0), new Point2D(0.0, 40.0), "top");
			AddSegment(outline, new Point2D(0.0, 40.0), new Point2D(0.0, 5.0), "left");
			// Full-height shoulder at tip start so BottomStructWidth 10 is also generated.
			AddSegment(outline, new Point2D(65.0, 0.0), new Point2D(65.0, 40.0), "shoulder-tip");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(!plan.Dimensions.Any(d =>
					(d.DebugRole == "BottomStructWidth" || d.DebugRole == "TopStructWidth")
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 10.0) <= config.GeometryTolerance),
				"structure width 10 that duplicates envelope OutlineSegment tip must not remain selected");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					(c.DebugRole == "BottomStructWidth" || c.DebugRole == "TopStructWidth")
					&& Math.Abs(c.Value - 10.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& (c.SuppressedReason == "LocalGeometryOnOverallEnvelope"
						|| c.SuppressedReason == "StructureDuplicateOfEnvelopeOutlineSegment"
						|| c.SuppressedReason == "StructureOverallPartition"
						|| c.SuppressedReason == "MirroredDuplicate")),
				"structure width 10 must be suppressed as envelope-OS duplicate (or equivalent)");
		}

		/// <summary>
		/// Positive gate: Bottom envelope OS [65,75]@Y=0 + collinear same-side BottomStructWidth
		/// [65,75]@Y=0 — structure is a true tip duplicate and must be co-suppressed.
		/// Isolated unit call avoids other suppress paths so the envelope co-delete rule is explicit.
		/// </summary>
		private static void EnvelopeStructureSameSideCollinearDuplicateIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			var overallWidth = new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "OverallWidth"
			};
			var overallHeight = new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 40.0),
				DebugRole = "OverallHeight"
			};
			var envelopeOs = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(65.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "OutlineSegment"
			};
			var structure = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(65.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "BottomStructWidth"
			};
			plan.Add(overallWidth);
			plan.Add(overallHeight);
			plan.Add(envelopeOs);
			plan.Add(structure);

			planner.SuppressOutlineSegmentsOnOverallEnvelope(plan);

			Assert(plan.Dimensions.Contains(overallWidth), "overall width must remain");
			Assert(plan.Dimensions.Contains(overallHeight), "overall height must remain");
			Assert(!plan.Dimensions.Contains(envelopeOs),
				"bottom envelope OutlineSegment tip [65,75] must be suppressed");
			Assert(!plan.Dimensions.Contains(structure),
				"same-side collinear BottomStructWidth [65,75]@Y=0 must be co-suppressed as envelope OS duplicate");
		}

		/// <summary>
		/// Negative gate: Bottom envelope OS [65,75]@Y=0 + opposite/internal structure
		/// [65,75]@Y=35 (TopStructWidth) — same 1D interval only must NOT suppress structure.
		/// </summary>
		private static void StructureSameIntervalAsOppositeEnvelopeTipIsKept()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			var overallWidth = new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "OverallWidth"
			};
			var overallHeight = new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 40.0),
				DebugRole = "OverallHeight"
			};
			var envelopeOs = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(65.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "OutlineSegment"
			};
			var structure = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(65.0, 35.0),
				SecondPoint = new Point2D(75.0, 35.0),
				DebugRole = "TopStructWidth"
			};
			plan.Add(overallWidth);
			plan.Add(overallHeight);
			plan.Add(envelopeOs);
			plan.Add(structure);

			planner.SuppressOutlineSegmentsOnOverallEnvelope(plan);

			Assert(plan.Dimensions.Contains(overallWidth), "overall width must remain");
			Assert(!plan.Dimensions.Contains(envelopeOs),
				"bottom envelope OutlineSegment tip must still be suppressed");
			Assert(plan.Dimensions.Contains(structure),
				"TopStructWidth [65,75]@Y=35 must be kept — same X interval as bottom tip is not a geometric duplicate");
			Assert(plan.Diagnostics.DimensionCandidates
					.Where(c => c.DebugRole == "TopStructWidth" && Math.Abs(c.Value - 10.0) <= config.GeometryTolerance)
					.All(c => c.SuppressedReason != "StructureDuplicateOfEnvelopeOutlineSegment"),
				"opposite-edge structure must not be labeled StructureDuplicateOfEnvelopeOutlineSegment");
		}

		private static void MirroredEnvelopeStructureWidthsAreBothSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 90.54,
				MaxY = 20.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 20.0), "left");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(15.54, 20.0), "top-left");
			AddSegment(outline, new Point2D(15.54, 20.0), new Point2D(67.54, 20.0), "top-52");
			AddSegment(outline, new Point2D(67.54, 20.0), new Point2D(90.54, 20.0), "top-right");
			AddSegment(outline, new Point2D(90.54, 20.0), new Point2D(90.54, 0.0), "right");
			AddSegment(outline, new Point2D(90.54, 0.0), new Point2D(67.54, 0.0), "bottom-right");
			AddSegment(outline, new Point2D(67.54, 0.0), new Point2D(15.54, 0.0), "bottom-52");
			AddSegment(outline, new Point2D(15.54, 0.0), new Point2D(0.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(15.54, 0.0), new Point2D(15.54, 20.0), "internal-left");
			AddSegment(outline, new Point2D(67.54, 0.0), new Point2D(67.54, 20.0), "internal-right");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(!plan.Dimensions.Any(d =>
					(d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 52.0) <= config.GeometryTolerance),
				"mirrored top/bottom structure width 52 with same-edge outline witnesses must both be suppressed");
			// History note: before pre-plan discards became visible in diagnostics, the 52
			// candidates were dropped silently during candidate building (52 completes the
			// 15.54+52+23 overall partition), DimensionCandidates contained no 52 entry at
			// all, and the original .All()-based reason assertion passed vacuously. The real
			// contract is: every mirrored 52 candidate must leave an explanatory trace -
			// either a pre-plan discard with a concrete reason, or an in-plan suppression
			// with the high-priority envelope reason - and both sides must leave one.
			var mirrored52 = plan.Diagnostics.DimensionCandidates
				.Where(c => (c.DebugRole == "TopStructWidth" || c.DebugRole == "BottomStructWidth")
					&& Math.Abs(c.Value - 52.0) <= config.GeometryTolerance)
				.ToList();
			Assert(mirrored52.Any(c => c.DebugRole == "TopStructWidth")
					&& mirrored52.Any(c => c.DebugRole == "BottomStructWidth"),
				"both mirrored structure width 52 candidates must appear in diagnostics");
			Assert(mirrored52.All(c =>
					(c.DecisionStatus == "Skipped" && !string.IsNullOrEmpty(c.DecisionReason))
					|| c.SuppressedReason == "LocalGeometryOnOverallEnvelope"),
				"every mirrored structure width 52 candidate must record a discard reason or the high-priority envelope reason");
		}

		private static void Production73x20EnvelopeDimensionsAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 73.0,
				MaxY = 20.0
			};
			var plan = new DimensionPlan();
			var invalid = new[]
			{
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(0.0, 20.0), new Point2D(35.38090093, 20.0), "TopStructWidth"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Bottom,
					new Point2D(35.38090097, 0.0), new Point2D(73.0, 0.0), "BottomStructWidth"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(53.0, 0.0), new Point2D(73.0, 0.0), "TopChamferedStepWidth"),
				CreateTestDimension(DimensionKind.Normal, DimensionOrientation.Vertical, DimensionSide.Right,
					new Point2D(73.0, 0.0), new Point2D(73.0, 20.0), "RightChamferedStepHeight")
			};
			foreach (PlannedDimension dimension in invalid)
			{
				plan.Add(dimension);
			}
			var valid = new[]
			{
				CreateTestDimension(DimensionKind.OverallWidth, DimensionOrientation.Horizontal, DimensionSide.Bottom,
					new Point2D(0.0, 0.0), new Point2D(73.0, 0.0), "OverallWidth"),
				CreateTestDimension(DimensionKind.OverallHeight, DimensionOrientation.Vertical, DimensionSide.Left,
					new Point2D(0.0, 0.0), new Point2D(0.0, 20.0), "OverallHeight"),
				CreateTestDimension(DimensionKind.DatumHoleLocationX, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(0.0, 10.0), new Point2D(10.0, 10.0), "DatumX"),
				CreateTestDimension(DimensionKind.DatumHoleLocationY, DimensionOrientation.Vertical, DimensionSide.Left,
					new Point2D(10.0, 0.0), new Point2D(10.0, 10.0), "DatumY"),
				CreateTestDimension(DimensionKind.PinDistance, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(10.0, 10.0), new Point2D(40.0, 10.0), "PinDistance"),
				CreateTestDimension(DimensionKind.HoleLocation, DimensionOrientation.Horizontal, DimensionSide.Top,
					new Point2D(10.0, 10.0), new Point2D(25.0, 10.0), "FunctionalHole")
			};
			foreach (PlannedDimension dimension in valid)
			{
				plan.Add(dimension);
			}
			Assert(invalid.Length == 4 && invalid.All(plan.Dimensions.Contains),
				"the 73x20 production regression must contain all four invalid candidates before suppression");

			planner.SuppressLocalGeometryOnOverallEnvelope(plan, outline);

			Assert(invalid.All(d => !plan.Dimensions.Contains(d)),
				"35.38, 37.62 and both composite 20 dimensions must be suppressed");
			Assert(invalid.All(d => plan.Diagnostics.DimensionCandidates.Any(c =>
					c.Id == d.DiagnosticId && c.SuppressedReason == "LocalGeometryOnOverallEnvelope")),
				"all four production candidates must record LocalGeometryOnOverallEnvelope");
			Assert(valid.All(plan.Dimensions.Contains),
				"73, 20, datum 10, pin 30 and functional 15 dimensions must remain");
		}

		/// <summary>
		/// Repro GEN|OutlineSegment1|GB|R|L0: outer right tip OS@MaxX height 5 is envelope-suppressed,
		/// but an inner vertical at mid-X with the same Y-interval was left selected (Side=Right).
		/// Same measurement interval as envelope fragment must also suppress.
		/// Bottom gap prevents left/right 5+40 from forming an overall-height partition chain
		/// (mirrors CAD case where mid segment is corner-suppressed and tips remain).
		/// </summary>
		private static void InnerOutlineSegmentMatchingEnvelopeTipIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 40.0,
				MaxY = 45.0
			};
			// Bottom gap [0,5] via diagonal so verticals do not start at overall MinY → no 5+40 chain.
			AddSegment(outline, new Point2D(5.0, 0.0), new Point2D(35.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(0.0, 5.0), new Point2D(5.0, 0.0), "chamfer-bl");
			AddSegment(outline, new Point2D(35.0, 0.0), new Point2D(40.0, 5.0), "chamfer-br");
			AddSegment(outline, new Point2D(40.0, 5.0), new Point2D(40.0, 40.0), "right-main");
			AddSegment(outline, new Point2D(40.0, 40.0), new Point2D(40.0, 45.0), "right-tip");
			AddSegment(outline, new Point2D(40.0, 45.0), new Point2D(0.0, 45.0), "top");
			AddSegment(outline, new Point2D(0.0, 45.0), new Point2D(0.0, 40.0), "left-tip");
			AddSegment(outline, new Point2D(0.0, 40.0), new Point2D(0.0, 5.0), "left-main");
			// Inner vertical, same Y-interval as outer tips [40,45], X not on envelope → Side=Right.
			AddSegment(outline, new Point2D(5.0, 40.0), new Point2D(5.0, 45.0), "inner-tip");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 45.0) <= config.GeometryTolerance),
				"overall height 45 must remain");
			// Inner tip must not remain; outer tips should be envelope-suppressed.
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment"
					&& d.Orientation == DimensionOrientation.Vertical
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 5.0) <= config.GeometryTolerance
					&& Math.Abs(d.FirstPoint.X - 5.0) <= config.GeometryTolerance),
				"inner vertical OutlineSegment tip at X=5 matching envelope tip interval must not remain");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "OutlineSegment"
					&& Math.Abs(c.Value - 5.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& (c.SuppressedReason == "OutlineSegmentOnOverallEnvelope"
						|| c.SuppressedReason == "OutlineSegmentSameIntervalAsEnvelopeFragment"
						|| c.SuppressedReason == "MirroredDuplicate"
						|| c.SuppressedReason == "DuplicateMeasuredDimension")),
				"tip OutlineSegments of 5 must be suppressed");
		}

		/// <summary>
		/// Case 1: [0,25] + [25,257] = overall [0,257] — true abutment partition.
		/// </summary>
		private static void CompleteOverallPartitionIntervalsAreDetected()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			var overall = CreatePartitionItem(0.0, 0.0, 257.0, 0.0, DimensionKind.OverallWidth);
			var a = CreatePartitionItem(0.0, 0.0, 25.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			var b = CreatePartitionItem(25.0, 0.0, 257.0, 0.0, DimensionKind.Normal, "OutlineSegment");

			Assert(rules.FormsCompleteOverallPartition(a, b, overall, horizontal: true),
				"abutting [0,25]+[25,257] must form a complete overall partition of 257");
			// Integration: same geometry still suppresses OutlineSegment pair in the planner.
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 257.0, MaxY = 20.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(25.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(257.0, 0.0), "bottom-right");
			AddSegment(outline, new Point2D(257.0, 0.0), new Point2D(257.0, 20.0), "right");
			AddSegment(outline, new Point2D(257.0, 20.0), new Point2D(0.0, 20.0), "top");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment" && d.Side == DimensionSide.Bottom),
				"true partition OutlineSegments must still be suppressed by planner");
		}

		/// <summary>
		/// Phase 2: legitimate snap candidate at origin (0,0) must not be treated as NotFound
		/// (old code used Equals(default(Point2D))).
		/// Covers both vertical-down and horizontal-left snap directions.
		/// </summary>
		private static void SnapToOriginPointIsNotTreatedAsNotFound()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			// Vertical snap: point (0, 10) should snap down to horizontal endpoint (0, 0).
			var outlineVertical = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 50.0,
				MaxY = 20.0
			};
			AddSegment(outlineVertical, new Point2D(0.0, 0.0), new Point2D(50.0, 0.0), "bottom");
			AddSegment(outlineVertical, new Point2D(50.0, 0.0), new Point2D(50.0, 20.0), "right");
			AddSegment(outlineVertical, new Point2D(50.0, 20.0), new Point2D(0.0, 20.0), "top");
			AddSegment(outlineVertical, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");
			Point2D snappedDown = planner.SnapVerticalPointToLowerConnectedHorizontal(new Point2D(0.0, 10.0), outlineVertical);
			Assert(Math.Abs(snappedDown.X - 0.0) <= config.GeometryTolerance
					&& Math.Abs(snappedDown.Y - 0.0) <= config.GeometryTolerance,
				"vertical snap must accept origin (0,0) as a valid candidate, not NotFound");

			// Horizontal snap: point (10, 0) should snap left to vertical endpoint (0, 0).
			var outlineHorizontal = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 50.0,
				MaxY = 20.0
			};
			AddSegment(outlineHorizontal, new Point2D(0.0, 0.0), new Point2D(0.0, 20.0), "left");
			AddSegment(outlineHorizontal, new Point2D(0.0, 20.0), new Point2D(50.0, 20.0), "top");
			AddSegment(outlineHorizontal, new Point2D(50.0, 20.0), new Point2D(50.0, 0.0), "right");
			AddSegment(outlineHorizontal, new Point2D(50.0, 0.0), new Point2D(0.0, 0.0), "bottom");
			Point2D snappedLeft = planner.SnapHorizontalPointToLeftConnectedVertical(new Point2D(10.0, 0.0), outlineHorizontal);
			Assert(Math.Abs(snappedLeft.X - 0.0) <= config.GeometryTolerance
					&& Math.Abs(snappedLeft.Y - 0.0) <= config.GeometryTolerance,
				"horizontal snap must accept origin (0,0) as a valid candidate, not NotFound");
		}

		/// <summary>
		/// Phase 2: when no snap candidate exists, keep the original point (both directions).
		/// </summary>
		private static void SnapKeepsOriginalPointWhenNoCandidateExists()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			// Isolated horizontal edge only — no lower connected horizontal for a vertical snap.
			var outline = new OutlineFeature2D
			{
				MinX = 10.0,
				MinY = 10.0,
				MaxX = 40.0,
				MaxY = 30.0
			};
			AddSegment(outline, new Point2D(10.0, 30.0), new Point2D(40.0, 30.0), "top-only");
			Point2D originalVertical = new Point2D(20.0, 25.0);
			Point2D snappedVertical = planner.SnapVerticalPointToLowerConnectedHorizontal(originalVertical, outline);
			Assert(Math.Abs(snappedVertical.X - originalVertical.X) <= config.GeometryTolerance
					&& Math.Abs(snappedVertical.Y - originalVertical.Y) <= config.GeometryTolerance,
				"vertical snap with no lower candidate must keep the original point");

			// Isolated vertical edge only — no left connected vertical for a horizontal snap.
			var outline2 = new OutlineFeature2D
			{
				MinX = 10.0,
				MinY = 10.0,
				MaxX = 40.0,
				MaxY = 30.0
			};
			AddSegment(outline2, new Point2D(40.0, 10.0), new Point2D(40.0, 30.0), "right-only");
			Point2D originalHorizontal = new Point2D(30.0, 20.0);
			Point2D snappedHorizontal = planner.SnapHorizontalPointToLeftConnectedVertical(originalHorizontal, outline2);
			Assert(Math.Abs(snappedHorizontal.X - originalHorizontal.X) <= config.GeometryTolerance
					&& Math.Abs(snappedHorizontal.Y - originalHorizontal.Y) <= config.GeometryTolerance,
				"horizontal snap with no left candidate must keep the original point");
		}

		/// <summary>
		/// Phase 3: legal complementary [0,20]+[20,98]=overall [0,98] — snap gate allows,
		/// FormsCompleteOverallPartition holds, RemoveComplementary drops the larger.
		/// </summary>
		private static void LegalComplementaryPartitionAllowsSnapAndSuppress()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 98.0, MaxY = 20.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(98.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(98.0, 0.0), new Point2D(98.0, 20.0), "right");
			AddSegment(outline, new Point2D(98.0, 20.0), new Point2D(0.0, 20.0), "top");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(20.0, 20.0), "shoulder");

			var smaller = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 20.0),
				SecondPoint = new Point2D(20.0, 20.0),
				DebugRole = "TopStructWidth"
			};
			var larger = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(20.0, 20.0),
				SecondPoint = new Point2D(98.0, 20.0),
				DebugRole = "TopStructWidth"
			};
			Assert(planner.CanAttemptComplementaryPartitionSnap(larger, smaller, outline, horizontal: true),
				"legal abutting structure pair must allow complementary snap");
			// Integration: full plan still suppresses the overall-restating structure pair path.
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 98.0) <= config.GeometryTolerance),
				"overall 98 must remain");
			// Structure that only re-partitions overall with same-side collinear OS is suppressed elsewhere;
			// gate itself must remain true for the legal pair.
			Assert(planner.CanAttemptComplementaryPartitionSnap(larger, smaller, outline, horizontal: true),
				"legal pair remains snap-eligible after FormsCompleteOverallPartition check");
		}

		/// <summary>
		/// Phase 3: [0,40]+[20,80] spans 40+60=100 but overlap — no snap, no partition suppress.
		/// </summary>
		private static void OverlappingSpanSumDoesNotAllowComplementarySnap()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 100.0, MaxY = 20.0 };
			var a = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 20.0),
				SecondPoint = new Point2D(40.0, 20.0),
				DebugRole = "TopStructWidth"
			};
			var b = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(20.0, 20.0),
				SecondPoint = new Point2D(80.0, 20.0),
				DebugRole = "TopStructWidth"
			};
			Assert(Math.Abs((40.0 + 60.0) - 100.0) <= config.GeometryTolerance, "precondition: span sum equals overall");
			Assert(!planner.CanAttemptComplementaryPartitionSnap(b, a, outline, horizontal: true),
				"overlapping intervals must not allow complementary snap despite span sum");
			Point2D beforeFirst = b.FirstPoint;
			Point2D beforeSecond = b.SecondPoint;
			// Simulate snap gate path: when CanAttempt is false, points must stay put.
			Assert(!planner.CanAttemptComplementaryPartitionSnap(b, a, outline, horizontal: true),
				"re-check: still not snap-eligible");
			Assert(beforeFirst.Equals(b.FirstPoint) && beforeSecond.Equals(b.SecondPoint),
				"attachment must not be modified when snap gate rejects overlap");
		}

		/// <summary>
		/// Phase 3: [0,30]+[40,100] spans 30+60=90 or 30+70=100 with gap — no snap.
		/// </summary>
		private static void GappedSpanSumDoesNotAllowComplementarySnap()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 100.0, MaxY = 20.0 };
			var a = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 20.0),
				SecondPoint = new Point2D(30.0, 20.0),
				DebugRole = "TopStructWidth"
			};
			var b = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(40.0, 20.0),
				SecondPoint = new Point2D(110.0, 20.0),
				DebugRole = "TopStructWidth"
			};
			Assert(Math.Abs((30.0 + 70.0) - 100.0) <= config.GeometryTolerance, "precondition: span sum equals overall");
			Assert(!planner.CanAttemptComplementaryPartitionSnap(b, a, outline, horizontal: true),
				"gapped/out-of-bounds intervals must not allow complementary snap");
			// Vertical direction gap case.
			var outlineV = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 20.0, MaxY = 100.0 };
			var va = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(20.0, 0.0),
				SecondPoint = new Point2D(20.0, 30.0),
				DebugRole = "RightStructHeight"
			};
			var vb = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(20.0, 40.0),
				SecondPoint = new Point2D(20.0, 100.0),
				DebugRole = "RightStructHeight"
			};
			Assert(!planner.CanAttemptComplementaryPartitionSnap(vb, va, outlineV, horizontal: false),
				"vertical gapped intervals must not allow complementary snap");
		}

		/// <summary>
		/// Phase 3: TopStructWidth 60 + BottomStructWidth 40 sum to 100 but different local
		/// positions — must not snap or treat as overall partition.
		/// </summary>
		private static void NumericComplementLocalStructuresDoNotSnapOrSuppress()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 100.0, MaxY = 50.0 };
			var top = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 50.0),
				SecondPoint = new Point2D(60.0, 50.0),
				DebugRole = "TopStructWidth"
			};
			var bottom = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(40.0, 0.0),
				DebugRole = "BottomStructWidth"
			};
			Assert(Math.Abs((60.0 + 40.0) - 100.0) <= config.GeometryTolerance, "precondition: span sum equals overall");
			Assert(!planner.CanAttemptComplementaryPartitionSnap(top, bottom, outline, horizontal: true),
				"numeric-only complement of local structures must not allow snap");
			// Integration: local mid step that does not complete overall stays selected.
			var stepOutline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 100.0, MaxY = 50.0 };
			AddSegment(stepOutline, new Point2D(0.0, 0.0), new Point2D(0.0, 50.0), "left");
			AddSegment(stepOutline, new Point2D(40.0, 10.0), new Point2D(40.0, 45.0), "middle");
			AddSegment(stepOutline, new Point2D(100.0, 0.0), new Point2D(100.0, 50.0), "right");
			var plan = new DimensionPlanner(config).CreateOutlinePlan(stepOutline);
			Assert(plan.Dimensions.Any(d =>
					(d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 40.0) <= config.GeometryTolerance),
				"local structure width 40 must remain when not a real overall partition");
		}

		/// <summary>
		/// Phase 1: greedy longest-first would pick [0,60] then die; DFS must still find
		/// [0,40]+[40,70]+[70,100]. Also verify result is independent of input order.
		/// </summary>
		private static void GreedyDeadEndStillFindsValidOverallPartitionChain()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			// A=[0,60] decoy, B=[0,40], C=[40,70], D=[70,100]
			var decoy = CreatePartitionItem(0.0, 0.0, 60.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			var b = CreatePartitionItem(0.0, 0.0, 40.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			var c = CreatePartitionItem(40.0, 0.0, 70.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			var d = CreatePartitionItem(70.0, 0.0, 100.0, 0.0, DimensionKind.Normal, "OutlineSegment");

			void AssertValidChain(IList<DimensionDeduplicationItem> input, string label)
			{
				var chain = rules.FindCompleteOverallPartitionChain(input, 0.0, 100.0, horizontal: true);
				Assert(chain != null && chain.Count == 3,
					label + ": must find 3-piece chain, not fail on decoy [0,60]");
				double[] starts = chain.Select(item => Math.Min(item.FirstPoint.X, item.SecondPoint.X)).ToArray();
				double[] ends = chain.Select(item => Math.Max(item.FirstPoint.X, item.SecondPoint.X)).ToArray();
				Assert(Math.Abs(starts[0] - 0.0) <= config.GeometryTolerance
						&& Math.Abs(ends[0] - 40.0) <= config.GeometryTolerance,
					label + ": first piece must be [0,40]");
				Assert(Math.Abs(starts[1] - 40.0) <= config.GeometryTolerance
						&& Math.Abs(ends[1] - 70.0) <= config.GeometryTolerance,
					label + ": second piece must be [40,70]");
				Assert(Math.Abs(starts[2] - 70.0) <= config.GeometryTolerance
						&& Math.Abs(ends[2] - 100.0) <= config.GeometryTolerance,
					label + ": third piece must be [70,100]");
				Assert(!chain.Any(item => Math.Abs(Math.Max(item.FirstPoint.X, item.SecondPoint.X) - 60.0) <= config.GeometryTolerance
						&& Math.Abs(Math.Min(item.FirstPoint.X, item.SecondPoint.X) - 0.0) <= config.GeometryTolerance
						&& Math.Abs(Math.Abs(item.SecondPoint.X - item.FirstPoint.X) - 60.0) <= config.GeometryTolerance),
					label + ": decoy [0,60] must not appear in the successful chain");
			}

			// Decoy first (greedy would pick it and die).
			AssertValidChain(new List<DimensionDeduplicationItem> { decoy, b, c, d }, "decoy-first");
			// Order perturbation: legal pieces shuffled, decoy last.
			AssertValidChain(new List<DimensionDeduplicationItem> { d, c, b, decoy }, "legal-first-shuffled");
			// Decoy between B and C.
			AssertValidChain(new List<DimensionDeduplicationItem> { b, decoy, d, c }, "decoy-middle");
		}

		/// <summary>
		/// Case 2: lengths 40+60=100 but intervals [0,40] and [20,80] overlap and miss [80,100].
		/// </summary>
		private static void OverlappingIntervalsDoNotFormOverallPartition()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			var overall = CreatePartitionItem(0.0, 0.0, 100.0, 0.0, DimensionKind.OverallWidth);
			var a = CreatePartitionItem(0.0, 0.0, 40.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			var b = CreatePartitionItem(20.0, 0.0, 80.0, 0.0, DimensionKind.Normal, "OutlineSegment");

			Assert(Math.Abs((40.0 + 60.0) - 100.0) <= config.GeometryTolerance,
				"precondition: span sum equals overall");
			Assert(!rules.FormsCompleteOverallPartition(a, b, overall, horizontal: true),
				"overlapping intervals must not form overall partition even when span sum matches");
		}

		/// <summary>
		/// Case 3: lengths 30+70=100 but [0,30] and [40,110] have a gap (and B overshoots).
		/// Also pure-gap case [0,30]+[40,100] inside overall.
		/// </summary>
		private static void GappedIntervalsDoNotFormOverallPartition()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			var overall = CreatePartitionItem(0.0, 0.0, 100.0, 0.0, DimensionKind.OverallWidth);
			var a = CreatePartitionItem(0.0, 0.0, 30.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			// Gap only (still within overall): [0,30] + [40,100]
			var gappedInside = CreatePartitionItem(40.0, 0.0, 100.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			Assert(!rules.FormsCompleteOverallPartition(a, gappedInside, overall, horizontal: true),
				"gapped intervals [0,30]+[40,100] must not form overall partition");

			// Classic gap + overshoot with span sum 100: [0,30]+[40,110]
			var overshoot = CreatePartitionItem(40.0, 0.0, 110.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			Assert(Math.Abs((30.0 + 70.0) - 100.0) <= config.GeometryTolerance,
				"precondition: span sum equals overall");
			Assert(!rules.FormsCompleteOverallPartition(a, overshoot, overall, horizontal: true),
				"gapped/overshooting intervals must not form overall partition");
		}

		/// <summary>
		/// Case 4: lengths sum to overall but one interval extends past overall max.
		/// </summary>
		private static void OutOfBoundsIntervalsDoNotFormOverallPartition()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			var overall = CreatePartitionItem(0.0, 0.0, 100.0, 0.0, DimensionKind.OverallWidth);
			// [0,30] + [30,130]: abut but B extends past overall; span sum 130 ≠ 100.
			// Use span-sum equal case with overshoot: [0,40] + [40,100] is valid;
			// overshoot-only: [10,50] + [50,110] spans 40+60=100 but does not cover [0,10] and exceeds max.
			var a = CreatePartitionItem(10.0, 0.0, 50.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			var b = CreatePartitionItem(50.0, 0.0, 110.0, 0.0, DimensionKind.Normal, "OutlineSegment");
			Assert(Math.Abs((40.0 + 60.0) - 100.0) <= config.GeometryTolerance,
				"precondition: span sum equals overall");
			Assert(!rules.FormsCompleteOverallPartition(a, b, overall, horizontal: true),
				"intervals that leave overall min uncovered and exceed max must not partition overall");
		}

		/// <summary>
		/// Case 5: TopStructWidth 60 and BottomStructWidth 40 at different positions —
		/// span sum equals overall but intervals do not form a contiguous cover.
		/// </summary>
		private static void NumericallyComplementaryStructureIntervalsDoNotPartitionOverall()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionDeduplicationRules(config);
			var overall = CreatePartitionItem(0.0, 0.0, 100.0, 0.0, DimensionKind.OverallWidth);
			// Different structural locations: top local step [0,60], bottom local step [0,40]
			var top = CreatePartitionItem(0.0, 50.0, 60.0, 50.0, DimensionKind.Normal, "TopStructWidth");
			var bottom = CreatePartitionItem(0.0, 0.0, 40.0, 0.0, DimensionKind.Normal, "BottomStructWidth");
			Assert(Math.Abs((60.0 + 40.0) - 100.0) <= config.GeometryTolerance,
				"precondition: span sum equals overall");
			Assert(!rules.FormsCompleteOverallPartition(top, bottom, overall, horizontal: true),
				"structure dims at different positions must not partition overall by span sum alone");

			// Another non-cover pair with same spans: top [20,80]=60, bottom [10,50]=40
			var topMid = CreatePartitionItem(20.0, 50.0, 80.0, 50.0, DimensionKind.Normal, "TopStructWidth");
			var bottomMid = CreatePartitionItem(10.0, 0.0, 50.0, 0.0, DimensionKind.Normal, "BottomStructWidth");
			Assert(!rules.FormsCompleteOverallPartition(topMid, bottomMid, overall, horizontal: true),
				"overlapping/non-covering structure intervals must not form overall partition");
		}

		private static DimensionDeduplicationItem CreatePartitionItem(
			double x1, double y1, double x2, double y2, DimensionKind kind, string debugRole = null)
		{
			return new DimensionDeduplicationItem
			{
				FirstPoint = new Point2D(x1, y1),
				SecondPoint = new Point2D(x2, y2),
				Span = Math.Abs(x2 - x1) > 1e-12 ? Math.Abs(x2 - x1) : Math.Abs(y2 - y1),
				Kind = kind,
				DebugRole = debugRole ?? string.Empty,
				OverrideText = string.Empty
			};
		}

		private static void EffectiveSpanControlsVerticalStacking()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.OverallHeight, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(0.0, 100.0), Span = 100.0, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationY, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(0.0, 10.0), Span = 10.0, ReadingLevel = DimensionReadingLevel.DatumTransfer },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(0.0, 20.0), Span = 20.0, ReadingLevel = DimensionReadingLevel.IntraGroup },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(0.0, 80.0), Span = 80.0, ReadingLevel = DimensionReadingLevel.LocalSpacing }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Left, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: false);

			Assert(placements.Single(item => item.Index == 1).Level < placements.Single(item => item.Index == 2).Level,
				"the shorter vertical datum transfer must stay inside the longer intra-group span");
			Assert(placements.Single(item => item.Index == 2).Level < placements.Single(item => item.Index == 3).Level,
				"effective span must outrank semantic reading level for non-equal vertical spans");
			Assert(placements.Single(item => item.Index == 3).Level < placements.Single(item => item.Index == 0).Level,
				"the forced vertical overall dimension must remain outermost");
		}

		private static void NearEqualEffectiveSpansUseSemanticTieBreak()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(50.0, 0.0), Span = 50.0, ReadingLevel = DimensionReadingLevel.DatumTransfer },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(50.0 + config.GeometryTolerance * 0.5, 0.0), Span = 50.0 + config.GeometryTolerance * 0.5, ReadingLevel = DimensionReadingLevel.LocalSpacing }
			};
			var rules = new DimensionLayoutRules(config);
			var order = rules.GetStackingOrder(dimensions, isHorizontal: true);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true).ToDictionary(item => item.Index);

			Assert(order.SequenceEqual(new[] { 1, 0 }),
				"semantic reading level may decide only when effective spans are within geometry tolerance");
			Assert(placements[1].OrderingReason == "NearEqualSpanSemanticTieBreak" && placements[0].OrderingReason == "NearEqualSpanSemanticTieBreak",
				"near-equal span diagnostics must expose the semantic tie-break reason");
		}

		private static void LayoutBlocksUseBottomV203SpanOrder()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(338.0, 100.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(305.0, 0.0), Span = 305.0, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(10.0, 0.0), SecondPoint = new Point2D(233.5, 0.0), Span = 223.5, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG3" },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(180.0, 0.0), SecondPoint = new Point2D(233.5, 0.0), Span = 53.5, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(60.0, 0.0), SecondPoint = new Point2D(180.0, 0.0), Span = 120.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(60.0, 0.0), Span = 60.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.OverallWidth, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(338.0, 0.0), Span = 338.0, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(25.0, 0.0), Span = 25.0, ReadingLevel = DimensionReadingLevel.LocalSpacing }
			};
			var rules = new DimensionLayoutRules(config);
			var order = rules.GetStackingOrder(dimensions, isHorizontal: true);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Bottom, outline, 2.5, 1.25, 5.0, 6.5, isHorizontal: true).ToDictionary(item => item.Index);

			// Nested isolated 223.5 stacks OUTSIDE continuous 59.5+120+60 (union 233.5), not inside:
			// local25 → rooted233.5 → isolated223.5 → structure305 → overall338
			Assert(order.SequenceEqual(new[] { 6, 2, 3, 4, 1, 0, 5 }),
				"bottom order must be local25, rooted233.5, isolated223.5, structure305, overall338");
			Assert(placements[2].Level < placements[1].Level && placements[1].Level < placements[0].Level && placements[0].Level < placements[5].Level,
				"nested PinGroupDistance 223.5 must stack outside the continuous rooted chain");
			Assert(new[] { 2, 3, 4 }.Select(index => placements[index].LayoutBlockId).Distinct().Count() == 1
				&& new[] { 2, 3, 4 }.All(index => placements[index].Level == placements[2].Level)
				&& Math.Abs(placements[2].EffectiveSpan - 233.5) <= config.GeometryTolerance,
				"the rooted datum chain must remain one indivisible 233.5 layout block");
			Assert(placements[1].OrderingReason == "NestedPinGroupTransferOutsideChain"
				|| placements[2].OrderingReason == "NestedPinGroupTransferOutsideChain",
				"nested transfer vs continuous chain must expose NestedPinGroupTransferOutsideChain");
			Assert(placements.Values.All(placement => placement.PhysicalOrderValidated),
				"the final bottom physical coordinates must preserve outward order");
		}

		private static void RootedLayoutBlockSurvivesLegacyLaneProcessing()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(338.0, 100.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(245.5, 0.0), SecondPoint = new Point2D(305.0, 0.0), Span = 59.5, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(121.5, 0.0), SecondPoint = new Point2D(245.5, 0.0), Span = 124.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(71.5, 0.0), SecondPoint = new Point2D(121.5, 0.0), Span = 50.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(22.0, 0.0), SecondPoint = new Point2D(245.5, 0.0), Span = 223.5, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG3" }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Bottom, outline, 2.5, 1.25, 5.0, 6.5, isHorizontal: true).ToDictionary(item => item.Index);
			var rooted = new[] { placements[0], placements[1], placements[2] };

			Assert(rooted.Select(item => item.LayoutBlockId).Distinct().Count() == 1
				&& rooted.All(item => item.LayoutBlockType == "RootedAlignmentLane" && item.Level == rooted[0].Level),
				"legacy alignment-lane processing must not split an already formed rooted layout block");
			Assert(rooted.All(item => item.AlignmentLaneKey == "PG1:DatumChain:H#1" && item.AlignmentLaneMemberCount == 3)
				&& rooted.All(item => item.DimLineCoordinateOverride.HasValue)
				&& rooted.Select(item => item.DimLineCoordinateOverride.Value).Distinct().Count() == 1,
				"rooted layout-block diagnostics and physical coordinates must remain block-consistent");
			Assert(placements[3].Level > rooted[0].Level && placements.Values.All(item => item.PhysicalOrderValidated),
				"isolated 223.5 transfer must stack outside the rooted 233.5 continuous chain");
		}

		private static void RootedLaneChoosesNearestSafeFiniteSegmentCoordinate()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 100.0
			};
			var outlinePoints = new[]
			{
				new Point2D(0.0, 0.0),
				new Point2D(100.0, 0.0),
				new Point2D(100.0, 100.0),
				new Point2D(80.0, 100.0),
				new Point2D(80.0, 70.0),
				new Point2D(40.0, 70.0),
				new Point2D(40.0, 30.0),
				new Point2D(0.0, 30.0),
				new Point2D(0.0, 0.0)
			};
			for (int i = 1; i < outlinePoints.Length; i++)
			{
				AddSegment(outline, outlinePoints[i - 1], outlinePoints[i], "left-finite-segment");
			}

			const string alignmentKey = "PG1:DatumChain:V";
			var dimensions = new[]
			{
				// No local boundary covers y=30..35 at this x, so this member falls back to the global left boundary.
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(20.0, 30.0),
					SecondPoint = new Point2D(20.0, 35.0),
					Span = 5.0,
					AlignmentKey = alignmentKey,
					AlignmentPriority = 120,
					ReadingLevel = DimensionReadingLevel.DatumTransfer
				},
				// These two members both have the finite x=40 local boundary and form the next chain links.
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(60.0, 35.0),
					SecondPoint = new Point2D(60.0, 50.0),
					Span = 15.0,
					AlignmentKey = alignmentKey,
					AlignmentPriority = 100,
					ReadingLevel = DimensionReadingLevel.DatumTransfer
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(60.0, 50.0),
					SecondPoint = new Point2D(60.0, 70.0),
					Span = 20.0,
					AlignmentKey = alignmentKey,
					AlignmentPriority = 100,
					ReadingLevel = DimensionReadingLevel.DatumTransfer
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.OverallHeight,
					FirstPoint = new Point2D(0.0, 0.0),
					SecondPoint = new Point2D(0.0, 100.0),
					Span = 100.0,
					ForceOuterLevel = true,
					ReadingLevel = DimensionReadingLevel.Overall
				}
			};
			var firstPoints = dimensions.Select(dimension => dimension.FirstPoint).ToArray();
			var secondPoints = dimensions.Select(dimension => dimension.SecondPoint).ToArray();
			var spans = dimensions.Select(dimension => dimension.Span).ToArray();
			var rules = new DimensionLayoutRules(config);

			Assert(!rules.TryGetDimensionLocalBoundary(dimensions[0], DimensionSide.Left, outline, out _),
				"the first lane member must exercise the global-boundary fallback");
			Assert(rules.TryGetDimensionLocalBoundary(dimensions[1], DimensionSide.Left, outline, out var firstLocalBoundary)
				&& Math.Abs(firstLocalBoundary - 40.0) <= config.GeometryTolerance,
				"the second lane member must expose the finite x=40 local boundary");
			Assert(rules.TryGetDimensionLocalBoundary(dimensions[2], DimensionSide.Left, outline, out var secondLocalBoundary)
				&& Math.Abs(secondLocalBoundary - 40.0) <= config.GeometryTolerance,
				"the third lane member must expose the finite x=40 local boundary");

			const double firstOffset = 5.0;
			var placements = rules.CreateStackingPlan(
				dimensions,
				DimensionSide.Left,
				outline,
				2.5,
				1.0,
				firstOffset,
				5.0,
				isHorizontal: false).ToDictionary(item => item.Index);
			var rooted = new[] { placements[0], placements[1], placements[2] };

			Assert(rooted.Select(item => item.LayoutBlockId).Distinct().Count() == 1
				&& rooted.All(item => item.LayoutBlockType == "RootedAlignmentLane" && item.AlignmentLaneMemberCount == 3),
				"the global and local members must stay in one rooted alignment block");
			Assert(rooted.All(item => item.DimLineCoordinateOverride.HasValue),
				"every rooted member must receive a final coordinate override");

			double globalCoordinate = rules.GetDimLineCoordinate(dimensions[0], DimensionSide.Left, outline, firstOffset);
			double nearestSafeCoordinate = rules.GetDimLineCoordinate(dimensions[1], DimensionSide.Left, outline, firstOffset);
			Assert(nearestSafeCoordinate > globalCoordinate + config.GeometryTolerance,
				"the local candidate must be physically nearer to the left contour than the global fallback");
			double unifiedCoordinate = rooted[0].DimLineCoordinateOverride.Value;
			Assert(rooted.All(item => Math.Abs(item.DimLineCoordinateOverride.Value - unifiedCoordinate) <= config.GeometryTolerance),
				"all rooted members must use one final dimension-line coordinate");
			Assert(Math.Abs(unifiedCoordinate - nearestSafeCoordinate) <= config.GeometryTolerance,
				"the block must choose the nearest candidate that is safe for every finite dimension segment");
			Assert(rooted.All(item => !rules.DimensionLineEntersOutlineInterior(dimensions[item.Index], DimensionSide.Left, unifiedCoordinate, outline)),
				"the shared coordinate must keep every finite dimension segment outside the outline interior");

			double overallCoordinate = placements[3].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[3], DimensionSide.Left, outline, placements[3].Offset);
			Assert(overallCoordinate < unifiedCoordinate - config.GeometryTolerance,
				"the forced overall height must remain physically outside the aligned block");
			for (int i = 0; i < dimensions.Length; i++)
			{
				Assert(dimensions[i].FirstPoint.Equals(firstPoints[i])
					&& dimensions[i].SecondPoint.Equals(secondPoints[i])
					&& Math.Abs(dimensions[i].Span - spans[i]) <= config.GeometryTolerance,
					"layout must not change dimension measurement endpoints or span");
			}
		}

		private static void RootedAlignmentStaysOutsideOuterContour()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 50.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 10.0), "rise");
			AddSegment(outline, new Point2D(100.0, 10.0), new Point2D(40.0, 10.0), "ledge");
			AddSegment(outline, new Point2D(40.0, 10.0), new Point2D(40.0, 50.0), "step");
			AddSegment(outline, new Point2D(40.0, 50.0), new Point2D(0.0, 50.0), "top");
			AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 0.0), "left");

			const double offset = 10.0;
			var dimensions = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.DatumHoleLocationX,
					FirstPoint = new Point2D(100.0, 0.0),
					SecondPoint = new Point2D(90.0, 40.0),
					Span = 10.0,
					AlignmentKey = "PG1:DatumChain:H",
					AlignmentPriority = 120,
					ReadingLevel = DimensionReadingLevel.DatumTransfer,
					SourceFeatureId = "PG1"
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinDistance,
					FirstPoint = new Point2D(50.0, 40.0),
					SecondPoint = new Point2D(90.0, 40.0),
					Span = 40.0,
					AlignmentKey = "PG1:DatumChain:H",
					AlignmentPriority = 100,
					ReadingLevel = DimensionReadingLevel.IntraGroup,
					SourceFeatureId = "PG1"
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.OverallWidth,
					FirstPoint = new Point2D(0.0, 0.0),
					SecondPoint = new Point2D(100.0, 0.0),
					Span = 100.0,
					ForceOuterLevel = true,
					ReadingLevel = DimensionReadingLevel.Overall
				}
			};
			var rules = new DimensionLayoutRules(config);
			Assert(rules.TryGetDimensionLocalBoundary(dimensions[1], DimensionSide.Bottom, outline, out var localBoundary)
				&& Math.Abs(localBoundary - 10.0) <= config.GeometryTolerance,
				"the pin chain must see the ledge as its local bottom boundary");
			double outward = rules.GetDimLineCoordinate(dimensions[0], DimensionSide.Bottom, outline, offset);
			double pinCoordinate = rules.GetDimLineCoordinate(dimensions[1], DimensionSide.Bottom, outline, offset);
			Assert(Math.Abs(localBoundary - offset) <= config.GeometryTolerance,
				"the pin local boundary minus the stack offset would lie on the outer contour");
			Assert(rules.DimensionLineEntersOutlineInterior(dimensions[1], DimensionSide.Bottom, localBoundary - offset, outline),
				"a dimension line lying on the outer contour is not an outward placement");
			Assert(pinCoordinate < -config.GeometryTolerance && outward < -config.GeometryTolerance,
				"both natural coordinates stay outside the outer contour");

			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Bottom, outline, 2.5, 1.25, offset, 6.5, isHorizontal: true)
				.ToDictionary(item => item.Index);
			Assert(placements[0].DimLineCoordinateOverride.HasValue && placements[1].DimLineCoordinateOverride.HasValue
				&& Math.Abs(placements[0].DimLineCoordinateOverride.Value - placements[1].DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
				"alignment still keeps the datum and pin chain on one dimension line");
			Assert(placements[0].DimLineCoordinateOverride.Value < -config.GeometryTolerance
				&& Math.Abs(placements[0].DimLineCoordinateOverride.Value - pinCoordinate) <= config.GeometryTolerance,
				"the shared line uses the outward stack, not the contour-coincident candidate");
			double overall = placements[2].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[2], DimensionSide.Bottom, outline, placements[2].Offset);
			Assert(overall < placements[0].DimLineCoordinateOverride.Value - config.GeometryTolerance,
				"the overall dimension remains outside the aligned chain");
		}

		private static void LooseChainFormsOneEffectiveSpanBlock()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 120.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(100.0, 0.0), SecondPoint = new Point2D(100.0, 20.0), Span = 20.0, LooseChainId = 1, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(100.0, 20.0), SecondPoint = new Point2D(100.0, 50.0), Span = 30.0, LooseChainId = 3, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(100.0, 0.0), SecondPoint = new Point2D(100.0, 40.0), Span = 40.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(100.0, 40.0), SecondPoint = new Point2D(100.0, 85.0), Span = 45.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(100.0, 0.0), SecondPoint = new Point2D(100.0, 100.0), Span = 100.0, ReadingLevel = DimensionReadingLevel.LocalSpacing }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Right, outline, 2.5, 1.25, 5.0, 6.5, isHorizontal: false).ToDictionary(item => item.Index);

			Assert(placements[0].LayoutBlockId == placements[1].LayoutBlockId
				&& placements[0].LayoutBlockType == "LooseChain"
				&& Math.Abs(placements[0].EffectiveSpan - 50.0) <= config.GeometryTolerance,
				"all members of one loose chain must form one 50-unit layout block");
			Assert(placements[0].Level < placements[2].Level && placements[2].Level < placements[4].Level,
				"right-side loose50, rooted85, and outline100 blocks must follow effective-span order");
		}

		private static void NestedLooseHoleSpansStackOnSeparateLayers()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(40.0, 40.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(30.0, 0.0), Span = 30.0, LooseChainId = 1, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "L1" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(16.0, 0.0), SecondPoint = new Point2D(30.0, 0.0), Span = 14.0, LooseChainId = 2, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "L2" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(15.0, 0.0), Span = 15.0, AlignmentKey = "PG2:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(15.0, 0.0), SecondPoint = new Point2D(30.0, 0.0), Span = 15.0, AlignmentKey = "PG2:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG2" }
			};
			var placements = new DimensionLayoutRules(config)
				.CreateStackingPlan(dimensions, DimensionSide.Bottom, outline, 2.5, 1.25, 10.0, 6.5, isHorizontal: true)
				.ToDictionary(item => item.Index);
			Assert(placements[0].LayoutBlockId != placements[1].LayoutBlockId,
				"a nested 14 must not share the loose-chain layout block of the outer 30");
			Assert(placements[1].Level < placements[0].Level,
				"the nested 14 must sit closer to the part than the outer 30");
			Assert(placements[1].Level <= placements[2].Level && placements[1].Level <= placements[3].Level,
				"the nested 14 must not sit outside either 15");
			Assert(placements[0].Level >= placements[2].Level && placements[0].Level >= placements[3].Level,
				"the outer 30 must not sit inside the 15s");
		}

		private static void DisconnectedLooseChainsRemainSeparateBlocks()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(100.0, 0.0), SecondPoint = new Point2D(100.0, 20.0), Span = 20.0, LooseChainId = 1 },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(100.0, 50.0), SecondPoint = new Point2D(100.0, 70.0), Span = 20.0, LooseChainId = 3 }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Right, null, 2.5, 1.25, 5.0, 6.5, isHorizontal: false).ToDictionary(item => item.Index);

			Assert(placements[0].LayoutBlockId != placements[1].LayoutBlockId,
				"disconnected loose dimensions with different chain identifiers must remain separate layout blocks");
		}

		private static void OverlappingRootedIntervalsSplitIntoSeparateLeftBlocks()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateTopLeftShoulderOutline();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(245.5, 15.0), SecondPoint = new Point2D(121.5, 56.0), Span = 41.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(245.5, 15.0), SecondPoint = new Point2D(22.0, 191.5), Span = 176.5, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG4" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(121.5, 56.0), SecondPoint = new Point2D(71.5, 11.0), Span = 45.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(22.0, 45.0), SecondPoint = new Point2D(22.0, 15.0), Span = 30.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG3" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(22.0, 45.0), SecondPoint = new Point2D(22.0, 30.0), Span = 15.0, PreferLocalBoundary = true, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG3" },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(-33.0, 181.5), SecondPoint = new Point2D(-33.0, 201.5), Span = 20.0, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(22.0, 191.5), SecondPoint = new Point2D(24.0, 143.0), Span = 48.5, LooseChainId = 6, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "L6" },
				new DimensionLayoutItem { Kind = DimensionKind.OverallHeight, FirstPoint = new Point2D(5.0, 0.0), SecondPoint = new Point2D(-33.0, 201.5), Span = 201.5, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall }
			};
			var rules = new DimensionLayoutRules(config);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Left, outline, 2.5, 1.25, 10.0, 6.5, isHorizontal: false).ToDictionary(item => item.Index);
			double pg2TransferCoordinate = placements[0].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[0], DimensionSide.Left, outline, placements[0].Offset);
			double pg2PinCoordinate = placements[2].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[2], DimensionSide.Left, outline, placements[2].Offset);
			double pg4TransferCoordinate = placements[1].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[1], DimensionSide.Left, outline, placements[1].Offset);
			double pg3PinCoordinate = placements[3].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[3], DimensionSide.Left, outline, placements[3].Offset);

			Assert(placements[0].LayoutBlockId != placements[2].LayoutBlockId
				&& placements[0].Level < placements[2].Level
				&& Math.Abs(pg2TransferCoordinate - pg2PinCoordinate) >= 6.5 - config.GeometryTolerance,
				"shared-endpoint PG2 dimensions with overlapping arrow intervals must use separate levels");
			Assert(placements[1].LayoutBlockId != placements[3].LayoutBlockId
				&& placements[3].Level < placements[1].Level
				&& Math.Abs(pg4TransferCoordinate - pg3PinCoordinate) >= 6.5 - config.GeometryTolerance,
				"shared-endpoint PG3/PG4 dimensions with overlapping arrow intervals must use separate levels");
			Assert(Math.Abs(placements[0].EffectiveSpan - 41.0) <= config.GeometryTolerance
				&& Math.Abs(placements[2].EffectiveSpan - 45.0) <= config.GeometryTolerance
				&& Math.Abs(placements[3].EffectiveSpan - 30.0) <= config.GeometryTolerance
				&& Math.Abs(placements[1].EffectiveSpan - 176.5) <= config.GeometryTolerance,
				"split dimensions must preserve their own effective spans");
			double pg4Rank = -pg4TransferCoordinate;
			double looseCoordinate = placements[6].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[6], DimensionSide.Left, outline, placements[6].Offset);
			double overallCoordinate = placements[7].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[7], DimensionSide.Left, outline, placements[7].Offset);
			Assert(placements[2].Level < placements[1].Level
				&& pg4Rank >= -looseCoordinate + 6.5 - config.GeometryTolerance
				&& -overallCoordinate >= pg4Rank + 6.5 - config.GeometryTolerance
				&& placements.Values.All(placement => placement.PhysicalOrderValidated),
				"left-side split dimensions must retain physical outward order across local and global boundaries");
		}

		private static void OverlappingDatumAndPinIntervalsSplitIntoSeparateBlocks()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationY, FirstPoint = new Point2D(40.0, 15.0), SecondPoint = new Point2D(40.0, 56.0), Span = 41.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(20.0, 11.0), SecondPoint = new Point2D(20.0, 56.0), Span = 45.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG1" }
			};
			var rules = new DimensionLayoutRules(config);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Left, null, 2.5, 1.25, 5.0, 5.0, isHorizontal: false).ToDictionary(item => item.Index);
			double datumCoordinate = placements[0].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[0], DimensionSide.Left, null, placements[0].Offset);
			double pinCoordinate = placements[1].DimLineCoordinateOverride
				?? rules.GetDimLineCoordinate(dimensions[1], DimensionSide.Left, null, placements[1].Offset);

			Assert(placements[0].LayoutBlockId != placements[1].LayoutBlockId
				&& placements[0].Level < placements[1].Level
				&& Math.Abs(datumCoordinate - pinCoordinate) >= 5.0 - config.GeometryTolerance
				&& placements.Values.All(placement => placement.PhysicalOrderValidated),
				"shared-endpoint datum and pin dimensions with overlapping arrow intervals must use separate levels");
		}

		private static void IndependentLocalAndGlobalDimensionsMayShareLogicalLevel()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRightNotchOutline();
			var dimensions = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.HoleLocation,
					FirstPoint = new Point2D(20.0, 30.0),
					SecondPoint = new Point2D(20.0, 40.0),
					Span = 10.0,
					PreferLocalBoundary = true,
					PreservePreferredSide = true,
					ReadingLevel = DimensionReadingLevel.LocalSpacing
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.Normal,
					FirstPoint = new Point2D(200.0, 85.0),
					SecondPoint = new Point2D(200.0, 95.0),
					Span = 10.0,
					ReadingLevel = DimensionReadingLevel.LocalSpacing
				}
			};
			var rules = new DimensionLayoutRules(config);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Right, outline, 2.5, 1.25, 5.0, 6.5, isHorizontal: false).ToDictionary(item => item.Index);
			double localCoordinate = placements[0].DimLineCoordinateOverride ?? rules.GetDimLineCoordinate(dimensions[0], DimensionSide.Right, outline, placements[0].Offset);
			double globalCoordinate = placements[1].DimLineCoordinateOverride ?? rules.GetDimLineCoordinate(dimensions[1], DimensionSide.Right, outline, placements[1].Offset);

			Assert(placements[0].Level == placements[1].Level && Math.Abs(localCoordinate - globalCoordinate) > config.GeometryTolerance,
				"independent local-boundary and global dimensions may share one logical level at different physical coordinates");
			Assert(placements.Values.All(placement => placement.PhysicalOrderValidated),
				"different coordinates on a shared non-conflicting logical level must not invalidate physical block ordering");
		}

		private static void IsolatedShortPinGroupTransferUsesInnerSpanOrder()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.OverallHeight, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(0.0, 100.0), Span = 100.0, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(10.0, 42.0), SecondPoint = new Point2D(0.0, 0.0), Span = 42.0, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(155.0, 14.5), SecondPoint = new Point2D(40.0, 0.0), Span = 14.5, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer }
			};
			var rules = new DimensionLayoutRules(config);
			var order = rules.GetStackingOrder(dimensions, isHorizontal: false);
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Left, null, 2.5, 1.25, 5.0, 6.5, isHorizontal: false).ToDictionary(item => item.Index);

			Assert(order.SequenceEqual(new[] { 2, 1, 0 }),
				"an isolated short pin-group transfer must use span order ahead of a larger overlapping local dimension");
			Assert(placements[2].Level == 0 && placements[1].Level == 1 && placements[0].Level == 2,
				"left-side isolated GD 14.5 must sit inside local structure height 42 while overall height remains outermost");
			Assert(placements[2].AlignmentLaneMemberCount == 1,
				"the span-order exception must apply only to an isolated alignment lane");
		}

		private static void PreferredSideLooseChainCanRebalance()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var locked = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(20.0, 30.0),
				SecondPoint = new Point2D(22.0, 70.0),
				Span = 40.0,
				LooseChainId = 6,
				PreferLocalBoundary = true,
				PreservePreferredSide = true
			};
			var unlocked = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = locked.FirstPoint,
				SecondPoint = locked.SecondPoint,
				Span = locked.Span,
				LooseChainId = locked.LooseChainId,
				PreferLocalBoundary = true
			};
			var crowded = Enumerable.Range(0, 3).Select(index => new DimensionLayoutItem
			{
				Kind = DimensionKind.Normal,
				FirstPoint = new Point2D(10.0 + index, 30.0),
				SecondPoint = new Point2D(10.0 + index, 70.0),
				Span = 40.0
			}).ToList();

			var lockedSource = new List<DimensionLayoutItem> { locked };
			lockedSource.AddRange(crowded);
			var unlockedSource = new List<DimensionLayoutItem> { unlocked };
			unlockedSource.AddRange(crowded);
			var lockedMoves = rules.SelectVerticalHoleLocationRebalanceMoves(lockedSource, new DimensionLayoutItem[0], 1.0);
			var unlockedMoves = rules.SelectVerticalHoleLocationRebalanceMoves(unlockedSource, new DimensionLayoutItem[0], 1.0);

			Assert(lockedMoves.Any(move => move.SourceIndex == 0),
				"a preferred-side vertical loose chain must remain eligible for cross-side rebalancing");
			Assert(unlockedMoves.Any(move => move.SourceIndex == 0),
				"an unlocked vertical loose chain must retain the legacy rebalance behavior");
		}

		private static void DimensionDiagnosticsRecordFinalPlacement()
		{
			var plan = new DimensionPlan();
			var dimension = new PlannedDimension
			{
				Kind = DimensionKind.PinDistance,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(30.0, 0.0),
				AlignmentKey = "PG1:DatumChain:H",
				AlignmentPriority = 100,
				ReadingLevel = DimensionReadingLevel.IntraGroup,
				DebugRole = "PinDistance"
			};
			plan.Add(dimension);
			plan.CaptureFinalDimensions();
			plan.Diagnostics.RecordFinalPlacement(dimension.DiagnosticId, DimensionSide.Bottom.ToString(), 2, 15.0, 125.0, true, true, "PG1:DatumChain:H#1", 3, "AlignedLaneCoordinateOverride", "AlignmentLane:PG1:DatumChain:H#1", "RootedAlignmentLane", 30.0, 1, "EffectiveSpanAscending", "Dimension:2", 15.0, true);
			plan.SynchronizeFinalPlacementSides();

			Assert(dimension.DiagnosticId > 0, "planned dimensions must receive a stable diagnostic id");
			Assert(plan.Diagnostics.DimensionCandidates.Single().ReadingLevel == DimensionReadingLevel.IntraGroup.ToString()
				&& plan.Diagnostics.DimensionCandidates.Single().AlignmentKey == "PG1:DatumChain:H",
				"candidate diagnostics must expose reading and requested alignment metadata");
			Assert(plan.Diagnostics.DimensionCandidates.Single().HasFinalPlacement
				&& plan.Diagnostics.FinalDimensions.Single().HasFinalPlacement
				&& plan.Diagnostics.FinalDimensions.Single().StackingLevel == 2
				&& Math.Abs(plan.Diagnostics.FinalDimensions.Single().StackingOffset.Value - 15.0) <= 1E-09
				&& Math.Abs(plan.Diagnostics.FinalDimensions.Single().ResolvedDimLineCoordinate.Value - 125.0) <= 1E-09,
				"final placement diagnostics must update both candidate and final-dimension views");
			Assert(plan.Diagnostics.FinalDimensions.Single().AlignmentLaneMemberCount == 3
				&& plan.Diagnostics.FinalDimensions.Single().AlignmentDecision == "AlignedLaneCoordinateOverride",
				"final placement diagnostics must explain the resolved alignment lane");
			Assert(plan.Diagnostics.FinalDimensions.Single().LayoutBlockType == "RootedAlignmentLane"
				&& Math.Abs(plan.Diagnostics.FinalDimensions.Single().EffectiveSpan - 30.0) <= 1E-09
				&& plan.Diagnostics.FinalDimensions.Single().PhysicalOrderValidated,
				"final placement diagnostics must expose v203 layout-block and physical-order metadata");
			Assert(dimension.Side == DimensionSide.Bottom
				&& plan.Diagnostics.FinalDimensions.Single().PlacementSide == DimensionSide.Bottom.ToString()
				&& plan.Diagnostics.FinalDimensions.Single().RequestedPlacementSide == DimensionSide.Top.ToString(),
				"final placement side must synchronize back to rendering while preserving the requested side");
		}

		private static void RuleEvidenceRejectsReassignmentAndRenderSuppressionStaysCompatible()
		{
			const string ruleId = "OuterContourStepOverallRemainder";
			var plan = new DimensionPlan();
			var dimension = CreateTestDimension(
				DimensionKind.Normal,
				DimensionOrientation.Horizontal,
				DimensionSide.Bottom,
				new Point2D(0.0, 0.0),
				new Point2D(20.0, 0.0),
				"BottomStructWidth");
			plan.Add(dimension);
			plan.RecordRuleEvidence(dimension, ruleId, new[] { "edge-a" }, "first");
			plan.RecordRuleEvidence(dimension, ruleId, new[] { "edge-b" }, "second");

			var diagnostic = plan.Diagnostics.DimensionCandidates.Single();
			Assert(dimension.RuleId == ruleId
					&& diagnostic.RuleId == ruleId
					&& diagnostic.SourceGeometryIds.Contains("edge-a")
					&& diagnostic.SourceGeometryIds.Contains("edge-b"),
				"recording the same RuleId again must be idempotent and merge evidence");

			bool rejected = false;
			try
			{
				plan.RecordRuleEvidence(dimension, "DifferentRule");
			}
			catch (InvalidOperationException)
			{
				rejected = true;
			}
			Assert(rejected && dimension.RuleId == ruleId && diagnostic.RuleId == ruleId,
				"a candidate with a non-empty RuleId must reject reassignment to another rule");

			plan.CaptureFinalDimensions();
			plan.Diagnostics.RecordRenderSuppressed(dimension.DiagnosticId, "RenderConflict");
			Assert(diagnostic.Decision == DimensionCandidateDecision.Suppressed
					&& diagnostic.DecisionStatus == "RenderSuppressed",
				"render suppression must expose formal Suppressed while preserving the legacy status");
			Assert(plan.Diagnostics.FinalDimensions.Count == 0,
				"render-suppressed dimensions must be removed from final diagnostics");
		}

		private static void FormattedDimensionTextLengthIgnoresControlCodes()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimension = new DimensionLayoutItem
			{
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 15.0),
				Span = 15.0,
				OverrideText = "15\\H0.8x;\u00B10.02\\H1x;"
			};

			double length = rules.GetDimensionTextLength(dimension, 2.5);

			Assert(Math.Abs(length - 10.5) <= config.GeometryTolerance,
				"formatted tolerance control codes must not count as visible glyphs when estimating dimension text length");
		}

		private static void FittingVerticalLocalTextStaysCentered()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimension = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(20.0, 0.0),
				SecondPoint = new Point2D(20.0, 15.0),
				Span = 15.0,
				OverrideText = "15\\H0.8x;\u00B10.02\\H1x;",
				PreferLocalBoundary = true
			};
			var dimLinePoint = new Point2D(-10.0, 7.5);
			var placed = new DimensionTextPlacementItem
			{
				Dimension = dimension,
				Side = DimensionSide.Left,
				DimLinePoint = dimLinePoint,
				TextBounds = rules.ComputePlacedTextBounds(dimension, dimLinePoint, isHorizontal: false, textHeight: 2.5)
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(new[] { placed }, new TextBounds2D[0], 2.5, 2.5, 3.0);

			Assert(slides.Count == 1 && rules.DimensionTextFitsBetweenOwnExtensionLines(dimension, 2.5),
				"dimension text that fits between its own extension lines must receive an explicit centered position");
			Assert(Math.Abs(slides[0].TextPosition.X + 10.0) <= config.GeometryTolerance
				&& Math.Abs(slides[0].TextPosition.Y - 7.5) <= config.GeometryTolerance,
				"fitting vertical text must stay at the center of its dimension line even when arrow clearance is tighter");
		}

		private static void HardTextOverlapSlidesVerticalDatumOnSameSide()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var datum = new DimensionLayoutItem
			{
				Kind = DimensionKind.DatumHoleLocationY,
				FirstPoint = new Point2D(20.0, 0.0),
				SecondPoint = new Point2D(20.0, 10.0),
				Span = 10.0,
				OverrideText = "<>\\H0.8x;\u00B10.05\\H1x;"
			};
			var neighbor = new DimensionLayoutItem
			{
				Kind = DimensionKind.PinDistance,
				FirstPoint = new Point2D(20.0, 10.0),
				SecondPoint = new Point2D(20.0, 40.0),
				Span = 30.0,
				OverrideText = "30\\H0.8x;\u00B10.02\\H1x;"
			};
			var datumLine = new Point2D(30.0, 5.0);
			var neighborLine = new Point2D(30.0, 25.0);
			var placed = new[]
			{
				new DimensionTextPlacementItem
				{
					Dimension = datum,
					Side = DimensionSide.Right,
					DimLinePoint = datumLine,
					TextBounds = rules.ComputePlacedTextBounds(datum, datumLine, isHorizontal: false, textHeight: 2.5)
				},
				new DimensionTextPlacementItem
				{
					Dimension = neighbor,
					Side = DimensionSide.Right,
					DimLinePoint = neighborLine,
					TextBounds = rules.ComputePlacedTextBounds(neighbor, neighborLine, isHorizontal: false, textHeight: 2.5)
				}
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(placed, new TextBounds2D[0], 2.5, 2.5, 3.0);
			var datumSlide = slides.Single(slide => slide.Index == 0);

			Assert(datumSlide.TextPosition.X == datumLine.X && datumSlide.TextPosition.Y < datumLine.Y,
				"vertical hard text overlap must slide the datum along the existing right-side lane");
			Assert(!rules.TextBoundsOverlap(datumSlide.TextBounds, placed[1].TextBounds, 0.0),
				"vertical datum slide must clear the neighboring dimension text");
		}

		private static void HardTextOverlapSlidesHorizontalDatumOnSameSide()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var datum = new DimensionLayoutItem
			{
				Kind = DimensionKind.DatumHoleLocationX,
				FirstPoint = new Point2D(0.0, 20.0),
				SecondPoint = new Point2D(10.0, 20.0),
				Span = 10.0,
				OverrideText = "<>\\H0.8x;\u00B10.05\\H1x;"
			};
			var neighbor = new DimensionLayoutItem
			{
				Kind = DimensionKind.PinDistance,
				FirstPoint = new Point2D(-5.0, 20.0),
				SecondPoint = new Point2D(25.0, 20.0),
				Span = 30.0,
				OverrideText = "30\\H0.8x;\u00B10.02\\H1x;"
			};
			var datumLine = new Point2D(5.0, 30.0);
			var neighborLine = new Point2D(10.0, 30.0);
			var placed = new[]
			{
				new DimensionTextPlacementItem
				{
					Dimension = datum,
					Side = DimensionSide.Top,
					DimLinePoint = datumLine,
					TextBounds = rules.ComputePlacedTextBounds(datum, datumLine, isHorizontal: true, textHeight: 2.5)
				},
				new DimensionTextPlacementItem
				{
					Dimension = neighbor,
					Side = DimensionSide.Top,
					DimLinePoint = neighborLine,
					TextBounds = rules.ComputePlacedTextBounds(neighbor, neighborLine, isHorizontal: true, textHeight: 2.5)
				}
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(placed, new TextBounds2D[0], 2.5, 2.5, 3.0);
			var datumSlide = slides.Single(slide => slide.Index == 0);

			Assert(datumSlide.TextPosition.Y == datumLine.Y && datumSlide.TextPosition.X < datumLine.X,
				"horizontal hard text overlap must slide the datum along the existing top-side lane");
			Assert(!rules.TextBoundsOverlap(datumSlide.TextBounds, placed[1].TextBounds, 0.0),
				"horizontal datum slide must clear the neighboring dimension text");
		}

		private static void NonOverlappingDatumTextDoesNotSlide()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var datum = new DimensionLayoutItem
			{
				Kind = DimensionKind.DatumHoleLocationY,
				FirstPoint = new Point2D(20.0, 0.0),
				SecondPoint = new Point2D(20.0, 10.0),
				Span = 10.0,
				OverrideText = "<>\\H0.8x;\u00B10.05\\H1x;"
			};
			var dimLine = new Point2D(30.0, 5.0);
			var placed = new DimensionTextPlacementItem
			{
				Dimension = datum,
				Side = DimensionSide.Right,
				DimLinePoint = dimLine,
				TextBounds = rules.ComputePlacedTextBounds(datum, dimLine, isHorizontal: false, textHeight: 2.5)
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(new[] { placed }, new TextBounds2D[0], 2.5, 2.5, 3.0);

			Assert(slides.Count == 0, "a datum dimension without text overlap must keep its default placement");
		}

		private static void ShortVerticalLocalTextClearsArrowheads()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimension = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(20.0, 0.0),
				SecondPoint = new Point2D(20.0, 8.0),
				Span = 8.0,
				OverrideText = "15\\H0.8x;\u00B10.02\\H1x;",
				PreferLocalBoundary = true
			};
			var dimLinePoint = new Point2D(-10.0, 4.0);
			var placed = new DimensionTextPlacementItem
			{
				Dimension = dimension,
				Side = DimensionSide.Left,
				DimLinePoint = dimLinePoint,
				TextBounds = rules.ComputePlacedTextBounds(dimension, dimLinePoint, isHorizontal: false, textHeight: 2.5)
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(new[] { placed }, new TextBounds2D[0], 2.5, 2.5, 3.0);

			Assert(slides.Count == 1, "a short vertical local dimension must move its text outside its arrowheads");
			TextBounds2D bounds = slides[0].TextBounds;
			Assert(bounds.MaxY <= -5.5 + config.GeometryTolerance || bounds.MinY >= 13.5 - config.GeometryTolerance,
				"vertical external text must keep the configured clearance beyond the arrowhead envelope");
		}

		private static void FittingHorizontalTextStaysCenteredDespiteNeighborArrow()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var target = new DimensionLayoutItem
			{
				Kind = DimensionKind.PinGroupDistance,
				FirstPoint = new Point2D(0.0, 20.0),
				SecondPoint = new Point2D(223.5, 20.0),
				Span = 223.5,
				OverrideText = "223.5\\H0.8x;\u00B10.05\\H1x;"
			};
			var neighbor = new DimensionLayoutItem
			{
				Kind = DimensionKind.PinDistance,
				FirstPoint = new Point2D(111.75, 30.0),
				SecondPoint = new Point2D(130.0, 30.0),
				Span = 18.25,
				OverrideText = "18.25"
			};
			var targetLinePoint = new Point2D(111.75, -10.0);
			var neighborLinePoint = new Point2D(120.875, -10.0);
			var placed = new[]
			{
				new DimensionTextPlacementItem
				{
					Dimension = target,
					Side = DimensionSide.Bottom,
					DimLinePoint = targetLinePoint,
					TextBounds = rules.ComputePlacedTextBounds(target, targetLinePoint, isHorizontal: true, textHeight: 2.5)
				},
				new DimensionTextPlacementItem
				{
					Dimension = neighbor,
					Side = DimensionSide.Bottom,
					DimLinePoint = neighborLinePoint,
					TextBounds = rules.ComputePlacedTextBounds(neighbor, neighborLinePoint, isHorizontal: true, textHeight: 2.5)
				}
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(placed, new TextBounds2D[0], 2.5, 2.5, 3.0);
			var targetPlacement = slides.Single(slide => slide.Index == 0);

			Assert(rules.DimensionTextFitsBetweenOwnExtensionLines(target, 2.5),
				"the long formatted dimension must fit between its own extension lines");
			Assert(Math.Abs(targetPlacement.TextPosition.X - 111.75) <= config.GeometryTolerance
				&& Math.Abs(targetPlacement.TextPosition.Y + 10.0) <= config.GeometryTolerance,
				"fitting horizontal text must stay explicitly centered even when another dimension arrow is nearby");
		}

		private static void ShortHorizontalLocalTextClearsArrowheads()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimension = new DimensionLayoutItem
			{
				Kind = DimensionKind.PinDistance,
				FirstPoint = new Point2D(0.0, 20.0),
				SecondPoint = new Point2D(8.0, 20.0),
				Span = 8.0,
				OverrideText = "15\\H0.8x;\u00B10.02\\H1x;"
			};
			var dimLinePoint = new Point2D(4.0, -10.0);
			var placed = new DimensionTextPlacementItem
			{
				Dimension = dimension,
				Side = DimensionSide.Bottom,
				DimLinePoint = dimLinePoint,
				TextBounds = rules.ComputePlacedTextBounds(dimension, dimLinePoint, isHorizontal: true, textHeight: 2.5)
			};

			var slides = rules.SelectShortLocalDimensionTextSlides(new[] { placed }, new TextBounds2D[0], 2.5, 2.5, 3.0);

			Assert(slides.Count == 1, "a short horizontal local dimension must move its text outside its arrowheads");
			TextBounds2D bounds = slides[0].TextBounds;
			Assert(bounds.MaxX <= -5.5 + config.GeometryTolerance || bounds.MinX >= 13.5 - config.GeometryTolerance,
				"horizontal external text must keep the configured clearance beyond the arrowhead envelope");
		}

		private static void ShortVerticalChainTextAvoidsNeighborArrowheads()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimensions = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.HoleLocation,
					FirstPoint = new Point2D(20.0, 0.0),
					SecondPoint = new Point2D(20.0, 8.0),
					Span = 8.0,
					OverrideText = "15\\H0.8x;\u00B10.02\\H1x;",
					PreferLocalBoundary = true,
					LooseChainId = 1
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.HoleLocation,
					FirstPoint = new Point2D(20.0, 8.0),
					SecondPoint = new Point2D(20.0, 16.0),
					Span = 8.0,
					OverrideText = "15\\H0.8x;\u00B10.02\\H1x;",
					PreferLocalBoundary = true,
					LooseChainId = 1
				}
			};
			var placed = dimensions.Select(dimension =>
			{
				var dimLinePoint = new Point2D(-10.0, (dimension.FirstPoint.Y + dimension.SecondPoint.Y) / 2.0);
				return new DimensionTextPlacementItem
				{
					Dimension = dimension,
					Side = DimensionSide.Left,
					DimLinePoint = dimLinePoint,
					TextBounds = rules.ComputePlacedTextBounds(dimension, dimLinePoint, isHorizontal: false, textHeight: 2.5)
				};
			}).ToList();

			var slides = rules.SelectShortLocalDimensionTextSlides(placed, new TextBounds2D[0], 2.5, 2.5, 3.0);
			var first = slides.Single(slide => slide.Index == 0);
			var second = slides.Single(slide => slide.Index == 1);

			Assert(first.TextBounds.MaxY <= -5.5 + config.GeometryTolerance,
				"the first short-chain label must choose the free side away from the neighboring arrowheads");
			Assert(second.TextBounds.MinY >= 21.5 - config.GeometryTolerance,
				"the second short-chain label must choose the opposite free side away from the neighboring arrowheads");
			Assert(!rules.TextBoundsOverlap(first.TextBounds, second.TextBounds, 3.0),
				"external labels in one short chain must preserve their configured mutual clearance");
		}

		private static void InvalidDatumCoordinateIsSkippedWithDiagnostic()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var datumPin = CreateHole(20.0, 20.0, 6.0, HoleKind2D.Pin);
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = datumPin;
			datum.DatumHoleLocationBaseX = 150.0;
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				datumPin,
				CreateHole(60.0, 20.0, 6.0, HoleKind2D.Pin)
			});
			var skipped = plan.Diagnostics.DimensionCandidates.Single(candidate => candidate.DebugRole == "DatumX"
				&& candidate.DecisionStatus == "Skipped");

			Assert(skipped.IsAttachmentValid == false && !skipped.IsSelected && !skipped.IsSuppressed,
				"an invalid datum coordinate must be skipped without pretending it was selected or suppressed");
			Assert(skipped.DecisionReason.StartsWith("NoRealOutlineAttachment:XDatum=", StringComparison.Ordinal),
				"an invalid datum coordinate must retain a machine-readable skip reason");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "DatumY"),
				"a bad X datum must not discard the valid Y datum dimension");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth)
				&& plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight),
				"a skipped datum dimension must not discard valid overall dimensions");
		}

		private static void InvalidSlotDatumIsSkippedWithDiagnostic()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var datum = Datum2D.FromOutline(outline);
			datum.BaseX = 150.0;
			var slot = new SlotFeature2D
			{
				GroupId = "INVALID-SLOT-DATUM",
				FirstCenter = new Point2D(20.0, 25.0),
				SecondCenter = new Point2D(60.0, 25.0),
				Radius = 5.0,
				CenterDistance = 40.0
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new HoleFeature2D[0], new[] { slot });
			var skipped = plan.Diagnostics.DimensionCandidates.Where(candidate => candidate.DecisionStatus == "Skipped").ToList();

			Assert(skipped.Any(candidate => candidate.DebugRole == "SlotDatumH" || candidate.DebugRole == "SlotChainH"),
				"an invalid slot datum must create an explicit skipped diagnostic");
			Assert(skipped.All(candidate => candidate.IsAttachmentValid == false
				&& candidate.DecisionReason.StartsWith("NoRealOutlineAttachment:", StringComparison.Ordinal)),
				"every skipped slot datum must report an invalid real-outline attachment");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "SlotCenter" && Math.Abs(GetSpan(d) - 40.0) <= 0.001),
				"an invalid slot datum must not discard a valid slot center dimension");
		}

        private static void ClosedPathRecognitionBuildsOutline()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new FeatureRecognizer2D(config).RecognizeOutlineFromClosedPath(new[]
            {
                new Point2D(0.0, 0.0),
                new Point2D(80.0, 0.0),
                new Point2D(80.0, 30.0),
                new Point2D(0.0, 30.0)
            });
            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(outline.Segments.Count == 4, "closed path should create four outline segments");
            AssertHasDimension(plan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 80.0, "closed path width");
            AssertHasDimension(plan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 30.0, "closed path height");
        }

        private static void NonFortyFiveSlopeIsNotChamfer()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 35.0), "right");
            AddSegment(outline, new Point2D(100.0, 35.0), new Point2D(80.0, 50.0), "slope");
            AddSegment(outline, new Point2D(80.0, 50.0), new Point2D(0.0, 50.0), "top");
            AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 0.0), "left");

            new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);

            Assert(outline.Chamfers.Count == 0, "non-45-degree slope should not be recognized as chamfer");
        }

        private static void VerticalStructurePointsCreateStepWidths()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 50.0), "left");
            AddSegment(outline, new Point2D(40.0, 10.0), new Point2D(40.0, 45.0), "middle");
            AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 50.0), "right");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(plan.Dimensions.Any(d =>
                    (d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
                    && d.Orientation == DimensionOrientation.Horizontal
                    && Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 40.0) <= 0.001),
                "expected structure width from left boundary to middle vertical");
            Assert(plan.Dimensions.Any(d =>
                    d.DebugRole == "BottomStructWidth"
                    && d.Orientation == DimensionOrientation.Horizontal
                    && Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 40.0) <= 0.001),
                "expected bottom structure width to keep the non-removed candidate");
            Assert(!plan.Dimensions.Any(d =>
                    d.DebugRole == "BottomStructWidth"
                    && d.Orientation == DimensionOrientation.Horizontal
                    && Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 60.0) <= 0.001),
                "bottom structure width should remove the longest extension candidate");
            Assert(plan.Dimensions.Where(d => d.DebugRole == "TopStructWidth").All(d =>
                    d.AlignmentKey == "Structure:T:H" && d.AlignmentPriority == 70),
                "top structure widths must share Structure:T:H alignment key");
            Assert(plan.Dimensions.Where(d => d.DebugRole == "BottomStructWidth").All(d =>
                    d.AlignmentKey == "Structure:B:H" && d.AlignmentPriority == 70),
                "bottom structure widths must share Structure:B:H alignment key");
        }

		private static void BottomStructureRejectsCrossAxisProjection()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 338.0,
				MaxY = 201.5
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 201.5), "left");
			AddSegment(outline, new Point2D(305.0, 176.5), new Point2D(305.0, 201.5), "high-shoulder");
			AddSegment(outline, new Point2D(338.0, 0.0), new Point2D(338.0, 201.5), "right");

			var plan = new DimensionPlan();
			var retained = new DimensionPlanner(config).BuildBottomStructureWidthDimensions(outline, plan);
			var bottomCandidates = plan.Diagnostics.DimensionCandidates
				.Where(candidate => candidate.DebugRole == "BottomStructWidth")
				.ToList();

			Assert(bottomCandidates.Any(candidate => Math.Abs(candidate.Value - 33.0) <= config.GeometryTolerance
					&& Math.Abs(Math.Abs(candidate.SecondPointY - candidate.FirstPointY) - 176.5) <= config.GeometryTolerance),
				"cross-axis BottomStructWidth 33 candidate must be generated from the complete structure path");
			Assert(bottomCandidates.Any(candidate => Math.Abs(candidate.Value - 33.0) <= config.GeometryTolerance
					&& candidate.DecisionReason == "NotBottomSideStructureCandidate"),
				"cross-axis BottomStructWidth 33 must be rejected with NotBottomSideStructureCandidate");
			Assert(retained.Any(dimension => dimension.DebugRole == "BottomStructWidth"
					&& Math.Abs(Math.Abs(dimension.SecondPoint.X - dimension.FirstPoint.X) - 305.0) <= config.GeometryTolerance),
				"valid BottomStructWidth 305 must remain selected (got: "
				+ string.Join(",", bottomCandidates.Select(candidate => candidate.Value + "/" + candidate.DecisionStatus + "/" + candidate.DecisionReason))
				+ ")");
		}

		private static void StructureWidthsThatPartitionOverallAreSuppressed()
		{
			// Cross-side partition: BottomStruct 25 + TopStruct 232 = Overall 257 → both suppressed.
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 257.0,
				MaxY = 20.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(25.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(25.0, 20.0), "shoulder");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(257.0, 0.0), "bottom-main");
			AddSegment(outline, new Point2D(257.0, 0.0), new Point2D(257.0, 20.0), "right");
			AddSegment(outline, new Point2D(257.0, 20.0), new Point2D(0.0, 20.0), "top");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 257.0) <= config.GeometryTolerance),
				"overall width 257 must remain");
			// Selected structure widths must not form an overall partition pair.
			var selectedStruct = plan.Dimensions
				.Where(d => d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
				.ToList();
			Assert(!selectedStruct.Any(a => selectedStruct.Any(b => a != b
					&& Math.Abs(Math.Abs(a.SecondPoint.X - a.FirstPoint.X) + Math.Abs(b.SecondPoint.X - b.FirstPoint.X) - 257.0) <= config.GeometryTolerance)),
				"no selected structure pair may partition overall 257");
			// Complementary remainder / partition should remove the long leftover edge 232.
			Assert(!selectedStruct.Any(d => Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 232.0) <= config.GeometryTolerance),
				"structure width 232 (overall remainder) must not remain selected");
		}

		/// <summary>
		/// Repro of GEN|BSW1|GB|B|L0: bottom edge split 20+78 = overall 98 with a shoulder.
		/// BottomStructWidth 20 + OutlineSegment 78 form a true overall partition → structure must suppress.
		/// </summary>
		private static void StructureWidthThatPartitionsOverallWithOutlineSegmentIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 98.0,
				MaxY = 20.0
			};
			// Bottom/top collinear splits + full-height shoulder at x=20 (matches last-run geometry).
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(20.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(98.0, 0.0), "bottom-right");
			AddSegment(outline, new Point2D(98.0, 0.0), new Point2D(98.0, 20.0), "right");
			AddSegment(outline, new Point2D(98.0, 20.0), new Point2D(20.0, 20.0), "top-right");
			AddSegment(outline, new Point2D(20.0, 20.0), new Point2D(0.0, 20.0), "top-left");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(20.0, 20.0), "shoulder");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 98.0) <= config.GeometryTolerance),
				"overall width 98 must remain");
			// Decision A: keep the short step length, drop the long remainder (OS/structure 78).
			Assert(plan.Dimensions.Any(d =>
					(d.DebugRole == "BottomStructWidth" || d.DebugRole == "TopStructWidth")
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 20.0) <= config.GeometryTolerance),
				"short structure step 20 must remain (decision A with overall 98)");
			Assert(!plan.Dimensions.Any(d =>
					(d.DebugRole == "BottomStructWidth" || d.DebugRole == "TopStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 78.0) <= config.GeometryTolerance),
				"long remainder 78 that closes overall with step 20 must not remain");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment"
					&& d.Orientation == DimensionOrientation.Horizontal),
				"horizontal OutlineSegment partition pieces must be suppressed");
		}

		/// <summary>
		/// Repro last-run BSW 9+11 + TSW 71 = overall 91 (pairwise incomplete, chain complete).
		/// BuildOverallPartitionChain must suppress all three structure widths.
		/// </summary>
		private static void ThreeStructureWidthsThatPartitionOverallAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 91.0,
				MaxY = 20.0
			};
			// Two shoulders at x=9 and x=20 → structure chain [0,9]+[9,20]+[20,91].
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(9.0, 0.0), "bottom-a");
			AddSegment(outline, new Point2D(9.0, 0.0), new Point2D(20.0, 0.0), "bottom-b");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(91.0, 0.0), "bottom-c");
			AddSegment(outline, new Point2D(91.0, 0.0), new Point2D(91.0, 20.0), "right");
			AddSegment(outline, new Point2D(91.0, 20.0), new Point2D(20.0, 20.0), "top-c");
			AddSegment(outline, new Point2D(20.0, 20.0), new Point2D(9.0, 20.0), "top-b");
			AddSegment(outline, new Point2D(9.0, 20.0), new Point2D(0.0, 20.0), "top-a");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(9.0, 0.0), new Point2D(9.0, 20.0), "shoulder-9");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(20.0, 20.0), "shoulder-20");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 91.0) <= config.GeometryTolerance),
				"overall width 91 must remain");
			// BSW 9 and 11 (and any TSW that completes the overall chain) must not stay selected.
			Assert(!plan.Dimensions.Any(d =>
					(d.DebugRole == "BottomStructWidth" || d.DebugRole == "TopStructWidth")
					&& (Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 9.0) <= config.GeometryTolerance
						|| Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 11.0) <= config.GeometryTolerance)),
				"BottomStructWidth 9 and 11 that partition overall must not remain selected");
			var structCandidates = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "BottomStructWidth" || c.DebugRole == "TopStructWidth")
				.ToList();
			var bsw9 = structCandidates.Where(c => Math.Abs(c.Value - 9.0) <= config.GeometryTolerance).ToList();
			var bsw11 = structCandidates.Where(c => Math.Abs(c.Value - 11.0) <= config.GeometryTolerance).ToList();
			Assert(bsw9.Count > 0 && bsw9.All(c => c.IsSuppressed),
				"structure width 9 must be generated and suppressed (got: "
				+ string.Join(",", structCandidates.Select(c => c.DebugRole + "=" + c.Value + "/" + c.SuppressedReason + "/sel=" + c.IsSelected)) + ")");
			Assert(bsw11.Count > 0 && bsw11.All(c => c.IsSuppressed),
				"structure width 11 must be generated and suppressed");
			Assert(bsw9.Concat(bsw11).All(c => c.SuppressedReason == "LocalGeometryOnOverallEnvelope"),
				"outer-envelope structure chain members must record the higher-priority envelope reason");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "OutlineSegment" && d.Side == DimensionSide.Bottom),
				"bottom OutlineSegment chain covering overall must also be suppressed by outline rule");
		}

		private static void LocalTopStructureWidthIsKeptWhenNotPartitioningOverall()
		{
			// Local step width 40 on overall 100 — must keep structure width (positioning), not treat as overall partition.
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 50.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 50.0), "left");
			AddSegment(outline, new Point2D(40.0, 10.0), new Point2D(40.0, 45.0), "middle");
			AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 50.0), "right");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d =>
					(d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 40.0) <= config.GeometryTolerance),
				"local structure width 40 must remain when it does not partition overall 100");
			Assert(plan.Diagnostics.DimensionCandidates
					.Where(c => (c.DebugRole == "TopStructWidth" || c.DebugRole == "BottomStructWidth")
						&& Math.Abs(c.Value - 40.0) <= config.GeometryTolerance)
					.All(c => c.SuppressedReason != "StructureOverallPartition"),
				"local structure width must not be suppressed as StructureOverallPartition");
		}

		/// <summary>
		/// L-shape regression after bottom-step fix: TopStructWidth 20 (tower) must not be killed
		/// by StructureOverallPartition with Top OutlineSegment 71 on the arm (same Side=Top,
		/// different Y — not collinear). Right arm height 20 lies on MaxX and must be suppressed.
		/// </summary>
		private static void LShapeTowerTopWidthIsKeptDespiteArmTopOutlineSegment()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 91.0,
				MaxY = 50.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(91.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(91.0, 0.0), new Point2D(91.0, 20.0), "right-arm");
			AddSegment(outline, new Point2D(91.0, 20.0), new Point2D(20.0, 20.0), "arm-top");
			AddSegment(outline, new Point2D(20.0, 20.0), new Point2D(20.0, 39.0), "step-up");
			AddSegment(outline, new Point2D(20.0, 39.0), new Point2D(9.0, 50.0), "chamfer");
			AddSegment(outline, new Point2D(9.0, 50.0), new Point2D(0.0, 50.0), "tower-top");
			AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 91.0) <= config.GeometryTolerance),
				"overall width 91 must remain");
			Assert(plan.Dimensions.Any(d =>
					d.DebugRole == "TopStructWidth"
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 20.0) <= config.GeometryTolerance),
				"tower top width 20 must remain (not erased by arm-top OutlineSegment via StructureOverallPartition)");
			Assert(plan.Dimensions.Any(d =>
					d.DebugRole == "RightStructHeight"
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 20.0) <= config.GeometryTolerance),
				"right arm height 20 on stepped MaxX must be kept (edge is not full-length)");
			Assert(plan.Diagnostics.DimensionCandidates
					.Where(c => c.DebugRole == "TopStructWidth" && Math.Abs(c.Value - 20.0) <= config.GeometryTolerance)
					.All(c => c.SuppressedReason != "StructureOverallPartition"),
				"tower top width must not be StructureOverallPartition against non-collinear arm OS");
		}

		/// <summary>
		/// Stepped bottom: overall width 215, lower ledge width 120 on MinY. MinY is not a
		/// full-length envelope edge (coverage 120 &lt; 215), so the step face is kept.
		/// Upper undercut stops short of the step (gap) so StructureOverallPartition cannot form
		/// 95+120 against overall 215.
		/// </summary>
		private static void BottomStepWidthOnOverallEnvelopeIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			// Left undercut Y=40 for X in [0,80]; gap 80→95; lower ledge Y=0 for X in [95,215] (span 120).
			AddSegment(outline, new Point2D(0.0, 40.0), new Point2D(80.0, 40.0), "upper-bottom");
			AddSegment(outline, new Point2D(80.0, 40.0), new Point2D(95.0, 40.0), "upper-to-step");
			AddSegment(outline, new Point2D(95.0, 40.0), new Point2D(95.0, 0.0), "step-down");
			AddSegment(outline, new Point2D(95.0, 0.0), new Point2D(215.0, 0.0), "lower-ledge");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 40.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 215.0) <= config.GeometryTolerance),
				"overall width 215 must remain");
			Assert(plan.Dimensions.Any(d =>
					d.DebugRole == "BottomStructWidth"
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 120.0) <= config.GeometryTolerance),
				"bottom step/ledge width 120 on partial MinY must be kept");
			Assert(!plan.Dimensions.Any(d => d.Orientation == DimensionOrientation.Horizontal
					&& Math.Abs(GetSpan(d) - 95.0) <= config.GeometryTolerance),
				"projected body remainder 95 must be removed even though the real step 120 is longer");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 95.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& c.SuppressedReason == "OuterContourStepOverallRemainder"),
				"body remainder 95 must record topology-based outer-step suppression");
		}

		private static void BottomProtrusionSuppressesOuterWidthAndInnerLedge()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 287.0,
				MaxY = 110.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(50.0, 0.0), "bottom-protrusion");
			AddSegment(outline, new Point2D(50.0, 0.0), new Point2D(50.0, 10.0), "protrusion-riser");
			AddSegment(outline, new Point2D(50.0, 10.0), new Point2D(70.0, 10.0), "inner-ledge");
			AddSegment(outline, new Point2D(70.0, 10.0), new Point2D(70.0, 110.0), "inner-left");
			AddSegment(outline, new Point2D(70.0, 110.0), new Point2D(287.0, 110.0), "top-right");
			AddSegment(outline, new Point2D(287.0, 110.0), new Point2D(287.0, 10.0), "right");
			AddSegment(outline, new Point2D(287.0, 10.0), new Point2D(70.0, 10.0), "inner-bottom");
			AddSegment(outline, new Point2D(70.0, 110.0), new Point2D(0.0, 110.0), "top-left");
			AddSegment(outline, new Point2D(0.0, 110.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.DebugRole == "BottomStructWidth"
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 50.0) <= config.GeometryTolerance),
				"bottom protrusion width 50 on partial MinY must be kept");
			Assert(!plan.Dimensions.Any(d => (d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 20.0) <= config.GeometryTolerance),
				"inner ledge width 20 must not remain selected");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.IsSuppressed
					&& Math.Abs(c.Value - 20.0) <= config.GeometryTolerance
					&& c.SuppressedReason == "BottomProtrusionInnerRemainder"),
				"inner ledge candidates must record BottomProtrusionInnerRemainder");
		}

		private static void BottomFilletedProtrusionWidthIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 90.0,
				MaxY = 53.5
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(20.0, 0.0), "bottom-step");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(20.0, 23.5), "step-riser");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(20.0, 23.5),
				End = new Point2D(30.0, 33.5),
				Center = new Point2D(30.0, 23.5),
				Radius = 10.0,
				Bulge = Math.Tan(Math.PI / 8.0),
				SourceKey = "step-fillet"
			});
			AddSegment(outline, new Point2D(30.0, 33.5), new Point2D(90.0, 33.5), "body-floor");
			AddSegment(outline, new Point2D(90.0, 33.5), new Point2D(90.0, 53.5), "right");
			AddSegment(outline, new Point2D(90.0, 53.5), new Point2D(0.0, 53.5), "top");
			AddSegment(outline, new Point2D(0.0, 53.5), new Point2D(0.0, 0.0), "left");
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(outline.Fillets.Count == 1, "step fillet must be recognized");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "BottomStructWidth"
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 20.0) <= config.GeometryTolerance),
				"filleted bottom protrusion width 20 on partial MinY must be kept");
		}

		private static void ChamferedTopStepUsesCompositeDimensions()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 90.0,
				MaxY = 53.5
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(90.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(90.0, 33.5), "right-body");
			AddSegment(outline, new Point2D(0.0, 33.5), new Point2D(70.0, 33.5), "body-floor");
			AddSegment(outline, new Point2D(70.0, 33.5), new Point2D(90.0, 33.5), "step-floor");
			AddSegment(outline, new Point2D(70.0, 33.5), new Point2D(70.0, 47.0), "step-left-low");
			AddSegment(outline, new Point2D(70.0, 47.0), new Point2D(71.0, 48.0), "step-left-chamfer-low");
			AddSegment(outline, new Point2D(71.0, 48.0), new Point2D(71.0, 52.5), "step-left-high");
			AddSegment(outline, new Point2D(71.0, 52.5), new Point2D(70.0, 53.5), "step-left-chamfer-top");
			AddSegment(outline, new Point2D(70.0, 53.5), new Point2D(90.0, 53.5), "step-top");
			AddSegment(outline, new Point2D(90.0, 33.5), new Point2D(90.0, 47.0), "step-right-low");
			AddSegment(outline, new Point2D(90.0, 47.0), new Point2D(89.0, 48.0), "step-right-chamfer-low");
			AddSegment(outline, new Point2D(89.0, 48.0), new Point2D(89.0, 52.5), "step-right-high");
			AddSegment(outline, new Point2D(89.0, 52.5), new Point2D(90.0, 53.5), "step-right-chamfer-top");
			AddSegment(outline, new Point2D(0.0, 53.5), new Point2D(0.0, 0.0), "left");
			outline.Chamfers.Add(new ChamferFeature2D { StartPoint = new Point2D(70.0, 47.0), EndPoint = new Point2D(71.0, 48.0) });
			outline.Chamfers.Add(new ChamferFeature2D { StartPoint = new Point2D(71.0, 52.5), EndPoint = new Point2D(70.0, 53.5) });
			outline.Chamfers.Add(new ChamferFeature2D { StartPoint = new Point2D(90.0, 47.0), EndPoint = new Point2D(89.0, 48.0) });
			outline.Chamfers.Add(new ChamferFeature2D { StartPoint = new Point2D(89.0, 52.5), EndPoint = new Point2D(90.0, 53.5) });

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.DebugRole == "TopChamferedStepWidth"
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 20.0) <= config.GeometryTolerance),
				"chamfered top step width 20 must remain selected");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "RightChamferedStepHeight"
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 20.0) <= config.GeometryTolerance),
				"chamfered top step height 20 on stepped MaxX must be kept");
		}

		private static void InteriorHorizontalOutlineSegmentPrefersNonCrossingSide()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 90.0, MaxY = 28.0 };
			// Shaft: interior horizontal edge at y=8.26 with solid above and free space below.
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(70.0, 0.0), "bottom-body");
			AddSegment(outline, new Point2D(70.0, 0.0), new Point2D(90.0, 0.0), "bottom-step");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(90.0, 8.26), "step-right-low");
			AddSegment(outline, new Point2D(90.0, 8.26), new Point2D(70.0, 8.26), "step-shelf");
			AddSegment(outline, new Point2D(70.0, 8.26), new Point2D(70.0, 28.0), "shoulder");
			AddSegment(outline, new Point2D(70.0, 28.0), new Point2D(0.0, 28.0), "body-top");
			AddSegment(outline, new Point2D(0.0, 28.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(0.0, 8.26), new Point2D(70.0, 8.26), "interior-body");
			var planner = new DimensionPlanner(config);
			var interior = new Segment2D(new Point2D(0.0, 8.26), new Point2D(70.0, 8.26));
			Assert(planner.ResolveHorizontalOutlineSegmentSide(interior, outline) == DimensionSide.Bottom,
				"interior horizontal body edge must resolve Bottom (free side), not Top through solid");
		}

		private static void TopEnvelopeHorizontalSegmentStaysTop()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 90.0, MaxY = 28.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(90.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(90.0, 28.0), "right");
			AddSegment(outline, new Point2D(90.0, 28.0), new Point2D(0.0, 28.0), "top");
			AddSegment(outline, new Point2D(0.0, 28.0), new Point2D(0.0, 0.0), "left");
			var top = new Segment2D(new Point2D(0.0, 28.0), new Point2D(90.0, 28.0));
			Assert(new DimensionPlanner(config).ResolveHorizontalOutlineSegmentSide(top, outline) == DimensionSide.Top,
				"MaxY envelope edge must stay Top");
		}

		private static void BottomEnvelopeHorizontalSegmentStaysBottom()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 90.0, MaxY = 28.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(90.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(90.0, 28.0), "right");
			AddSegment(outline, new Point2D(90.0, 28.0), new Point2D(0.0, 28.0), "top");
			AddSegment(outline, new Point2D(0.0, 28.0), new Point2D(0.0, 0.0), "left");
			var bottom = new Segment2D(new Point2D(0.0, 0.0), new Point2D(90.0, 0.0));
			Assert(new DimensionPlanner(config).ResolveHorizontalOutlineSegmentSide(bottom, outline) == DimensionSide.Bottom,
				"MinY envelope edge must stay Bottom");
		}

		private static void BottomBodyWidthNotDroppedByLongestExtension()
		{
			const string ruleId = "OuterContourStepOverallRemainder";
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 90.0, MaxY = 28.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(70.0, 0.0), "bottom-body");
			AddSegment(outline, new Point2D(70.0, 0.0), new Point2D(90.0, 0.0), "bottom-step");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(90.0, 20.0), "step-right");
			AddSegment(outline, new Point2D(90.0, 20.0), new Point2D(70.0, 20.0), "step-top");
			AddSegment(outline, new Point2D(70.0, 20.0), new Point2D(70.0, 28.0), "shoulder");
			AddSegment(outline, new Point2D(70.0, 28.0), new Point2D(0.0, 28.0), "body-top");
			AddSegment(outline, new Point2D(0.0, 28.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(70.0, 0.0), new Point2D(70.0, 20.0), "shoulder-down");
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(!plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 70.0) <= config.GeometryTolerance
					&& c.DecisionStatus == "Skipped"
					&& c.DecisionReason == "LongestExtensionCandidate"),
				"bottom body width 70 must not be silently dropped as LongestExtensionCandidate");
			// May be Selected or later Suppressed by closed-chain rules, but must be diagnosable.
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 70.0) <= config.GeometryTolerance),
				"bottom body width 70 must appear in diagnostics");
			// Four-way OuterContour may stamp RuleId on other sides; this fixture only forbids
			// claiming the same-level bottom body 70 as an outer-step remainder.
			Assert(!plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 70.0) <= config.GeometryTolerance
					&& c.RuleId == ruleId),
				"adjacent same-level bottom body 70 must not be claimed by the outer-step remainder rule");
		}

		private static void BottomOuterContourStepKeeps20AndSuppresses70Body()
		{
			const string ruleId = "OuterContourStepOverallRemainder";
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateOuterContourStepOutline(translateX: 0.0, translateY: 0.0);
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			var bottomBodyCandidates = plan.Diagnostics.DimensionCandidates.Where(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 70.0) <= config.GeometryTolerance)
				.ToList();
			var outlineBodyCandidates = plan.Diagnostics.DimensionCandidates.Where(c =>
					c.DebugRole == "OutlineSegment"
					&& Math.Abs(c.Value - 70.0) <= config.GeometryTolerance)
				.ToList();
			var leftResidualCandidates = plan.Diagnostics.DimensionCandidates.Where(c =>
					c.DebugRole == "LeftStructHeight"
					&& Math.Abs(c.Value - 8.26) <= config.GeometryTolerance)
				.ToList();
			Assert(bottomBodyCandidates.Count == 1,
				"projected BottomStructWidth body 70 must exist exactly once before suppression");
			Assert(outlineBodyCandidates.Count == 1,
				"OutlineSegment body 70 must exist exactly once before suppression");
			Assert(leftResidualCandidates.Count == 1,
				"projected left residual 8.26 must exist exactly once before suppression");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 20.0) <= config.GeometryTolerance),
				"real chamfered bottom outer step 20 must exist as a candidate");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "LeftStructHeight"
					&& Math.Abs(c.Value - 20.0) <= config.GeometryTolerance),
				"real partial MinX outer face 20 must exist as a candidate");

			var suppressedRemainders = bottomBodyCandidates
				.Concat(outlineBodyCandidates)
				.Concat(leftResidualCandidates)
				.ToList();
			Assert(suppressedRemainders.All(c => c.IsSuppressed
					&& c.Decision == DimensionCandidateDecision.Suppressed
					&& c.SuppressedReason == ruleId
					&& c.RuleId == ruleId),
				"all three projected remainders must have the unique outer-step RuleId and suppressed decision");
			Assert(bottomBodyCandidates[0].Role == DimensionCandidateRole.Structure
					&& outlineBodyCandidates[0].Role == DimensionCandidateRole.OutlineSegment
					&& leftResidualCandidates[0].Role == DimensionCandidateRole.Structure,
				"suppressed OC01 candidates must expose formal roles");
			Assert(suppressedRemainders.All(c => c.OwnerKind == DimensionCandidateOwnerKind.Outline),
				"suppressed OC01 candidates must belong to the outline");
			Assert(suppressedRemainders.All(c => c.SourceGeometryIds.Count > 0
					&& c.SourceGeometryIds.All(id => !string.IsNullOrWhiteSpace(id))),
				"suppressed OC01 candidates must retain source geometry ids");
			Assert(suppressedRemainders.All(c => !string.IsNullOrWhiteSpace(c.TopologyEvidence)),
				"suppressed OC01 candidates must retain topology evidence");

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(GetSpan(d) - 90.0) <= config.GeometryTolerance),
				"overall width 90 must remain");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "BottomStructWidth"
					&& Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance
					&& d.RuleId == ruleId),
				"real chamfered bottom outer step 20 must remain with rule evidence");
			Assert(!plan.Dimensions.Any(d => d.Orientation == DimensionOrientation.Horizontal
					&& Math.Abs(GetSpan(d) - 70.0) <= config.GeometryTolerance),
				"all body remainder representations 70 must be removed");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "LeftStructHeight"
					&& Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance
					&& d.RuleId == ruleId),
				"real partial MinX outer face height must remain with rule evidence");
			Assert(!plan.Dimensions.Any(d => d.Orientation == DimensionOrientation.Vertical
					&& Math.Abs(GetSpan(d) - 8.26) <= config.GeometryTolerance),
				"projected lower height residual must not remain");
		}

		private static void TranslatedOuterContourStepKeepsRuleDecision()
		{
			const string ruleId = "OuterContourStepOverallRemainder";
			var config = DimensionRuleConfig.CreateDefault();
			var originalPlan = new DimensionPlanner(config).CreateOutlinePlan(
				CreateOuterContourStepOutline(translateX: 0.0, translateY: 0.0));
			var transformedPlan = new DimensionPlanner(config).CreateOutlinePlan(
				CreateOuterContourStepOutline(translateX: 130.0, translateY: 40.0));

			var originalRuleCandidates = originalPlan.Diagnostics.DimensionCandidates
				.Where(c => c.RuleId == ruleId)
				.ToList();
			var transformedRuleCandidates = transformedPlan.Diagnostics.DimensionCandidates
				.Where(c => c.RuleId == ruleId)
				.ToList();
			Assert(originalRuleCandidates.Count > 0
					&& transformedRuleCandidates.Count == originalRuleCandidates.Count,
				"translation must preserve the number of candidates decided by the outer-step rule");
			foreach (var original in originalRuleCandidates)
			{
				Assert(transformedRuleCandidates.Any(candidate =>
						candidate.Role == original.Role
						&& candidate.Decision == original.Decision
						&& Math.Abs(candidate.Value - original.Value) <= config.GeometryTolerance),
					"translation must preserve RuleId, formal role, decision, and value");
			}

			var unmatchedFinal = transformedPlan.Dimensions.ToList();
			foreach (var original in originalPlan.Dimensions)
			{
				var equivalent = unmatchedFinal.FirstOrDefault(candidate =>
					candidate.Role == original.Role
					&& candidate.Orientation == original.Orientation
					&& candidate.Side == original.Side
					&& Math.Abs(GetSpan(candidate) - GetSpan(original)) <= config.GeometryTolerance);
				Assert(equivalent != null,
					"translation must preserve the final dimension role, orientation, side, and span");
				unmatchedFinal.Remove(equivalent);
			}
			Assert(unmatchedFinal.Count == 0,
				"translation must not add final dimensions");
		}

		private static OutlineFeature2D CreateOuterContourStepOutline(double translateX, double translateY)
		{
			Func<double, double> x = value => translateX + value;
			Func<double, double> y = value => translateY + value;
			var outline = new OutlineFeature2D
			{
				MinX = x(0.0),
				MinY = y(0.0),
				MaxX = x(90.0),
				MaxY = y(28.26)
			};
			// Closed production topology: upper body underside 70, two 1x1 chamfers, bottom step 20 overall.
			AddSegment(outline, new Point2D(x(0.0), y(8.26)), new Point2D(x(70.0), y(8.26)), "body-underside");
			AddSegment(outline, new Point2D(x(70.0), y(8.26)), new Point2D(x(70.0), y(1.0)), "step-shoulder");
			AddSegment(outline, new Point2D(x(70.0), y(1.0)), new Point2D(x(71.0), y(0.0)), "step-chamfer-left");
			AddSegment(outline, new Point2D(x(71.0), y(0.0)), new Point2D(x(89.0), y(0.0)), "step-bottom");
			AddSegment(outline, new Point2D(x(89.0), y(0.0)), new Point2D(x(90.0), y(1.0)), "step-chamfer-right");
			AddSegment(outline, new Point2D(x(90.0), y(1.0)), new Point2D(x(90.0), y(28.26)), "right");
			AddSegment(outline, new Point2D(x(90.0), y(28.26)), new Point2D(x(0.0), y(28.26)), "top");
			AddSegment(outline, new Point2D(x(0.0), y(28.26)), new Point2D(x(0.0), y(8.26)), "left");
			return outline;
		}

		private static void OutlineSegmentBodyLengthClosedByStepIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			var overall = new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(90.0, 0.0),
				DebugRole = "OverallWidth"
			};
			var os70 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 8.26),
				SecondPoint = new Point2D(70.0, 8.26),
				DebugRole = "OutlineSegment"
			};
			var step20 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(70.0, 0.0),
				SecondPoint = new Point2D(90.0, 0.0),
				DebugRole = "BottomStructWidth"
			};
			plan.Add(overall);
			plan.Add(os70);
			plan.Add(step20);
			planner.SuppressClosedOverallLengthRemainders(plan, horizontal: true);
			Assert(plan.Dimensions.Contains(overall) && plan.Dimensions.Contains(step20),
				"overall 90 and step 20 must remain");
			Assert(!plan.Dimensions.Contains(os70),
				"OutlineSegment body 70 that closes overall with step 20 must be suppressed (decision A)");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.Id == os70.DiagnosticId
					&& c.IsSuppressed
					&& c.SuppressedReason == "ComplementaryOutlineRemainder"),
				"OS 70 must record ComplementaryOutlineRemainder");
		}

		/// <summary>
		/// Shaft-like step: overall 90, top body 70, bottom step 20. 70+20 closes overall and the
		/// larger complementary piece (70) must suppress while keeping overall and the step 20.
		/// Directly exercises the cross-side pass with concrete planned dims (full outline path may
		/// still envelope-suppress the bottom step when MinY is collinear full-length).
		/// </summary>
		private static void CrossSideStructureWidthsThatCloseOverallChainAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			var overall = new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(90.0, 0.0),
				DebugRole = "OverallWidth"
			};
			var top70 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 28.0),
				SecondPoint = new Point2D(70.0, 28.0),
				DebugRole = "TopStructWidth"
			};
			var bottom20 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(70.0, 0.0),
				SecondPoint = new Point2D(90.0, 0.0),
				DebugRole = "BottomStructWidth"
			};
			plan.Add(overall);
			plan.Add(top70);
			plan.Add(bottom20);

			planner.SuppressCrossSideComplementaryStructureRemainders(plan, horizontal: true);

			Assert(plan.Dimensions.Contains(overall), "overall width 90 must remain");
			Assert(plan.Dimensions.Contains(bottom20), "step length 20 must remain");
			Assert(!plan.Dimensions.Contains(top70),
				"body length 70 that closes overall with step 20 must be suppressed");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.Id == top70.DiagnosticId
					&& c.IsSuppressed
					&& c.SuppressedReason == "ComplementaryOutlineRemainder"),
				"closed-chain body length 70 must record ComplementaryOutlineRemainder");

			// Full outline path with collinear bottom (matches the shaft drawing): keep step 20,
			// drop body 70, keep overall 90.
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 90.0, MaxY = 28.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(70.0, 0.0), "bottom-body");
			AddSegment(outline, new Point2D(70.0, 0.0), new Point2D(90.0, 0.0), "bottom-step");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(90.0, 20.0), "step-right");
			AddSegment(outline, new Point2D(90.0, 20.0), new Point2D(70.0, 20.0), "step-top");
			AddSegment(outline, new Point2D(70.0, 20.0), new Point2D(70.0, 28.0), "shoulder");
			AddSegment(outline, new Point2D(70.0, 28.0), new Point2D(0.0, 28.0), "body-top");
			AddSegment(outline, new Point2D(0.0, 28.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(70.0, 0.0), new Point2D(70.0, 20.0), "shoulder-down");
			var full = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(full.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(GetSpan(d) - 90.0) <= config.GeometryTolerance),
				"full-path overall 90 must remain");
			Assert(full.Dimensions.Any(d =>
					(d.DebugRole == "BottomStructWidth" || d.DebugRole == "TopStructWidth")
					&& Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance),
				"full-path step length 20 must remain");
			Assert(!full.Dimensions.Any(d =>
					(d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
					&& Math.Abs(GetSpan(d) - 70.0) <= config.GeometryTolerance),
				"full-path must not keep body length 70 beside the closed chain");
		}

		private static void ProjectedCrossLevelStructureWidthsDoNotPartitionOverall()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 96.0,
				MaxY = 35.5
			};
			// Top 25 is real. The next top projection spans 3 in X but drops 15.5 in Y.
			// Bottom 3 + 68 must not join the top edge into an overall partition.
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 35.5), "left");
			AddSegment(outline, new Point2D(0.0, 35.5), new Point2D(25.0, 35.5), "top-step");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(25.0, 35.5), "top-riser");
			AddSegment(outline, new Point2D(28.0, 0.0), new Point2D(28.0, 20.0), "inner-riser");
			AddSegment(outline, new Point2D(28.0, 0.0), new Point2D(96.0, 0.0), "bottom-main");
			AddSegment(outline, new Point2D(28.0, 20.0), new Point2D(96.0, 20.0), "arm-top");
			AddSegment(outline, new Point2D(96.0, 0.0), new Point2D(96.0, 35.5), "right");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var top25 = plan.Diagnostics.DimensionCandidates.Where(c => c.DebugRole == "TopStructWidth"
				&& Math.Abs(c.Value - 25.0) <= config.GeometryTolerance).ToList();
			var projected3 = plan.Diagnostics.DimensionCandidates.Where(c => c.DebugRole == "TopStructWidth"
				&& Math.Abs(c.Value - 3.0) <= config.GeometryTolerance).ToList();
			var bottom68 = plan.Diagnostics.DimensionCandidates.Where(c => c.DebugRole == "BottomStructWidth"
				&& Math.Abs(c.Value - 68.0) <= config.GeometryTolerance).ToList();

			Assert(top25.Count > 0, "real top step width 25 must be generated");
			Assert(top25.All(c => c.SuppressedReason != "LocalGeometryOnOverallEnvelope"),
				"top step width 25 on partial MaxY must not be removed by full-envelope local geometry");
			Assert(projected3.All(c => c.SuppressedReason != "StructureOverallPartition"),
				"cross-level 3 must not participate in StructureOverallPartition");
			Assert(bottom68.All(c => c.SuppressedReason != "StructureOverallPartition"),
				"bottom arm 68 must not be wiped only via StructureOverallPartition from cross-level tops");
			Assert(bottom68.All(c => c.SuppressedReason != "LocalGeometryOnOverallEnvelope"),
				"bottom arm 68 on partial MinY must not be removed by full-envelope local geometry");
		}

		private static void GeometricMirrorOwnershipPrefersContourBackedCandidate()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 96.0,
				MaxY = 35.5
			};
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 35.5), "left");
			AddSegment(outline, new Point2D(0.0, 35.5), new Point2D(25.0, 35.5), "top-step");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(25.0, 35.5), "top-riser");
			AddSegment(outline, new Point2D(28.0, 0.0), new Point2D(28.0, 20.0), "inner-riser");
			AddSegment(outline, new Point2D(28.0, 0.0), new Point2D(96.0, 0.0), "bottom-main");
			AddSegment(outline, new Point2D(28.0, 20.0), new Point2D(96.0, 20.0), "arm-top");
			AddSegment(outline, new Point2D(96.0, 0.0), new Point2D(96.0, 35.5), "right");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var top25 = plan.Dimensions.Where(d => d.DebugRole == "TopStructWidth"
				&& Math.Abs(GetSpan(d) - 25.0) <= config.GeometryTolerance).ToList();
			var bottom25 = plan.Diagnostics.DimensionCandidates.Where(c => c.DebugRole == "BottomStructWidth"
				&& Math.Abs(c.Value - 25.0) <= config.GeometryTolerance).ToList();
			var candidates25 = plan.Diagnostics.DimensionCandidates.Where(c =>
					(c.DebugRole == "TopStructWidth" || c.DebugRole == "BottomStructWidth")
					&& Math.Abs(c.Value - 25.0) <= config.GeometryTolerance)
				.ToList();

			Assert(top25.Count == 1, "the contour-backed top structure width 25 must remain selected (candidates: "
				+ string.Join(",", candidates25.Select(c => c.DebugRole + "/sel=" + c.IsSelected
					+ "/supp=" + c.IsSuppressed + "/reason=" + c.SuppressedReason
					+ "/p=" + c.FirstPointX + ":" + c.FirstPointY + "-" + c.SecondPointX + ":" + c.SecondPointY)) + ")");
			Assert(bottom25.Any(c => c.SuppressedReason == "MirroredDuplicate"),
				"the cross-level bottom projection 25 must be suppressed as the mirror duplicate");
		}

		private static void SameSideClosedChainSuppressesCrossLevelProjection()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 36.0,
				MaxY = 35.5
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(36.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(36.0, 0.0), new Point2D(36.0, 35.5), "right");
			AddSegment(outline, new Point2D(36.0, 35.5), new Point2D(18.0, 35.5), "top-real");
			AddSegment(outline, new Point2D(18.0, 35.5), new Point2D(18.0, 20.0), "step-riser");
			AddSegment(outline, new Point2D(18.0, 20.0), new Point2D(0.0, 20.0), "lower-step");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var projected = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "TopStructWidth"
					&& Math.Abs(c.Value - 18.0) <= config.GeometryTolerance
					&& Math.Abs(c.FirstPointY - c.SecondPointY) > config.GeometryTolerance)
				.ToList();
			var real = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "TopStructWidth"
					&& Math.Abs(c.Value - 18.0) <= config.GeometryTolerance
					&& Math.Abs(c.FirstPointY - c.SecondPointY) <= config.GeometryTolerance)
				.ToList();

			Assert(projected.Count > 0, "cross-level top projection 18 must be generated");
			Assert(real.Count > 0 && real.Any(c => c.IsSelected), "real top edge 18 must remain selected");
			Assert(projected.All(c => c.IsSuppressed
				&& c.SuppressedReason == "ProjectedStructureOverallPartition"),
				"same-side closed chain must suppress only the cross-level projection");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
				&& Math.Abs(GetSpan(d) - 36.0) <= config.GeometryTolerance),
				"overall width 36 must remain");
		}

		private static void ProjectedThreePieceHorizontalChainKeepsRealSteps()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var plan = new DimensionPlanner(config).CreateOutlinePlan(BuildProjectedHorizontalChainOutline(mirrored: false));
			var selected = plan.Dimensions.Where(d => d.DebugRole == "TopStructWidth").ToList();
			var suppressed = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "TopStructWidth" && c.IsSuppressed)
				.ToList();

			Assert(selected.Count(d => Math.Abs(Math.Round(GetSpan(d), 2) - 134.79) <= config.GeometryTolerance) == 2,
				"two real top steps 134.79 must remain selected");
			Assert(!selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 169.21) <= config.GeometryTolerance),
				"cross-level top projection 169.21 must not remain selected");
			Assert(suppressed.Any(c => Math.Abs(Math.Round(c.Value, 2) - 169.21) <= config.GeometryTolerance
				&& c.SuppressedReason == "ProjectedStructureOverallPartition"),
				"cross-level top projection 169.21 must retain its projected-partition diagnostic");
		}

		private static void TopClosedChainDropsUnbackedBodyRemainder()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(338.0, 201.5);
			var candidates = new List<PlannedDimension>
			{
				new PlannedDimension
				{
					Kind = DimensionKind.Normal,
					Orientation = DimensionOrientation.Horizontal,
					Side = DimensionSide.Top,
					FirstPoint = new Point2D(0.0, 100.0),
					SecondPoint = new Point2D(73.0, 90.0),
					DebugRole = "TopStructWidth"
				},
				new PlannedDimension
				{
					Kind = DimensionKind.Normal,
					Orientation = DimensionOrientation.Horizontal,
					Side = DimensionSide.Top,
					FirstPoint = new Point2D(73.0, 90.0),
					SecondPoint = new Point2D(160.55427071, 0.0),
					DebugRole = "TopStructWidth"
				},
				new PlannedDimension
				{
					Kind = DimensionKind.Normal,
					Orientation = DimensionOrientation.Horizontal,
					Side = DimensionSide.Top,
					FirstPoint = new Point2D(160.55427071, 0.0),
					SecondPoint = new Point2D(338.0, 5.0),
					DebugRole = "TopStructWidth"
				}
			};

			int removed = new StructureEndpointRules(config)
				.FindLongestExtensionCandidateIndex(candidates, outline, DimensionSide.Top);

			Assert(removed == 2, "DL01-like Top chain must drop only the unbacked body remainder");
			Assert(candidates[removed].RuleId == "TopClosedOverallChainBodyRemainder",
				"removed Top body remainder must record the closed-chain rule");
			Assert(candidates[removed].TopologyEvidence
				== "CompleteOverallChain:0-73|73-160.55427071|160.55427071-338",
				"removed Top body remainder must record the complete chain intervals");
		}

		/// <summary>
		/// test2-like Top closed chain with datum on the right:
		/// keep feature width 50 + datum-side location 75; suppress opposite overall-closing 90.
		/// Hole/pin dims are present so datum side can be inferred; they must remain.
		/// </summary>
		private static void TopClosedChainKeepsRealStepsDropsUnbackedBody()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(140.0, 100.0), "top-75");
			AddSegment(outline, new Point2D(140.0, 100.0), new Point2D(90.0, 100.0), "top-50");
			AddSegment(outline, new Point2D(90.0, 100.0), new Point2D(90.0, 80.0), "left-riser");
			AddSegment(outline, new Point2D(90.0, 80.0), new Point2D(0.0, 80.0), "left-ledge");
			AddSegment(outline, new Point2D(0.0, 80.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				ForceOuterLevel = true,
				DebugRole = "OverallWidth"
			});
			// Opposite overall-closing location (should drop).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 85.0),
				SecondPoint = new Point2D(90.0, 85.0),
				DebugRole = "TopStructWidth"
			});
			// Interior feature / slot width (keep).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(90.0, 100.0),
				SecondPoint = new Point2D(140.0, 100.0),
				DebugRole = "TopStructWidth"
			});
			// Datum-side location (keep).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(140.0, 100.0),
				SecondPoint = new Point2D(215.0, 100.0),
				DebugRole = "TopStructWidth"
			});
			// Datum evidence on the right (pin/datum base at MaxX).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.DatumHoleLocationX,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(155.0, 90.0),
				SecondPoint = new Point2D(215.0, 90.0),
				DebugRole = "DatumX"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.PinGroupDistance,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(100.0, 90.0),
				SecondPoint = new Point2D(155.0, 90.0),
				DebugRole = "PinGroupDistance"
			});

			new DimensionPlanner(config).SuppressTopStructureClosedChainRedundantPositioning(plan, outline);

			var topStruct = plan.Dimensions.Where(d => d.DebugRole == "TopStructWidth").ToList();
			Assert(topStruct.Any(d => Math.Abs(GetSpan(d) - 50.0) <= config.GeometryTolerance),
				"feature width 50 must remain");
			Assert(topStruct.Any(d => Math.Abs(GetSpan(d) - 75.0) <= config.GeometryTolerance),
				"datum-side location 75 must remain");
			Assert(!topStruct.Any(d => Math.Abs(GetSpan(d) - 90.0) <= config.GeometryTolerance),
				"opposite overall-closing 90 must be suppressed");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "DatumX"),
				"hole/pin datum dims must not be killed by the structure closed-chain rule");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "PinGroupDistance"),
				"pin group distance must not be killed by the structure closed-chain rule");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "TopStructWidth"
					&& Math.Abs(c.Value - 90.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& c.SuppressedReason == "TopClosedChainRedundantPositioning"),
				"suppressed 90 must record TopClosedChainRedundantPositioning");
		}

		/// <summary>
		/// Same 90+50+75=215 top closed chain as test2 pure-structure selection: no hole/pin
		/// datum dims. Must still drop opposite overall-closing 90 (default MaxX datum side).
		/// </summary>
		private static void TopClosedChainWithoutDatumDropsOppositeBody()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(140.0, 100.0), "top-75");
			AddSegment(outline, new Point2D(140.0, 100.0), new Point2D(90.0, 100.0), "top-50");
			AddSegment(outline, new Point2D(90.0, 100.0), new Point2D(0.0, 100.0), "top-90");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				ForceOuterLevel = true,
				DebugRole = "OverallWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 100.0),
				SecondPoint = new Point2D(90.0, 100.0),
				DebugRole = "TopStructWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(90.0, 100.0),
				SecondPoint = new Point2D(140.0, 100.0),
				DebugRole = "TopStructWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(140.0, 100.0),
				SecondPoint = new Point2D(215.0, 100.0),
				DebugRole = "TopStructWidth"
			});

			new DimensionPlanner(config).SuppressTopStructureClosedChainRedundantPositioning(plan, outline);

			var topStruct = plan.Dimensions.Where(d => d.DebugRole == "TopStructWidth").ToList();
			Assert(topStruct.Any(d => Math.Abs(GetSpan(d) - 50.0) <= config.GeometryTolerance),
				"feature width 50 must remain without hole/pin datum");
			Assert(topStruct.Any(d => Math.Abs(GetSpan(d) - 75.0) <= config.GeometryTolerance),
				"shorter overall-closing end 75 must remain without hole/pin datum");
			Assert(!topStruct.Any(d => Math.Abs(GetSpan(d) - 90.0) <= config.GeometryTolerance),
				"longer overall-closing body 90 must still be suppressed without hole/pin datum");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "TopStructWidth"
					&& Math.Abs(c.Value - 90.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& c.SuppressedReason == "TopClosedChainRedundantPositioning"),
				"suppressed 90 must record TopClosedChainRedundantPositioning without datum");
		}

		/// <summary>
		/// 180°-style bottom closed chain 75+50+90=215: no-datum keeps shorter end 75, drops 90.
		/// </summary>
		private static void BottomClosedChainWithoutDatumDropsOppositeBody()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				ForceOuterLevel = true,
				DebugRole = "OverallWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "BottomStructWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(75.0, 0.0),
				SecondPoint = new Point2D(125.0, 0.0),
				DebugRole = "BottomStructWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(125.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				DebugRole = "BottomStructWidth"
			});

			new DimensionPlanner(config).SuppressTopStructureClosedChainRedundantPositioning(plan, outline);

			var bottomStruct = plan.Dimensions.Where(d => d.DebugRole == "BottomStructWidth").ToList();
			Assert(bottomStruct.Any(d => Math.Abs(GetSpan(d) - 50.0) <= config.GeometryTolerance),
				"bottom feature width 50 must remain");
			Assert(bottomStruct.Any(d => Math.Abs(GetSpan(d) - 75.0) <= config.GeometryTolerance),
				"shorter overall-closing end 75 must remain");
			Assert(!bottomStruct.Any(d => Math.Abs(GetSpan(d) - 90.0) <= config.GeometryTolerance),
				"longer overall-closing body 90 must be suppressed");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 90.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& c.SuppressedReason == "TopClosedChainRedundantPositioning"),
				"suppressed bottom 90 must record closed-chain reason");
		}

		/// <summary>
		/// Right-side vertical closed chain 42+50+108=200: default MaxY datum keeps top-side
		/// location + interior feature; drops MinY overall-closing body.
		/// </summary>
		private static void RightClosedChainWithoutDatumDropsOppositeBody()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 200.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 200.0), "right");
			AddSegment(outline, new Point2D(100.0, 200.0), new Point2D(0.0, 200.0), "top");
			AddSegment(outline, new Point2D(0.0, 200.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 200.0),
				ForceOuterLevel = true,
				DebugRole = "OverallHeight"
			});
			// MinY overall-closing body (should drop with default MaxY datum).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 0.0),
				SecondPoint = new Point2D(100.0, 108.0),
				DebugRole = "RightStructHeight"
			});
			// Interior feature (keep).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 108.0),
				SecondPoint = new Point2D(100.0, 158.0),
				DebugRole = "RightStructHeight"
			});
			// MaxY-side location (keep).
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 158.0),
				SecondPoint = new Point2D(100.0, 200.0),
				DebugRole = "RightStructHeight"
			});

			new DimensionPlanner(config).SuppressTopStructureClosedChainRedundantPositioning(plan, outline);

			var rightStruct = plan.Dimensions.Where(d => d.DebugRole == "RightStructHeight").ToList();
			Assert(rightStruct.Any(d => Math.Abs(GetSpan(d) - 50.0) <= config.GeometryTolerance),
				"right interior feature 50 must remain");
			Assert(rightStruct.Any(d => Math.Abs(GetSpan(d) - 42.0) <= config.GeometryTolerance),
				"right MaxY-side location 42 must remain");
			Assert(!rightStruct.Any(d => Math.Abs(GetSpan(d) - 108.0) <= config.GeometryTolerance),
				"right MinY overall-closing 108 must be suppressed (Left↔Right symmetry)");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "RightStructHeight"
					&& Math.Abs(c.Value - 108.0) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& c.SuppressedReason == "TopClosedChainRedundantPositioning"),
				"suppressed right 108 must record closed-chain reason");
		}

		/// <summary>
		/// 180°-style multi-level bottom: real horizontal ledges 177.45 + 87.55 + 73 = 338.
		/// Generation must admit 87.55 (bottom-facing edge), multi-piece rule drops 177.45.
		/// Must not break cross-axis rejection (BottomStructureRejectsCrossAxisProjection).
		/// </summary>
		private static void BottomMultiLevelStepsKeepFeatureChainDropBodyRemainder()
		{
			var config = DimensionRuleConfig.CreateDefault();
			// Stepped bottom silhouette (former top two-step after 180°).
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 338.0,
				MaxY = 200.0
			};
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(177.45, 100.0), "bottom-body-177");
			AddSegment(outline, new Point2D(177.45, 100.0), new Point2D(177.45, 50.0), "riser-1");
			AddSegment(outline, new Point2D(177.45, 50.0), new Point2D(265.0, 50.0), "bottom-step-87.55");
			AddSegment(outline, new Point2D(265.0, 50.0), new Point2D(265.0, 0.0), "riser-2");
			AddSegment(outline, new Point2D(265.0, 0.0), new Point2D(338.0, 0.0), "bottom-step-73");
			AddSegment(outline, new Point2D(338.0, 0.0), new Point2D(338.0, 200.0), "right");
			AddSegment(outline, new Point2D(338.0, 200.0), new Point2D(0.0, 200.0), "top");
			AddSegment(outline, new Point2D(0.0, 200.0), new Point2D(0.0, 100.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var bottom = plan.Dimensions.Where(d => d.DebugRole == "BottomStructWidth").ToList();
			double[] sig = bottom.Select(d => Math.Round(GetSpan(d), 2)).OrderBy(v => v).ToArray();
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 73.0) <= config.GeometryTolerance),
				"bottom step 73 must be selected; bottom=[" + string.Join(",", sig) + "]");
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 87.55) <= config.GeometryTolerance),
				"bottom step 87.55 must be selected (bottom-facing edge); bottom=[" + string.Join(",", sig) + "]");
			Assert(!bottom.Any(d => Math.Abs(GetSpan(d) - 177.45) <= config.GeometryTolerance),
				"body remainder 177.45 must be suppressed; bottom=[" + string.Join(",", sig) + "]");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 177.45) <= config.GeometryTolerance
					&& c.IsSuppressed),
				"177.45 must appear as a suppressed BottomStructWidth candidate");
		}

		/// <summary>
		/// last-run repro: mid ledge is classified as Top OS (solid below pocket), yet column
		/// bottoms still emit cross-axis BottomStructWidth 87.55. Snap must use ledge-Y match
		/// (not only ray-cast bottom-facing) so 87.55 is kept and 177.45 is dropped.
		/// </summary>
		private static void BottomCrossLevelLedgeSnapWhenOutlineSegmentResolvesTop()
		{
			var config = DimensionRuleConfig.CreateDefault();
			// Geometry inspired by last-run (relative bbox): mid ledge at y=106.5 with solid
			// both above and partially below so OS may resolve Top; foot at MinY.
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 338.0,
				MaxY = 201.5
			};
			// Upper body top
			AddSegment(outline, new Point2D(0.0, 201.5), new Point2D(305.0, 201.5), "top-305");
			AddSegment(outline, new Point2D(305.0, 201.5), new Point2D(305.0, 20.0), "right-inner");
			AddSegment(outline, new Point2D(305.0, 20.0), new Point2D(338.0, 20.0), "right-shelf");
			AddSegment(outline, new Point2D(338.0, 20.0), new Point2D(338.0, 0.0), "right-foot");
			AddSegment(outline, new Point2D(338.0, 0.0), new Point2D(265.0, 0.0), "bottom-73");
			AddSegment(outline, new Point2D(265.0, 0.0), new Point2D(265.0, 10.0), "foot-riser");
			// Mid ledge ~87.55 (last-run OS was Top @ y=106.5 x=177.45..260)
			AddSegment(outline, new Point2D(265.0, 10.0), new Point2D(265.0, 106.5), "mid-riser");
			AddSegment(outline, new Point2D(265.0, 106.5), new Point2D(177.45, 106.5), "mid-ledge-87");
			AddSegment(outline, new Point2D(177.45, 106.5), new Point2D(177.45, 101.5), "ledge-step");
			AddSegment(outline, new Point2D(177.45, 101.5), new Point2D(0.0, 101.5), "mid-body-177");
			AddSegment(outline, new Point2D(0.0, 101.5), new Point2D(0.0, 201.5), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var bottom = plan.Dimensions.Where(d => d.DebugRole == "BottomStructWidth").ToList();
			double[] sig = bottom.Select(d => Math.Round(GetSpan(d), 2)).OrderBy(v => v).ToArray();
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 73.0) <= 1.0),
				"foot 73-class step must remain; bottom=[" + string.Join(",", sig) + "]");
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 87.55) <= 5.0),
				"mid ledge ~87.55 must be snapped/kept as BottomStructWidth; bottom=["
				+ string.Join(",", sig) + "]");
			Assert(!bottom.Any(d => Math.Abs(GetSpan(d) - 177.45) <= 1.0),
				"177.45 body remainder must not remain selected; bottom=[" + string.Join(",", sig) + "]");
		}

		/// <summary>
		/// P0: bottom structure 177.45+73+87.55=338 overall → keep 73+87.55, drop body 177.45.
		/// </summary>
		private static void MultiPieceStructureOverallRemainderDropsLongBody()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 338.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(338.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(338.0, 0.0), new Point2D(338.0, 100.0), "right");
			AddSegment(outline, new Point2D(338.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			void AddStruct(double x0, double x1, string role)
			{
				var dim = new PlannedDimension
				{
					Kind = DimensionKind.Normal,
					Orientation = DimensionOrientation.Horizontal,
					Side = DimensionSide.Bottom,
					FirstPoint = new Point2D(x0, 0.0),
					SecondPoint = new Point2D(x1, 0.0),
					DebugRole = role,
					Role = DimensionCandidateRole.Structure
				};
				plan.Add(dim);
			}
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(338.0, 0.0),
				ForceOuterLevel = true,
				DebugRole = "OverallWidth",
				Role = DimensionCandidateRole.Overall
			});
			// Body remainder (should drop).
			AddStruct(0.0, 177.45, "BottomStructWidth");
			// Real two-step chain (keep).
			AddStruct(177.45, 250.45, "BottomStructWidth"); // 73
			AddStruct(250.45, 338.0, "BottomStructWidth"); // 87.55

			new DimensionPlanner(config).SuppressMultiPieceStructureOverallRemainders(plan, outline);

			var bottom = plan.Dimensions.Where(d => d.DebugRole == "BottomStructWidth").ToList();
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 73.0) <= config.GeometryTolerance),
				"feature step 73 must remain");
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 87.55) <= config.GeometryTolerance),
				"feature step 87.55 must remain");
			Assert(!bottom.Any(d => Math.Abs(GetSpan(d) - 177.45) <= config.GeometryTolerance),
				"overall-closing body 177.45 must be suppressed");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "BottomStructWidth"
					&& Math.Abs(c.Value - 177.45) <= config.GeometryTolerance
					&& c.IsSuppressed
					&& c.SuppressedReason == "MultiPieceStructureOverallRemainder"),
				"suppressed 177.45 must record MultiPieceStructureOverallRemainder");
		}

		private static void ProjectedThreePieceVerticalChainKeepsRealHeights()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var plan = new DimensionPlanner(config).CreateOutlinePlan(BuildProjectedVerticalChainOutline());
			var selected = plan.Dimensions.Where(d => d.DebugRole == "LeftStructHeight").ToList();
			var suppressed = plan.Diagnostics.DimensionCandidates
				.Where(c => c.DebugRole == "LeftStructHeight" && c.IsSuppressed)
				.ToList();

			Assert(selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 163.37) <= config.GeometryTolerance),
				"real left height 163.37 must remain selected");
			Assert(selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 126.11) <= config.GeometryTolerance),
				"real left height 126.11 must remain selected");
			Assert(!selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 140.44) <= config.GeometryTolerance),
				"cross-level left residual 140.44 must not remain selected");
			Assert(suppressed.Any(c => Math.Abs(Math.Round(c.Value, 2) - 140.44) <= config.GeometryTolerance
				&& c.SuppressedReason == "ProjectedStructureOverallPartition"),
				"cross-level left residual 140.44 must retain its projected-partition diagnostic (suppressed: "
				+ string.Join(",", suppressed.Select(c => c.Value + "/" + c.SuppressedReason)) + ")");
		}

		private static void OrthogonalRotatedVerticalChainKeepsRealWidths()
		{
			var config = DimensionRuleConfig.CreateDefault();
			foreach (double angle in new[] { Math.PI / 2.0, -Math.PI / 2.0 })
			{
				var rotated = TransformOutline(BuildProjectedVerticalChainOutline(), angle);
				var plan = new DimensionPlanner(config).CreateOutlinePlan(rotated);
				var selected = plan.Dimensions
					.Where(d => (d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
						&& d.Orientation == DimensionOrientation.Horizontal)
					.ToList();
				Assert(selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 163.37) <= config.GeometryTolerance),
					"90-degree rotated chain must retain real width 163.37");
				Assert(selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 126.11) <= config.GeometryTolerance),
					"90-degree rotated chain must retain real width 126.11");
				Assert(!selected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 140.44) <= config.GeometryTolerance),
					"90-degree rotated chain must suppress derivable width 140.44");
			}

			var actual = new DimensionPlanner(config).CreateDimensionPlan(
				BuildActualRotatedContourOutline(),
				null,
				new HoleFeature2D[0]);
			var actualSelected = actual.Dimensions
				.Where(d => (d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal)
				.ToList();
			Assert(actualSelected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 163.37) <= config.GeometryTolerance),
				"actual rotated contour must retain real width 163.37");
			Assert(actualSelected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 126.11) <= config.GeometryTolerance),
				"actual rotated contour must retain real width 126.11");
			Assert(!actualSelected.Any(d => Math.Abs(Math.Round(GetSpan(d), 2) - 140.44) <= config.GeometryTolerance),
				"actual rotated contour must suppress derivable width 140.44");
			Assert(actual.Diagnostics.DimensionCandidates.Any(c =>
				Math.Abs(c.Value - 140.43723701) <= config.GeometryTolerance
				&& c.SuppressedReason == "ProjectedStructureOverallPartition"),
				"actual rotated contour must record the derivable width suppression");
		}

		private static void FullWidthSideSeamsDoNotCreateStructureHeights()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 20.0,
				MaxY = 29.038
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(20.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(20.0, 20.0), "right-lower");
			AddSegment(outline, new Point2D(20.0, 20.0), new Point2D(0.0, 20.0), "full-width-seam-lower");
			AddSegment(outline, new Point2D(20.0, 20.0), new Point2D(20.0, 28.0), "right-upper");
			AddSegment(outline, new Point2D(20.0, 28.0), new Point2D(0.0, 28.0), "full-width-seam-upper");
			AddSegment(outline, new Point2D(20.0, 29.038), new Point2D(0.0, 29.038), "top");
			AddSegment(outline, new Point2D(0.0, 29.038), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var falseStructureCandidates = plan.Diagnostics.DimensionCandidates
				.Where(c => (c.DebugRole == "LeftStructHeight" || c.DebugRole == "RightStructHeight")
					&& (Math.Abs(c.Value - 8.0) <= config.GeometryTolerance
						|| Math.Abs(c.Value - 20.0) <= config.GeometryTolerance))
				.ToList();

			Assert(falseStructureCandidates.Count > 0,
				"full-width seams must still be visible in diagnostics as rejected structure candidates");
			Assert(falseStructureCandidates.All(c => c.IsSuppressed)
				&& falseStructureCandidates.Any(c => c.DebugRole == "RightStructHeight"
					&& c.SuppressedReason == "NonProfileBackedSideStructureHeight"),
				"full-width seam heights must be suppressed before mirror/partition promotion ("
				+ string.Join(",", falseStructureCandidates.Select(c => c.DebugRole + "/" + c.Value
					+ "/" + c.IsSelected + "/" + c.SuppressedReason)) + ")");
			Assert(!plan.Dimensions.Any(d =>
				(d.DebugRole == "LeftStructHeight" || d.DebugRole == "RightStructHeight")
				&& (Math.Abs(GetSpan(d) - 8.0) <= config.GeometryTolerance
					|| Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance)),
				"full-width seams must not become visible side dimensions");
		}

		private static OutlineFeature2D BuildActualRotatedContourOutline()
		{
			const double width = 429.90990921;
			const double height = 438.79648808;
			const double firstBreak = 140.43723701;
			const double secondBreak = 266.54414371;
			const double lowerStep = 169.20909149;
			const double upperStep = 304.00278979;
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = width,
				MaxY = height
			};
			AddSegment(outline, new Point2D(0.0, height), new Point2D(0.0, upperStep), "left-outer");
			AddSegment(outline, new Point2D(0.0, upperStep), new Point2D(firstBreak, upperStep), "step-1");
			AddSegment(outline, new Point2D(firstBreak, upperStep), new Point2D(firstBreak, lowerStep), "riser-1");
			AddSegment(outline, new Point2D(firstBreak, lowerStep), new Point2D(secondBreak, lowerStep), "step-2");
			AddSegment(outline, new Point2D(secondBreak, lowerStep), new Point2D(secondBreak, 0.0), "riser-2");
			AddSegment(outline, new Point2D(secondBreak, 0.0), new Point2D(width, 0.0), "step-3");
			AddSegment(outline, new Point2D(width, 0.0), new Point2D(width, height), "right-outer");
			AddSegment(outline, new Point2D(width, height), new Point2D(0.0, height), "top");
			return outline;
		}

		private static void MirroredProjectedChainNormalizesStructureSelection()
		{
			var config = DimensionRuleConfig.CreateDefault();
			DimensionPlan original = new DimensionPlanner(config).CreateOutlinePlan(BuildProjectedHorizontalChainOutline(mirrored: false));
			DimensionPlan mirrored = new DimensionPlanner(config).CreateOutlinePlan(BuildProjectedHorizontalChainOutline(mirrored: true));
			string[] originalSelection = original.Dimensions
				.Where(d => d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
				.Select(d => "HorizontalStructWidth@" + Math.Round(GetSpan(d), 3).ToString("0.000"))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();
			string[] mirroredSelection = mirrored.Dimensions
				.Where(d => d.DebugRole == "TopStructWidth" || d.DebugRole == "BottomStructWidth")
				.Select(d => "HorizontalStructWidth@" + Math.Round(GetSpan(d), 3).ToString("0.000"))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();

			Assert(originalSelection.SequenceEqual(mirroredSelection),
				"mirroring must preserve normalized structure selection; only placement side may change (original: "
				+ string.Join(",", originalSelection) + "; mirrored: " + string.Join(",", mirroredSelection) + ")");
		}

		private static void Test2BottomContourChainKeepsTwoRealWidths()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var originalOutline = BuildTest2BottomContourOutline(mirrored: false);
			var mirroredOutline = BuildTest2BottomContourOutline(mirrored: true);
			var original = planner.CreateOutlinePlan(originalOutline);
			var mirrored = planner.CreateOutlinePlan(mirroredOutline);

			AssertTest2BottomContourPlan(original, originalOutline, config);
			AssertTest2BottomContourPlan(mirrored, mirroredOutline, config);

			string[] originalSelection = original.Dimensions
				.Where(d => (d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal)
				.Select(d => d.DebugRole + "@" + Math.Round(GetSpan(d), 3).ToString("0.000"))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();
			string[] mirroredSelection = mirrored.Dimensions
				.Where(d => (d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal)
				.Select(d => d.DebugRole + "@" + Math.Round(GetSpan(d), 3).ToString("0.000"))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();
			Assert(originalSelection.SequenceEqual(mirroredSelection),
				"test2 X mirror must preserve Bottom/Outline selection semantics (original: "
				+ string.Join(",", originalSelection) + "; mirrored: " + string.Join(",", mirroredSelection) + ")");
		}

		private static void RotatedTest2PreservesLocalSemanticSignature()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var baselineOutline = BuildTest2BottomContourOutline(mirrored: false);
			var baseline = planner.CreateOutlinePlan(baselineOutline);
			string[] baselineSignature = GetPlanningSemanticSignature(baseline);
			Assert(baseline.CoordinateFrame.IsIdentity,
				"axis-aligned Test2 baseline must retain the identity planning frame");

			foreach (double angle in new[] { 27.0, -33.0 })
			{
				double radians = angle * Math.PI / 180.0;
				var rotatedOutline = TransformOutline(baselineOutline, radians);
				var rotated = planner.CreateOutlinePlan(rotatedOutline);

				Assert(Math.Abs(rotated.CoordinateFrame.Angle - radians) <= 1E-9,
					"rotated Test2 must infer its principal local frame (angle " + angle + ")");
				string[] rotatedSignature = GetPlanningSemanticSignature(rotated);
				Assert(rotatedSignature.SequenceEqual(baselineSignature),
					"rotated Test2 must preserve selected/suppressed local semantics (angle " + angle + ")");

				var explicitFrame = new CoordinateFrame2D(
					new Point2D(0.0, 0.0),
					new Point2D(Math.Cos(radians), Math.Sin(radians)));
				var explicitPlan = planner.CreateOutlinePlan(rotatedOutline, explicitFrame);
				Assert(Math.Abs(explicitPlan.CoordinateFrame.Angle - radians) <= 1E-9,
					"explicit rotated Test2 frame must be retained (angle " + angle + ")");
				Assert(GetPlanningSemanticSignature(explicitPlan).SequenceEqual(baselineSignature),
					"explicit rotated Test2 frame must preserve local semantics (angle " + angle + ")");
			}

			var mirroredOutline = BuildTest2BottomContourOutline(mirrored: true);
			var mirrored = planner.CreateOutlinePlan(mirroredOutline);
			Assert(mirrored.CoordinateFrame.IsIdentity,
				"X-mirrored Test2 must keep the identity planning frame");
			AssertTest2BottomContourPlan(mirrored, mirroredOutline, config);
			string[] baselineBottomSelection = baseline.Dimensions
				.Where(d => (d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal)
				.Select(d => d.DebugRole + "@" + Math.Round(GetSpan(d), 3).ToString("0.000"))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();
			string[] mirroredBottomSelection = mirrored.Dimensions
				.Where(d => (d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal)
				.Select(d => d.DebugRole + "@" + Math.Round(GetSpan(d), 3).ToString("0.000"))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();
			Assert(mirroredBottomSelection.SequenceEqual(baselineBottomSelection),
				"X-mirrored Test2 must preserve bottom selected role/value semantics");
		}

		private static string[] GetPlanningSemanticSignature(DimensionPlan plan)
		{
			return plan.Diagnostics.DimensionCandidates
				.Where(candidate => candidate.IsSelected || candidate.IsSuppressed)
				.Select(candidate => string.Join("|",
					candidate.Kind ?? string.Empty,
					candidate.DebugRole ?? string.Empty,
					candidate.Role.ToString(),
					candidate.IsSelected ? "selected" : "suppressed",
					candidate.IsSuppressed ? "suppressed" : "active",
					candidate.SuppressedReason ?? string.Empty,
					candidate.RuleId ?? string.Empty,
					Math.Round(candidate.Value, 3).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture),
					Math.Round(Math.Abs(candidate.MeasurementMaximum - candidate.MeasurementMinimum), 3)
						.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture),
					candidate.Orientation ?? string.Empty,
					candidate.PlacementSide ?? string.Empty,
					candidate.RequestedPlacementSide ?? string.Empty,
					string.Join(",", (candidate.SourceGeometryIds ?? new List<string>())
						.Where(id => !string.IsNullOrWhiteSpace(id))
						.OrderBy(id => id, StringComparer.Ordinal))))
				.OrderBy(value => value, StringComparer.Ordinal)
				.ToArray();
		}

		/// <summary>
		/// Phase 0 rotation gate (grill-me): multiset of selected Overall + Structure values only.
		/// Placement side / debug-role prefix are ignored.
		/// </summary>
		private static double[] GetOverallStructureValueSignature(DimensionPlan plan, double tolerance)
		{
			return plan.Dimensions
				.Where(d => d.Kind == DimensionKind.OverallWidth
					|| d.Kind == DimensionKind.OverallHeight
					|| d.Role == DimensionCandidateRole.Structure
					|| string.Equals(d.DebugRole, "TopStructWidth", StringComparison.Ordinal)
					|| string.Equals(d.DebugRole, "BottomStructWidth", StringComparison.Ordinal)
					|| string.Equals(d.DebugRole, "LeftStructHeight", StringComparison.Ordinal)
					|| string.Equals(d.DebugRole, "RightStructHeight", StringComparison.Ordinal)
					|| string.Equals(d.DebugRole, "TopChamferedStepWidth", StringComparison.Ordinal)
					|| string.Equals(d.DebugRole, "RightChamferedStepHeight", StringComparison.Ordinal))
				.Select(d => Math.Round(GetSpan(d), 2))
				.OrderBy(v => v)
				.ToArray();
		}

		private static bool SignatureContains(double[] signature, double value, double tol)
		{
			return signature.Any(v => Math.Abs(v - value) <= tol);
		}

		/// <summary>
		/// OC01 outer-step fixture — Phase 1 hard gate (suppression four-way):
		/// every 90° orientation keeps Overall 90, overall height ~28.26, and real step 20.
		/// Full multiset equality is Phase 2 (generation symmetry).
		/// </summary>
		private static void RotationSignature_OuterStepOverallStructureIsStable()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var baselineOutline = CreateOuterContourStepOutline(translateX: 0.0, translateY: 0.0);
			int orientationsKeepingStep20 = 0;
			foreach (double degrees in new[] { 0.0, 90.0, 180.0, 270.0 })
			{
				var outline = degrees == 0.0
					? baselineOutline
					: TransformOutline(baselineOutline, degrees * Math.PI / 180.0);
				double[] signature = GetOverallStructureValueSignature(planner.CreateOutlinePlan(outline), config.GeometryTolerance);
				Console.WriteLine("OC01-outer-step @" + degrees + "° sig=[" + string.Join(",", signature) + "]");
				Assert(SignatureContains(signature, 90.0, config.GeometryTolerance),
					"OC01 @" + degrees + "° must keep Overall 90; sig=[" + string.Join(",", signature) + "]");
				Assert(SignatureContains(signature, 28.26, 0.05),
					"OC01 @" + degrees + "° must keep overall height ~28.26; sig=[" + string.Join(",", signature) + "]");
				if (SignatureContains(signature, 20.0, config.GeometryTolerance))
				{
					orientationsKeepingStep20++;
				}
			}
			// Phase 1: step 20 must survive most orientations; full 4/4 is Phase 2 generation.
			Assert(orientationsKeepingStep20 >= 3,
				"OC01 real step 20 must remain in at least 3/4 orientations (Phase 1); got "
				+ orientationsKeepingStep20);
		}

		/// <summary>
		/// 215 closed-chain silhouette — Phase 1 hard gate:
		/// every 90° orientation keeps Overall 215 + height 100, and never re-selects the
		/// overall-closing body 90 once the feature chain is present.
		/// Full multiset equality (always keep 50+75) is Phase 2 generation work.
		/// </summary>
		private static void RotationSignature_ClosedChainStructureIsStable()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var baselineOutline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(baselineOutline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(baselineOutline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(baselineOutline, new Point2D(215.0, 100.0), new Point2D(140.0, 100.0), "top-75");
			AddSegment(baselineOutline, new Point2D(140.0, 100.0), new Point2D(140.0, 90.0), "notch-r");
			AddSegment(baselineOutline, new Point2D(140.0, 90.0), new Point2D(90.0, 90.0), "notch-bottom");
			AddSegment(baselineOutline, new Point2D(90.0, 90.0), new Point2D(90.0, 100.0), "notch-l");
			AddSegment(baselineOutline, new Point2D(90.0, 100.0), new Point2D(0.0, 100.0), "top-90");
			AddSegment(baselineOutline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");

			foreach (double degrees in new[] { 0.0, 90.0, 180.0, 270.0 })
			{
				var outline = degrees == 0.0
					? baselineOutline
					: TransformOutline(baselineOutline, degrees * Math.PI / 180.0);
				double[] signature = GetOverallStructureValueSignature(planner.CreateOutlinePlan(outline), config.GeometryTolerance);
				Console.WriteLine("closed-chain-215 @" + degrees + "° sig=[" + string.Join(",", signature) + "]");
				Assert(SignatureContains(signature, 215.0, config.GeometryTolerance),
					"215-chain @" + degrees + "° must keep Overall 215; sig=[" + string.Join(",", signature) + "]");
				Assert(SignatureContains(signature, 100.0, config.GeometryTolerance),
					"215-chain @" + degrees + "° must keep Overall height 100; sig=[" + string.Join(",", signature) + "]");
				// Phase 1: never keep full 90+50+75 closed body on the structure set.
				bool hasFeature50 = SignatureContains(signature, 50.0, config.GeometryTolerance);
				bool hasSide75 = SignatureContains(signature, 75.0, config.GeometryTolerance);
				bool hasBody90 = SignatureContains(signature, 90.0, config.GeometryTolerance);
				Assert(!(hasFeature50 && hasSide75 && hasBody90),
					"215-chain @" + degrees + "° must not keep full closed body 90+50+75; sig=["
					+ string.Join(",", signature) + "]");
			}
		}

		/// <summary>
		/// Phase A hard gate: F215 four-way Signature must equal Golden215 exactly.
		/// Expected RED on legacy side-patch pipeline until Phase B/C feature-first lands.
		/// Golden215 = {42, 50, 75, 100, 120, 215}
		/// </summary>
		private static void RotationSignature_F215GoldenMultisetFourWayEqual()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			double[] golden = { 42.0, 50.0, 75.0, 100.0, 120.0, 215.0 };
			var baseline = CreateF215NotchOutline();
			AssertFourWaySignatureEqualsGolden(planner, baseline, golden, config.GeometryTolerance, "F215");
		}

		/// <summary>
		/// last-run v42 F215 CAD: 假槽宽 95 挤掉 120，顶 75/80 被圆角切成 72/77。
		/// 槽宽必须两侧内凹；缺口 3mm 内凹仍算 notch。Golden215 四向全等。
		/// </summary>
		private static void RotationSignature_F215CadGoldenMultisetFourWayEqual()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			double[] golden = { 42.0, 50.0, 75.0, 100.0, 120.0, 215.0 };
			var baseline = CreateF215CadFilletedOutline();
			AssertFourWaySignatureEqualsGolden(planner, baseline, golden, config.GeometryTolerance, "F215Cad");
		}

		/// <summary>
		/// last-run v44 90°: Bottom 32 stub + plat at X=42 + C10. Must keep 42, drop 32.
		/// </summary>
		private static void F215CadRotatedKeeps42Drops32Stub()
		{
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 100.0, MaxY = 215.0 };
			AddSegment(outline, new Point2D(10.0, 0.0), new Point2D(42.0, 0.0), "stub32");
			AddSegment(outline, new Point2D(42.0, 0.0), new Point2D(42.0, 75.0), "plat75");
			AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(10.0, 0.0), "c10");
			AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(0.0, 87.0), "t77");
			AddSegment(outline, new Point2D(0.0, 140.0), new Point2D(0.0, 215.0), "t75");
			AddSegment(outline, new Point2D(3.0, 90.0), new Point2D(3.0, 140.0), "n50");
			AddSegment(outline, new Point2D(62.0, 95.0), new Point2D(100.0, 95.0), "pr38");
			AddSegment(outline, new Point2D(100.0, 95.0), new Point2D(100.0, 215.0), "r120");
			AddSegment(outline, new Point2D(100.0, 215.0), new Point2D(0.0, 215.0), "top");
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			double[] signature = GetOverallStructureValueSignature(plan, config.GeometryTolerance);
			Console.WriteLine("F215Cad-90-repro sig=[" + string.Join(",", signature) + "]");
			Assert(SignatureContains(signature, 42.0, 1.0),
				"rotated F215 must keep arm 42; sig=[" + string.Join(",", signature) + "]");
			Assert(!SignatureContains(signature, 32.0, 1.0),
				"rotated F215 must drop chamfer stub 32; sig=[" + string.Join(",", signature) + "]");
		}

		/// <summary>
		/// Phase A/B hard gate: F338 four-way Signature must equal Golden338 exactly.
		/// Golden338 = {73, 87.55, 100, 201.5, 305, 338} (305 kept by product decision).
		/// </summary>
		private static void RotationSignature_F338GoldenMultisetFourWayEqual()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			double[] golden = { 73.0, 87.55, 100.0, 201.5, 305.0, 338.0 };
			var baseline = CreateF338StepOutline();
			AssertFourWaySignatureEqualsGolden(planner, baseline, golden, config.GeometryTolerance, "F338");
		}

		/// <summary>
		/// CAD 轨门禁：Golden338Cad = {20, 73, 87.55, 100, 201.5, 305, 338} 四向全等。
		/// Fixture 模拟 test2 圆角缝（合成边还原 305）+ 外轮廓脚尖 20。
		/// ASD 打开 FeatureFirst 的前置条件（grill-me 2026-08-07）。
		/// </summary>
		private static void RotationSignature_F338CadGoldenMultisetFourWayEqual()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			double[] golden = { 20.0, 73.0, 87.55, 100.0, 201.5, 305.0, 338.0 };
			var baseline = CreateF338CadFilletedOutline();
			AssertFourWaySignatureEqualsGolden(planner, baseline, golden, config.GeometryTolerance, "F338Cad");
		}

		/// <summary>
		/// last-run 8-line staircase: three abutting treads and three risers, all similar
		/// (no 50%+ body). Keep every step including both 134.79 edges; four-way equal.
		/// </summary>
		private static void RotationSignature_Stair3GoldenMultisetFourWayEqual()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			// Open chain: both 134.79 + locating 163.37 + mid riser 126.11; ring is 169.21/140.44.
			double[] golden = { 126.11, 134.79, 134.79, 163.37, 429.91, 438.80 };
			var baseline = CreateStair3Outline();
			AssertFourWaySignatureEqualsGolden(planner, baseline, golden, 0.05, "Stair3");
		}

		/// <summary>
		/// L-plate 257×134: foot 25 + fillet-trimmed boss 30 + locate 58,
		/// arm 25, boss stack 10⊂25⊂40. No 33/232/59.
		/// </summary>
		private static void RotationSignature_LBoss257GoldenMultisetFourWayEqual()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			double[] golden = { 10.0, 25.0, 25.0, 25.0, 30.0, 40.0, 58.0, 134.0, 257.0 };
			var baseline = CreateLBoss257Outline();
			AssertFourWaySignatureEqualsGolden(planner, baseline, golden, 0.05, "LBoss257");
		}

		/// <summary>
		/// last-run RF110: 2mm top / 3mm bottom step risers at X=52.5 must survive.
		/// </summary>
		private static void SteppedPlateReplacesThinStepRisersWithComplement53()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			var outline = CreateSteppedPlate102Outline();
			var plan = planner.CreateOutlinePlan(outline);
			double[] signature = GetOverallStructureValueSignature(plan, config.GeometryTolerance);
			Assert(SignatureContains(signature, 53.0, 0.05),
				"53 (overall min to inner top ledge) must be kept; sig=[" + string.Join(",", signature) + "]");
			Assert(SignatureContains(signature, 50.0, 0.05),
				"left wall 50 must stay; sig=[" + string.Join(",", signature) + "]");
			Assert(SignatureContains(signature, 55.0, 0.05),
				"overall height 55 must be kept; sig=[" + string.Join(",", signature) + "]");
			Assert(!SignatureContains(signature, 2.0, 0.05),
				"top step riser 2 must be replaced by 53; sig=[" + string.Join(",", signature) + "]");
			Assert(!SignatureContains(signature, 3.0, 0.05),
				"bottom step riser 3 must be replaced by 53; sig=[" + string.Join(",", signature) + "]");
			Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Left
					&& Math.Abs(GetSpan(d) - 53.0) <= 0.05),
				"53 must sit on the left with 50/55");
			Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Left
					&& Math.Abs(GetSpan(d) - 50.0) <= 0.05),
				"50 must remain a left structure height");
			Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Top
					&& Math.Abs(GetSpan(d) - 50.0) <= 0.05),
				"top-right pad 50 on MaxY must be kept as TopStructWidth; sig=["
				+ string.Join(",", signature) + "]");
			Assert(!plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Top
					&& Math.Abs(GetSpan(d) - 52.5) <= 0.05),
				"inner top outline 52.5 must stay dropped; pin 52.5 locates that half");
			Assert(!plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Bottom
					&& Math.Abs(GetSpan(d) - 50.0) <= 0.05),
				"bottom-right pad 50 must stay dropped");

			var leftVertical = plan.Dimensions
				.Where(d => d.Orientation == DimensionOrientation.Vertical && d.Side == DimensionSide.Left)
				.Select((d, index) => new { Dim = d, Item = new DimensionLayoutItem
				{
					Kind = d.Kind,
					FirstPoint = d.FirstPoint,
					SecondPoint = d.SecondPoint,
					Span = GetSpan(d),
					ForceOuterLevel = d.ForceOuterLevel,
					AlignmentKey = d.AlignmentKey,
					AlignmentPriority = d.AlignmentPriority,
					ReadingLevel = d.ReadingLevel,
					SourceFeatureId = d.SourceKey
				}})
				.ToList();
			var placements = new DimensionLayoutRules(config)
				.CreateStackingPlan(
					leftVertical.Select(x => x.Item).ToList(),
					DimensionSide.Left,
					outline,
					2.5,
					1.25,
					10.0,
					6.5,
					isHorizontal: false)
				.ToDictionary(p => p.Index);
			int i50 = leftVertical.FindIndex(x => Math.Abs(x.Item.Span - 50.0) <= 0.05 && x.Dim.Kind != DimensionKind.OverallHeight);
			int i53 = leftVertical.FindIndex(x => Math.Abs(x.Item.Span - 53.0) <= 0.05);
			int i55 = leftVertical.FindIndex(x => x.Dim.Kind == DimensionKind.OverallHeight
				|| Math.Abs(x.Item.Span - 55.0) <= 0.05 && x.Dim.ForceOuterLevel);
			Assert(i50 >= 0 && i53 >= 0 && i55 >= 0,
				"left stack must include 50, 53, and 55");
			Assert(placements[i50].Level < placements[i53].Level
				&& placements[i53].Level < placements[i55].Level,
				"left stack must be 50 inside 53 inside 55; levels 50="
				+ placements[i50].Level + " 53=" + placements[i53].Level
				+ " 55=" + placements[i55].Level);

			var top50 = plan.Dimensions.First(d => d.Role == DimensionCandidateRole.Structure
				&& d.Side == DimensionSide.Top
				&& Math.Abs(GetSpan(d) - 50.0) <= 0.05);
			var topStack = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.Normal,
					FirstPoint = top50.FirstPoint,
					SecondPoint = top50.SecondPoint,
					Span = 50.0,
					AlignmentKey = top50.AlignmentKey,
					AlignmentPriority = top50.AlignmentPriority,
					ReadingLevel = DimensionReadingLevel.LocalSpacing
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(40.0, 55.0),
					SecondPoint = new Point2D(92.5, 55.0),
					Span = 52.5,
					AlignmentKey = "PG1:DatumChain:H",
					AlignmentPriority = 110,
					ReadingLevel = DimensionReadingLevel.DatumTransfer,
					SourceFeatureId = "PG2"
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.OverallWidth,
					FirstPoint = new Point2D(0.0, 0.0),
					SecondPoint = new Point2D(102.5, 0.0),
					Span = 102.5,
					ForceOuterLevel = true,
					ReadingLevel = DimensionReadingLevel.Overall
				}
			};
			var topPlacements = new DimensionLayoutRules(config)
				.CreateStackingPlan(topStack, DimensionSide.Top, outline, 2.5, 1.25, 10.0, 6.5, isHorizontal: true)
				.ToDictionary(p => p.Index);
			Assert(topPlacements[0].Level < topPlacements[1].Level
				&& topPlacements[1].Level < topPlacements[2].Level,
				"top 50 must sit inside pin 52.5, overall 102.5 outermost; levels 50="
				+ topPlacements[0].Level + " 52.5=" + topPlacements[1].Level
				+ " 102.5=" + topPlacements[2].Level);
		}

		/// <summary>
		/// C-notch 180×100: top main-body width 120 on MaxY must stay (same class as RF110
		/// top pad 50). Bottom 120 and C-inner 50 stay dropped. Not a fixed 50/52.5 rule.
		/// </summary>
		private static void CNotchPlateKeepsTopEnvelopeBodyWidth120()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			var outline = CreateCNotch180Outline();
			var plan = planner.CreateOutlinePlan(outline);
			double[] signature = GetOverallStructureValueSignature(plan, config.GeometryTolerance);
			Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Top
					&& Math.Abs(GetSpan(d) - 120.0) <= 0.05),
				"top MaxY body 120 must be kept as TopStructWidth; sig=["
				+ string.Join(",", signature) + "]");
			Assert(!plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Bottom
					&& Math.Abs(GetSpan(d) - 120.0) <= 0.05),
				"bottom 120 must stay dropped");
			Assert(!plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Top
					&& Math.Abs(GetSpan(d) - 50.0) <= 0.05),
				"C-inner top shelf 50 must stay dropped");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(GetSpan(d) - 180.0) <= 0.05),
				"overall width 180 must remain");
			Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Left
					&& Math.Abs(GetSpan(d) - 50.0) <= 0.05),
				"C opening height 50 must stay; sig=[" + string.Join(",", signature) + "]");
			Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Left
					&& Math.Abs(GetSpan(d) - 15.0) <= 0.05),
				"bottom residual 15 must stay as location of 50; sig=["
				+ string.Join(",", signature) + "]");
			Assert(!plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& d.Side == DimensionSide.Left
					&& Math.Abs(GetSpan(d) - 35.0) <= 0.05),
				"top-end residual 35 must be dropped to open 15+50+35=100; sig=["
				+ string.Join(",", signature) + "]");

			var top120 = plan.Dimensions.First(d => d.Role == DimensionCandidateRole.Structure
				&& d.Side == DimensionSide.Top
				&& Math.Abs(GetSpan(d) - 120.0) <= 0.05);
			var topStack = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.HoleLocation,
					FirstPoint = new Point2D(120.0, 100.0),
					SecondPoint = new Point2D(165.0, 100.0),
					Span = 45.0,
					PreserveAlignmentLevel = true,
					AlignmentKey = "PG1:FunctionalHoles:H",
					AlignmentPriority = 90,
					ReadingLevel = DimensionReadingLevel.LocalSpacing
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.DatumHoleLocationX,
					FirstPoint = new Point2D(180.0, 85.0),
					SecondPoint = new Point2D(120.0, 85.0),
					Span = 60.0,
					AlignmentKey = "PG1:DatumChain:H",
					AlignmentPriority = 120,
					ReadingLevel = DimensionReadingLevel.DatumTransfer
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.Normal,
					FirstPoint = top120.FirstPoint,
					SecondPoint = top120.SecondPoint,
					Span = 120.0,
					AlignmentKey = top120.AlignmentKey,
					AlignmentPriority = top120.AlignmentPriority,
					ReadingLevel = DimensionReadingLevel.LocalSpacing
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.OverallWidth,
					FirstPoint = new Point2D(0.0, 0.0),
					SecondPoint = new Point2D(180.0, 0.0),
					Span = 180.0,
					ForceOuterLevel = true,
					ReadingLevel = DimensionReadingLevel.Overall
				}
			};
			var topPlacements = new DimensionLayoutRules(config)
				.CreateStackingPlan(topStack, DimensionSide.Top, outline, 2.5, 1.25, 10.0, 6.5, isHorizontal: true)
				.ToDictionary(p => p.Index);
			Assert(topPlacements[0].Level < topPlacements[1].Level
				&& topPlacements[1].Level < topPlacements[2].Level
				&& topPlacements[2].Level < topPlacements[3].Level,
				"top stack must be 45 inside 60 inside 120 inside 180; levels "
				+ topPlacements[0].Level + "/" + topPlacements[1].Level + "/"
				+ topPlacements[2].Level + "/" + topPlacements[3].Level);
		}

		private static void AnnotationCaseSnapshotRequiresSuccessfulCurrentDocumentRun()
		{
			AnnotationCaseRuntime.Invalidate();
			try
			{
				var config = DimensionRuleConfig.CreateDefault();
				config.UseFeatureFirstStructurePipeline = true;
				var planner = new DimensionPlanner(config);
				var plan = planner.CreateOutlinePlan(CreateRectangle(100.0, 50.0));
				var document = new object();
				var database = new object();
				Assert(plan.AnnotationCaseSnapshot != null && AnnotationCaseRuntime.LastSnapshot == null,
					"Planning alone must not publish a confirmed case");
				Assert(!plan.AnnotationCaseSnapshot.MatchesDocument(document, database, "A.dwg", "fingerprint"),
					"An uncommitted plan must not be saveable");
				AnnotationCaseRuntime.Publish(plan.AnnotationCaseSnapshot, document, database, "A.dwg", "fingerprint", "run-1");
				var snapshot = AnnotationCaseRuntime.LastSnapshot;
				Assert(snapshot != null && snapshot.MatchesDocument(document, database, "A.dwg", "fingerprint"),
					"A successful run must be saveable on its current document");
				Assert(!snapshot.MatchesDocument(new object(), database, "A.dwg", "fingerprint")
					&& !snapshot.MatchesDocument(document, new object(), "A.dwg", "fingerprint")
					&& !snapshot.MatchesDocument(document, database, "B.dwg", "fingerprint"),
					"A different or reopened document/database must not reuse the snapshot");
				planner.CreateOutlinePlan(CreateRectangle(80.0, 40.0));
				Assert(object.ReferenceEquals(snapshot, AnnotationCaseRuntime.LastSnapshot),
					"Other planner callers must not replace the confirmed snapshot");
				AnnotationCaseRuntime.Invalidate();
				Assert(AnnotationCaseRuntime.LastSnapshot == null, "Cancellation/failure must clear the snapshot");
				AnnotationCaseRuntime.Publish(plan.AnnotationCaseSnapshot, document, database, "A.dwg", "fingerprint", "");
				Assert(AnnotationCaseRuntime.LastSnapshot == null, "Publishing without a run identity must fail closed");
			}
			finally
			{
				AnnotationCaseRuntime.Invalidate();
			}
		}

		private static void AnnotationCaseOverlayDropsMaxEndResidual()
		{
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 180.0, MaxY = 100.0 };
			List<StructureFeature> features = CreateCoveringVerticalChain(outline, 15.0, 50.0, 35.0);
			string minToken = StructureSchemaEncoder.Encode(features[0], outline);
			string maxToken = StructureSchemaEncoder.Encode(features[2], outline);
			Assert(minToken.Contains("ResidualMin") && maxToken.Contains("ResidualMax") && minToken != maxToken,
				"encoder must distinguish min/max residuals without millimetre values; min="
				+ minToken + " max=" + maxToken);
			Assert(!minToken.Contains("15") && !maxToken.Contains("35"),
				"tokens must not embed absolute spans");

			var store = new AnnotationCaseStore();
			store.Add(new AnnotationCase
			{
				Id = "cnotch-open-top",
				Strategies = { AnnotationStrategyIds.OpenCoveringDropResidualMax },
				Schemas = { "CoveringChain|V|ResidualMin|RealStep|ResidualMax" },
				Decisions =
				{
					new AnnotationCaseDecision { Token = minToken, Keep = true },
					new AnnotationCaseDecision { Token = maxToken, Keep = false }
				}
			});
			string temp = Path.Combine(Path.GetTempPath(), "annotation-case-overlay-test.json");
			store.Save(temp);
			AnnotationCaseStore loaded = AnnotationCaseStore.Load(temp);
			Assert(loaded.Cases.Count == 1
					&& loaded.Cases[0].Strategies.Contains(AnnotationStrategyIds.OpenCoveringDropResidualMax)
					&& loaded.Cases[0].Schemas.Count == 1,
				"store must round-trip strategy and schema");

			string matched = new AnnotationCaseOverlay(loaded).Apply(features, outline);
			Assert(matched == "cnotch-open-top", "overlay must hit the confirmed strategy case");
			Assert(features[0].Keep && features[1].Keep && !features[2].Keep,
				"overlay must drop ResidualMax and keep ResidualMin plus the real wall");

			features[2].Keep = true;
			features[2].Kind = StructureFeatureKind.RealStep;
			features[2].SuppressReason = null;
			string emptyHit = new AnnotationCaseOverlay(new AnnotationCaseStore()).Apply(features, outline);
			Assert(string.IsNullOrEmpty(emptyHit) && features[2].Keep,
				"empty store must leave Select decisions unchanged");
		}

		/// <summary>
		/// Square vs fillet (different spans / deciles): capture logic from one covering
		/// chain and apply it to the other. Token overlay would miss; strategy must hit.
		/// </summary>
		private static void AnnotationCaseStrategyMatchesSquareAndFilletCoveringChains()
		{
			var squareOutline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 180.0, MaxY = 100.0 };
			var filletOutline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 200.0, MaxY = 120.0 };
			List<StructureFeature> square = CreateCoveringVerticalChain(squareOutline, 15.0, 50.0, 35.0);
			List<StructureFeature> fillet = CreateCoveringVerticalChain(filletOutline, 10.0, 70.0, 40.0);
			string squareMin = StructureSchemaEncoder.Encode(square[0], squareOutline);
			string filletMin = StructureSchemaEncoder.Encode(fillet[0], filletOutline);
			Assert(squareMin != filletMin,
				"square and fillet ResidualMin tokens must differ (deciles); square="
				+ squareMin + " fillet=" + filletMin);

			AnnotationCase captured = AnnotationCaseOverlay.Capture(square, squareOutline, "square-cnotch");
			Assert(captured.Strategies.Contains(AnnotationStrategyIds.OpenCoveringDropResidualMax),
				"capture must record OpenCoveringDropResidualMax, not only tokens");
			Assert(captured.Schemas.Contains("CoveringChain|V|ResidualMin|RealStep|ResidualMax"),
				"capture schema must be qualitative covering-chain, got ["
				+ string.Join(",", captured.Schemas) + "]");

			var store = new AnnotationCaseStore();
			store.Add(captured);
			string matched = new AnnotationCaseOverlay(store).Apply(fillet, filletOutline);
			Assert(matched == "square-cnotch", "fillet covering chain must inherit square strategy");
			Assert(fillet[0].Keep && fillet[1].Keep && !fillet[2].Keep,
				"inherited strategy must drop fillet ResidualMax and keep locating residual + wall");
		}

		/// <summary>
		/// F215-class lone ResidualMin (42) does not cover overall with ResidualMax;
		/// a covering-chain case must not drop it.
		/// </summary>
		private static void AnnotationCaseStrategyDoesNotDropLoneResidual()
		{
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 215.0, MaxY = 215.0 };
			var lone = new StructureFeature
			{
				Axis = StructureFeatureAxis.Vertical,
				Kind = StructureFeatureKind.RealStep,
				T0 = 0.0,
				T1 = 42.0,
				CrossPosition = 0.0,
				TouchesOverallMin = true,
				SourceKey = "LedgeResidualUp:f215",
				Keep = true
			};
			var store = new AnnotationCaseStore();
			store.Add(new AnnotationCase
			{
				Id = "cnotch-open-top",
				Strategies = { AnnotationStrategyIds.OpenCoveringDropResidualMax },
				Schemas = { "CoveringChain|V|ResidualMin|RealStep|ResidualMax" }
			});
			string matched = new AnnotationCaseOverlay(store).Apply(
				new List<StructureFeature> { lone }, outline);
			Assert(string.IsNullOrEmpty(matched) && lone.Keep,
				"lone ResidualMin that does not cover overall must not inherit covering-chain drop");
		}

		private static List<StructureFeature> CreateCoveringVerticalChain(
			OutlineFeature2D outline,
			double minSpan,
			double wallSpan,
			double maxSpan)
		{
			double h = outline.MaxY - outline.MinY;
			Assert(Math.Abs(minSpan + wallSpan + maxSpan - h) <= 0.001,
				"covering chain spans must sum to overall height");
			return new List<StructureFeature>
			{
				new StructureFeature
				{
					Axis = StructureFeatureAxis.Vertical,
					Kind = StructureFeatureKind.RealStep,
					T0 = outline.MinY,
					T1 = outline.MinY + minSpan,
					CrossPosition = outline.MinX,
					TouchesOverallMin = true,
					SourceKey = "LedgeResidualDown:c-bot",
					Keep = true
				},
				new StructureFeature
				{
					Axis = StructureFeatureAxis.Vertical,
					Kind = StructureFeatureKind.RealStep,
					T0 = outline.MinY + minSpan,
					T1 = outline.MinY + minSpan + wallSpan,
					CrossPosition = outline.MinX,
					SourceKey = "left-wall",
					Keep = true
				},
				new StructureFeature
				{
					Axis = StructureFeatureAxis.Vertical,
					Kind = StructureFeatureKind.RealStep,
					T0 = outline.MinY + minSpan + wallSpan,
					T1 = outline.MaxY,
					CrossPosition = outline.MinX,
					TouchesOverallMax = true,
					SourceKey = "LedgeResidualUp:c-top",
					Keep = true
				}
			};
		}

		private static OutlineFeature2D CreateSteppedPlate102Outline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 102.5, MaxY = 55.0 };
			AddSegment(o, new Point2D(0.0, 3.0), new Point2D(52.5, 3.0), "bot-52.5");
			AddSegment(o, new Point2D(52.5, 3.0), new Point2D(52.5, 0.0), "riser-3");
			AddSegment(o, new Point2D(52.5, 0.0), new Point2D(102.5, 0.0), "bot-50");
			AddSegment(o, new Point2D(102.5, 0.0), new Point2D(102.5, 55.0), "right");
			AddSegment(o, new Point2D(52.5, 55.0), new Point2D(102.5, 55.0), "top-50");
			AddSegment(o, new Point2D(52.5, 53.0), new Point2D(52.5, 55.0), "riser-2");
			AddSegment(o, new Point2D(0.0, 53.0), new Point2D(52.5, 53.0), "top-52.5");
			AddSegment(o, new Point2D(0.0, 3.0), new Point2D(0.0, 53.0), "left-50");
			return o;
		}

		/// <summary>
		/// Sharp stand-in for last-run C-notch 180×100 (fillets collapsed to diagonals).
		/// Top/bottom body 120 at X=60–180; C opening 50×50 at the left.
		/// </summary>
		private static OutlineFeature2D CreateCNotch180Outline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 180.0, MaxY = 100.0 };
			AddSegment(o, new Point2D(0.0, 15.0), new Point2D(50.0, 15.0), "c-bot-50");
			AddSegment(o, new Point2D(50.0, 15.0), new Point2D(60.0, 0.0), "fillet-bl");
			AddSegment(o, new Point2D(60.0, 0.0), new Point2D(180.0, 0.0), "bot-120");
			AddSegment(o, new Point2D(180.0, 0.0), new Point2D(180.0, 100.0), "right");
			AddSegment(o, new Point2D(180.0, 100.0), new Point2D(60.0, 100.0), "top-120");
			AddSegment(o, new Point2D(60.0, 100.0), new Point2D(50.0, 65.0), "fillet-tl");
			AddSegment(o, new Point2D(50.0, 65.0), new Point2D(0.0, 65.0), "c-top-50");
			AddSegment(o, new Point2D(0.0, 65.0), new Point2D(0.0, 15.0), "left-50");
			return o;
		}

		private static void AssertFourWaySignatureEqualsGolden(
			DimensionPlanner planner,
			OutlineFeature2D baseline,
			double[] golden,
			double tol,
			string label)
		{
			double[] sortedGolden = golden.OrderBy(v => v).ToArray();
			foreach (double degrees in new[] { 0.0, 90.0, 180.0, 270.0 })
			{
				OutlineFeature2D outline = degrees == 0.0
					? baseline
					: TransformOutline(baseline, degrees * Math.PI / 180.0);
				double[] signature = GetOverallStructureValueSignature(
					planner.CreateOutlinePlan(outline),
					tol);
				Console.WriteLine(label + " @" + degrees + "° sig=[" + string.Join(",", signature) + "]"
					+ " golden=[" + string.Join(",", sortedGolden) + "]");
				Assert(SignaturesEqualMultiset(signature, sortedGolden, tol),
					label + " @" + degrees + "° Signature must equal golden; got=["
					+ string.Join(",", signature) + "] expected=["
					+ string.Join(",", sortedGolden) + "]");
			}
		}

		private static bool SignaturesEqualMultiset(double[] actual, double[] goldenSorted, double tol)
		{
			if (actual == null || goldenSorted == null || actual.Length != goldenSorted.Length)
			{
				return false;
			}
			double[] a = actual.OrderBy(v => v).ToArray();
			for (int i = 0; i < a.Length; i++)
			{
				if (Math.Abs(a[i] - goldenSorted[i]) > tol)
				{
					return false;
				}
			}
			return true;
		}

		/// <summary>
		/// F215: overall 215×100, top notch 50 with sides 75/90, bottom platform 120+95, left arm 42.
		/// </summary>
		private static OutlineFeature2D CreateF215NotchOutline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 215.0, MaxY = 100.0 };
			AddSegment(o, new Point2D(0.0, 0.0), new Point2D(95.0, 0.0), "b95");
			AddSegment(o, new Point2D(95.0, 0.0), new Point2D(215.0, 0.0), "b120");
			AddSegment(o, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(o, new Point2D(215.0, 100.0), new Point2D(140.0, 100.0), "t75");
			AddSegment(o, new Point2D(140.0, 100.0), new Point2D(140.0, 90.0), "nr");
			AddSegment(o, new Point2D(140.0, 90.0), new Point2D(90.0, 90.0), "n50");
			AddSegment(o, new Point2D(90.0, 90.0), new Point2D(90.0, 100.0), "nl");
			AddSegment(o, new Point2D(90.0, 100.0), new Point2D(10.0, 100.0), "tl");
			AddSegment(o, new Point2D(10.0, 100.0), new Point2D(0.0, 90.0), "ch");
			AddSegment(o, new Point2D(0.0, 90.0), new Point2D(0.0, 58.0), "lu");
			AddSegment(o, new Point2D(0.0, 58.0), new Point2D(95.0, 58.0), "pt");
			AddSegment(o, new Point2D(95.0, 58.0), new Point2D(95.0, 0.0), "pr");
			return o;
		}

		/// <summary>
		/// last-run F215 CAD：顶缺口 50 @ Y=97（圆角 3mm），左右顶臂 77/72，
		/// 底 95+120，内台 0–95 @ Y=48（不得报 StepGroove:95），左臂残 42。
		/// </summary>
		private static OutlineFeature2D CreateF215CadFilletedOutline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 215.0, MaxY = 100.0 };
			AddSegment(o, new Point2D(0.0, 0.0), new Point2D(95.0, 0.0), "b95");
			AddSegment(o, new Point2D(95.0, 0.0), new Point2D(215.0, 0.0), "b120");
			AddSegment(o, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(o, new Point2D(143.0, 100.0), new Point2D(215.0, 100.0), "t72");
			AddSegment(o, new Point2D(143.0, 100.0), new Point2D(140.0, 97.0), "chamfer-tr");
			AddSegment(o, new Point2D(140.0, 97.0), new Point2D(90.0, 97.0), "n50");
			AddSegment(o, new Point2D(90.0, 97.0), new Point2D(87.0, 100.0), "chamfer-tl-notch");
			AddSegment(o, new Point2D(10.0, 100.0), new Point2D(87.0, 100.0), "t77");
			AddSegment(o, new Point2D(10.0, 100.0), new Point2D(0.0, 90.0), "chamfer-left");
			AddSegment(o, new Point2D(0.0, 90.0), new Point2D(0.0, 58.0), "lu32");
			AddSegment(o, new Point2D(0.0, 58.0), new Point2D(95.0, 58.0), "plat95");
			AddSegment(o, new Point2D(95.0, 58.0), new Point2D(95.0, 0.0), "pr");
			return o;
		}

		/// <summary>
		/// F338: overall 338×201.5, multi-level steps 73+87.55, arm 100, long structure 305.
		/// Matches product golden that keeps 305.
		/// </summary>
		private static OutlineFeature2D CreateF338StepOutline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 338.0, MaxY = 201.5 };
			// Top outer 305 + small tip shelf 20/33 region simplified as continuous top then step
			AddSegment(o, new Point2D(0.0, 201.5), new Point2D(305.0, 201.5), "top-305");
			AddSegment(o, new Point2D(305.0, 201.5), new Point2D(305.0, 100.0), "right-upper");
			AddSegment(o, new Point2D(305.0, 100.0), new Point2D(338.0, 100.0), "right-arm-100");
			AddSegment(o, new Point2D(338.0, 100.0), new Point2D(338.0, 0.0), "right-foot");
			// Bottom multi-level: 73 + 87.55 + body remainder geometry (body suppressed in golden)
			AddSegment(o, new Point2D(338.0, 0.0), new Point2D(265.0, 0.0), "bottom-73");
			AddSegment(o, new Point2D(265.0, 0.0), new Point2D(265.0, 50.0), "riser-87");
			AddSegment(o, new Point2D(265.0, 50.0), new Point2D(177.45, 50.0), "bottom-87.55");
			AddSegment(o, new Point2D(177.45, 50.0), new Point2D(177.45, 100.0), "riser-body");
			AddSegment(o, new Point2D(177.45, 100.0), new Point2D(0.0, 100.0), "bottom-body-177");
			AddSegment(o, new Point2D(0.0, 100.0), new Point2D(0.0, 201.5), "left");
			return o;
		}

		/// <summary>
		/// last-run 8-line 3-step stair (no fillet). Both 134.79 treads are required.
		/// </summary>
		private static OutlineFeature2D CreateStair3Outline()
		{
			var o = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 438.79648808,
				MaxY = 429.90990921
			};
			AddSegment(o, new Point2D(0.0, 0.0), new Point2D(438.79648808, 0.0), "bottom");
			AddSegment(o, new Point2D(438.79648808, 0.0), new Point2D(438.79648808, 429.90990921), "right");
			AddSegment(o, new Point2D(304.00278978, 429.90990921), new Point2D(438.79648808, 429.90990921), "top-134");
			AddSegment(o, new Point2D(304.00278978, 289.47267220), new Point2D(304.00278978, 429.90990921), "rise-140");
			AddSegment(o, new Point2D(169.20909149, 289.47267220), new Point2D(304.00278978, 289.47267220), "mid-134");
			AddSegment(o, new Point2D(169.20909149, 163.36576549), new Point2D(169.20909149, 289.47267220), "rise-126");
			AddSegment(o, new Point2D(0.0, 163.36576549), new Point2D(169.20909149, 163.36576549), "ledge-169");
			AddSegment(o, new Point2D(0.0, 0.0), new Point2D(0.0, 163.36576549), "left-163");
			return o;
		}

		/// <summary>
		/// last-run L 257×134: foot 25, 3mm fillet, boss clear 30, locate 58, arm 25.
		/// </summary>
		private static OutlineFeature2D CreateLBoss257Outline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 257.0, MaxY = 134.0 };
			AddSegment(o, new Point2D(0.0, 0.0), new Point2D(25.0, 0.0), "foot-25");
			AddSegment(o, new Point2D(25.0, 0.0), new Point2D(25.0, 18.0), "boss-left-low");
			AddSegment(o, new Point2D(25.0, 18.0), new Point2D(28.0, 15.0), "chamfer-shelf");
			AddSegment(o, new Point2D(28.0, 15.0), new Point2D(58.0, 15.0), "shelf-30");
			AddSegment(o, new Point2D(58.0, 15.0), new Point2D(58.0, 25.0), "step-10");
			AddSegment(o, new Point2D(58.0, 25.0), new Point2D(58.0, 40.0), "step-15");
			AddSegment(o, new Point2D(28.0, 40.0), new Point2D(58.0, 40.0), "ledge-30");
			AddSegment(o, new Point2D(25.0, 43.0), new Point2D(28.0, 40.0), "chamfer-ledge");
			AddSegment(o, new Point2D(25.0, 43.0), new Point2D(25.0, 109.0), "waist");
			AddSegment(o, new Point2D(25.0, 109.0), new Point2D(257.0, 109.0), "arm-bot");
			AddSegment(o, new Point2D(257.0, 109.0), new Point2D(257.0, 134.0), "arm-25");
			AddSegment(o, new Point2D(25.0, 134.0), new Point2D(257.0, 134.0), "top-232");
			AddSegment(o, new Point2D(0.0, 134.0), new Point2D(25.0, 134.0), "left-top");
			AddSegment(o, new Point2D(0.0, 0.0), new Point2D(0.0, 134.0), "left");
			return o;
		}

		/// <summary>
		/// CAD 轨 F338：顶 305 共线微缝 + MaxX 脚尖 20 + 整脚 100（ledge residual）+ 台阶 73/87.55。
		/// Golden338Cad = {20, 73, 87.55, 100, 201.5, 305, 338}.
		/// </summary>
		private static OutlineFeature2D CreateF338CadFilletedOutline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 338.0, MaxY = 201.5 };
			// Fillet-truncated top: straight 300 only; arc chords bridge to verticals at x=0 and x=305
			// (real CAD skips arc chords → need ExpandFeaturesAcrossFilletBridges → 305).
			AddSegment(o, new Point2D(2.5, 201.5), new Point2D(302.5, 201.5), "top-truncated");
			o.Segments.Add(new Segment2D(new Point2D(0.0, 201.5), new Point2D(2.5, 201.5))
			{
				SourceKey = "fillet-tl",
				IsArcChord = true
			});
			o.Segments.Add(new Segment2D(new Point2D(302.5, 201.5), new Point2D(305.0, 201.5))
			{
				SourceKey = "fillet-tr",
				IsArcChord = true
			});
			AddSegment(o, new Point2D(305.0, 201.5), new Point2D(305.0, 100.0), "right-upper");
			AddSegment(o, new Point2D(305.0, 100.0), new Point2D(338.0, 100.0), "right-arm");
			AddSegment(o, new Point2D(338.0, 100.0), new Point2D(338.0, 20.0), "right-foot-80");
			AddSegment(o, new Point2D(338.0, 20.0), new Point2D(338.0, 0.0), "tip-20");
			// Bottom 73 truncated by fillet to 63; arc bridges to riser at x=265
			AddSegment(o, new Point2D(333.0, 0.0), new Point2D(270.0, 0.0), "bottom-73-trunc");
			o.Segments.Add(new Segment2D(new Point2D(338.0, 0.0), new Point2D(333.0, 0.0))
			{
				SourceKey = "fillet-br",
				IsArcChord = true
			});
			o.Segments.Add(new Segment2D(new Point2D(270.0, 0.0), new Point2D(265.0, 0.0))
			{
				SourceKey = "fillet-bl",
				IsArcChord = true
			});
			AddSegment(o, new Point2D(265.0, 0.0), new Point2D(265.0, 50.0), "riser-87");
			// mid step 87.55 truncated similarly
			AddSegment(o, new Point2D(262.5, 50.0), new Point2D(180.0, 50.0), "bottom-87-trunc");
			o.Segments.Add(new Segment2D(new Point2D(265.0, 50.0), new Point2D(262.5, 50.0))
			{
				SourceKey = "fillet-mr",
				IsArcChord = true
			});
			o.Segments.Add(new Segment2D(new Point2D(180.0, 50.0), new Point2D(177.45, 50.0))
			{
				SourceKey = "fillet-ml",
				IsArcChord = true
			});
			AddSegment(o, new Point2D(177.45, 50.0), new Point2D(177.45, 100.0), "riser-body");
			AddSegment(o, new Point2D(177.45, 100.0), new Point2D(0.0, 100.0), "bottom-body-177");
			AddSegment(o, new Point2D(0.0, 100.0), new Point2D(0.0, 201.5), "left");
			return o;
		}

		/// <summary>
		/// last-run v38: truncated mid floor 82.55 at Y=106.5, body ledge ends at 172.45 / Y=101.5,
		/// 73-riser at X=265. 槽宽 = wall-to-wall 92.55, not floor length 82.55, not riser 86.5.
		/// </summary>
		private static OutlineFeature2D CreateF338CadLastRunGrooveOutline()
		{
			var o = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 338.0, MaxY = 201.5 };
			AddSegment(o, new Point2D(2.5, 201.5), new Point2D(302.5, 201.5), "top-truncated");
			o.Segments.Add(new Segment2D(new Point2D(0.0, 201.5), new Point2D(2.5, 201.5))
			{
				SourceKey = "fillet-tl",
				IsArcChord = true
			});
			o.Segments.Add(new Segment2D(new Point2D(302.5, 201.5), new Point2D(305.0, 201.5))
			{
				SourceKey = "fillet-tr",
				IsArcChord = true
			});
			// last-run right wall is 171.5 (fillet-truncated), not a clean 100 arm.
			AddSegment(o, new Point2D(305.0, 196.5), new Point2D(305.0, 25.0), "right-upper-171.5");
			o.Segments.Add(new Segment2D(new Point2D(305.0, 201.5), new Point2D(305.0, 196.5))
			{
				SourceKey = "fillet-right-top",
				IsArcChord = true
			});
			AddSegment(o, new Point2D(305.0, 25.0), new Point2D(310.0, 20.0), "chamfer-right-arm");
			AddSegment(o, new Point2D(310.0, 20.0), new Point2D(338.0, 20.0), "right-arm-28");
			AddSegment(o, new Point2D(338.0, 20.0), new Point2D(338.0, 0.0), "tip-20");
			// Truncated 73 starts at 275; diagonal chamfer to riser 265@Y=10.
			// 1D furthest-station snap used to jump 260→275 and emit 102.55.
			AddSegment(o, new Point2D(275.0, 0.0), new Point2D(338.0, 0.0), "bottom-63");
			AddSegment(o, new Point2D(275.0, 0.0), new Point2D(265.0, 10.0), "chamfer-foot");
			AddSegment(o, new Point2D(265.0, 10.0), new Point2D(265.0, 101.5), "riser-91.5");
			// Right chamfer: floor X=260 / Y=106.5 → riser X=265 / Y=101.5
			AddSegment(o, new Point2D(260.0, 106.5), new Point2D(265.0, 101.5), "chamfer-groove-right");
			// Truncated mid floor 82.55 (last-run StepGroove:82.55)
			AddSegment(o, new Point2D(177.45, 106.5), new Point2D(260.0, 106.5), "mid-floor-82.55");
			// Left chamfer off-band: floor X=177.45 / Y=106.5 → body X=172.45 / Y=101.5
			AddSegment(o, new Point2D(177.45, 106.5), new Point2D(172.45, 101.5), "chamfer-groove-left");
			AddSegment(o, new Point2D(172.45, 101.5), new Point2D(0.0, 101.5), "body-172.45");
			AddSegment(o, new Point2D(0.0, 101.5), new Point2D(0.0, 201.5), "left");
			return o;
		}

		/// <summary>
		/// last-run v38 emitted StepGroove:82.55 (truncated floor) + StepGroove:86.5 (riser).
		/// Four-way must keep wall-to-wall 槽宽 ~92.55 and must not keep 82.55 / 86.5.
		/// </summary>
		private static void CadLastRunGrooveSnapsToWallClearWidthFourWay()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			var extractor = new StructureFeatureExtractor(config);
			var selector = new StructureMeasurementSelector(config);
			var baseline = CreateF338CadLastRunGrooveOutline();
			const double groove = 92.55;
			const double truncatedFloor = 82.55;
			const double falseRiser = 86.5;
			foreach (double degrees in new[] { 0.0, 90.0, 180.0, 270.0 })
			{
				OutlineFeature2D outline = degrees == 0.0
					? baseline
					: TransformOutline(baseline, degrees * Math.PI / 180.0);
				IList<StructureFeature> kept = selector.Select(extractor.Extract(outline), outline);
				double[] spans = kept
					.Where(f => f.Kind != StructureFeatureKind.Overall)
					.Select(f => Math.Round(f.Span, 2))
					.OrderBy(v => v)
					.ToArray();
				Console.WriteLine("CAD-last-run-groove @" + degrees + "° kept=[" + string.Join(",", spans) + "]");
				Assert(spans.Any(s => Math.Abs(s - groove) <= 1.0),
					"CAD-last-run @" + degrees + "° must keep 槽宽 ~92.55; kept=[" + string.Join(",", spans) + "]");
				Assert(!spans.Any(s => Math.Abs(s - truncatedFloor) <= 1.0),
					"CAD-last-run @" + degrees + "° must not keep truncated floor 82.55; kept=[" + string.Join(",", spans) + "]");
				Assert(!spans.Any(s => Math.Abs(s - falseRiser) <= 1.0),
					"CAD-last-run @" + degrees + "° must not keep riser 86.5 as groove; kept=[" + string.Join(",", spans) + "]");
				Assert(!spans.Any(s => Math.Abs(s - 102.55) <= 1.0),
					"CAD-last-run @" + degrees + "° must not over-snap 槽宽 to 102.55; kept=[" + string.Join(",", spans) + "]");
				Assert(spans.Any(s => Math.Abs(s - 20.0) <= 1.0),
					"CAD-last-run @" + degrees + "° must keep foot tip 20; kept=[" + string.Join(",", spans) + "]");

				double[] signature = GetOverallStructureValueSignature(
					planner.CreateOutlinePlan(outline),
					config.GeometryTolerance);
				Console.WriteLine("CAD-last-run-groove @" + degrees + "° sig=[" + string.Join(",", signature) + "]");
				Assert(SignatureContains(signature, groove, 1.0),
					"CAD-last-run @" + degrees + "° plan must include 槽宽 ~92.55; sig=[" + string.Join(",", signature) + "]");
				Assert(!SignatureContains(signature, truncatedFloor, 1.0),
					"CAD-last-run @" + degrees + "° plan must not include 82.55; sig=[" + string.Join(",", signature) + "]");
				Assert(!SignatureContains(signature, falseRiser, 1.0),
					"CAD-last-run @" + degrees + "° plan must not include 86.5; sig=[" + string.Join(",", signature) + "]");
			}
		}

		/// <summary>
		/// 槽宽优先与定位台阶 73 同侧对齐（不要贴到对面的 305）。
		/// </summary>
		private static void StepGroovePlacesOnSameSideAsOuterStepFourWay()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var planner = new DimensionPlanner(config);
			var cases = new[]
			{
				new { Label = "F338Cad", Outline = CreateF338CadFilletedOutline(), Groove = 87.55 },
				new { Label = "CAD-last-run", Outline = CreateF338CadLastRunGrooveOutline(), Groove = 92.55 }
			};
			foreach (var c in cases)
			{
				foreach (double degrees in new[] { 0.0, 90.0, 180.0, 270.0 })
				{
					OutlineFeature2D outline = degrees == 0.0
						? c.Outline
						: TransformOutline(c.Outline, degrees * Math.PI / 180.0);
					var structs = planner.CreateOutlinePlan(outline).Dimensions
						.Where(d => d.Role == DimensionCandidateRole.Structure)
						.ToList();
					var groove = structs.FirstOrDefault(d => Math.Abs(GetSpan(d) - c.Groove) <= 1.0);
					var step73 = structs.FirstOrDefault(d => Math.Abs(GetSpan(d) - 73.0) <= 1.0);
					Assert(groove != null,
						c.Label + " @" + degrees + "° missing 槽宽; sides=["
						+ string.Join(",", structs.Select(d => GetSpan(d) + "@" + d.Side)) + "]");
					Assert(step73 != null,
						c.Label + " @" + degrees + "° missing 73; sides=["
						+ string.Join(",", structs.Select(d => GetSpan(d) + "@" + d.Side)) + "]");
					Console.WriteLine(c.Label + " @" + degrees + "° groove=" + groove.Side
						+ " 73=" + step73.Side);
					Assert(groove.Side == step73.Side,
						c.Label + " @" + degrees + "° 槽宽 must sit with 73; groove="
						+ groove.Side + " 73=" + step73.Side);
				}
			}
		}

		private static OutlineFeature2D TransformOutline(OutlineFeature2D source, double angle)
		{
			var transformed = new OutlineFeature2D();
			foreach (Point2D vertex in source.Vertices)
			{
				transformed.Vertices.Add(TransformPoint(vertex, angle));
			}
			foreach (Segment2D segment in source.Segments)
			{
				if (segment == null)
				{
					transformed.Segments.Add(null);
					continue;
				}
				transformed.Segments.Add(new Segment2D(
					TransformPoint(segment.Start, angle),
					TransformPoint(segment.End, angle))
				{
					SourceKey = segment.SourceKey,
					IsArcChord = segment.IsArcChord
				});
			}
			if (transformed.Segments.Count == 0)
			{
				transformed.MinX = source.MinX;
				transformed.MaxX = source.MaxX;
				transformed.MinY = source.MinY;
				transformed.MaxY = source.MaxY;
				return transformed;
			}
			var points = transformed.Segments
				.Where(segment => segment != null)
				.SelectMany(segment => new[] { segment.Start, segment.End })
				.ToList();
			transformed.MinX = points.Min(point => point.X);
			transformed.MaxX = points.Max(point => point.X);
			transformed.MinY = points.Min(point => point.Y);
			transformed.MaxY = points.Max(point => point.Y);
			return transformed;
		}

		private static Point2D TransformPoint(Point2D point, double angle)
		{
			// Snap cardinal angles so H/V edges stay exactly axis-aligned after 90° steps
			// (feature extractor requires IsHorizontal/IsVertical).
			double degrees = angle * 180.0 / Math.PI;
			double norm = ((degrees % 360) + 360) % 360;
			if (Math.Abs(norm) < 1e-9 || Math.Abs(norm - 360) < 1e-9)
			{
				return new Point2D(point.X, point.Y);
			}
			if (Math.Abs(norm - 90) < 1e-9)
			{
				return new Point2D(-point.Y, point.X);
			}
			if (Math.Abs(norm - 180) < 1e-9)
			{
				return new Point2D(-point.X, -point.Y);
			}
			if (Math.Abs(norm - 270) < 1e-9)
			{
				return new Point2D(point.Y, -point.X);
			}
			double cosine = Math.Cos(angle);
			double sine = Math.Sin(angle);
			return new Point2D(
				cosine * point.X - sine * point.Y,
				sine * point.X + cosine * point.Y);
		}

		private static void AssertTest2BottomContourPlan(
			DimensionPlan plan,
			OutlineFeature2D outline,
			DimensionRuleConfig config)
		{
			const double overallWidth = 438.79648808;
			const double realWidth = 134.79369829;
			const double projectedWidth = 169.20909149;
			var selected = plan.Dimensions
				.Where(d => (d.DebugRole == "BottomStructWidth" || d.DebugRole == "OutlineSegment")
					&& d.Orientation == DimensionOrientation.Horizontal)
				.ToList();
			var selectedReal = selected
				.Where(d => Math.Abs(GetSpan(d) - realWidth) <= config.GeometryTolerance
					&& Math.Abs(d.FirstPoint.Y - d.SecondPoint.Y) <= config.GeometryTolerance)
				.ToList();
			var projectedCandidates = plan.Diagnostics.DimensionCandidates
				.Where(c => (c.DebugRole == "BottomStructWidth" || c.DebugRole == "OutlineSegment")
					&& Math.Abs(c.Value - projectedWidth) <= config.GeometryTolerance)
				.ToList();

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
				&& Math.Abs(GetSpan(d) - overallWidth) <= config.GeometryTolerance),
				"test2 overall width 438.79648808 must remain");
			Assert(selectedReal.Count == 2
				&& selectedReal.Count(d => d.DebugRole == "BottomStructWidth") == 1
				&& selectedReal.Count(d => d.DebugRole == "OutlineSegment") == 1
				&& selectedReal.All(d => HasRealHorizontalSegment(d, outline, config)),
				"test2 must retain exactly one real BottomStructWidth and one real OutlineSegment at 134.79369829 (selected="
				+ string.Join(",", selected.Select(d => d.DebugRole + "@" + Math.Round(GetSpan(d), 3)
					+ "/yΔ=" + Math.Round(Math.Abs(d.FirstPoint.Y - d.SecondPoint.Y), 3)))
				+ "; real=" + string.Join(",", selectedReal.Select(d => d.DebugRole + "@" + Math.Round(GetSpan(d), 3)))
				+ ")");
			Assert(!selected.Any(d => Math.Abs(GetSpan(d) - projectedWidth) <= config.GeometryTolerance),
				"test2 derived/projection width 169.20909149 must not remain selected");
			Assert(selected.All(d => Math.Abs(d.FirstPoint.Y - d.SecondPoint.Y) <= config.GeometryTolerance),
				"test2 selected Bottom/Outline widths must attach to real horizontal edges, not cross-level projections");
			Assert(projectedCandidates.Count > 0 && projectedCandidates.All(c => c.IsSuppressed && !c.IsSelected),
				"test2 169.20909149 candidates must all be suppressed");
			Assert(projectedCandidates.Any(c => c.DebugRole == "BottomStructWidth"
				&& c.SuppressedReason == "ProjectedStructureOverallPartition"),
				"test2 cross-level BottomStructWidth 169.20909149 must record ProjectedStructureOverallPartition");
			Assert(projectedCandidates.Any(c => c.DebugRole == "OutlineSegment"
				&& c.SuppressedReason == "OutlineSegmentOverallPartition"),
				"test2 real OutlineSegment 169.20909149 must record OutlineSegmentOverallPartition");
		}

		private static bool HasRealHorizontalSegment(
			PlannedDimension dimension,
			OutlineFeature2D outline,
			DimensionRuleConfig config)
		{
			double minX = Math.Min(dimension.FirstPoint.X, dimension.SecondPoint.X);
			double maxX = Math.Max(dimension.FirstPoint.X, dimension.SecondPoint.X);
			return outline.Segments.Any(segment => segment != null
				&& segment.IsHorizontal(config.GeometryTolerance)
				&& Math.Abs(segment.MinY - dimension.FirstPoint.Y) <= config.GeometryTolerance
				&& segment.MinX <= minX + config.GeometryTolerance
				&& segment.MaxX >= maxX - config.GeometryTolerance);
		}

		private static OutlineFeature2D BuildProjectedHorizontalChainOutline(bool mirrored)
		{
			const double overallWidth = 438.7964881;
			const double firstBreak = 169.2090915;
			const double secondBreak = 304.0027898;
			const double maxY = 429.9099092;
			Func<double, double> x = value => mirrored ? overallWidth - value : value;
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = overallWidth, MaxY = maxY };
			AddSegment(outline, new Point2D(x(0.0), 0.0), new Point2D(x(0.0), 163.37), "left-lower");
			AddSegment(outline, new Point2D(x(0.0), 163.37), new Point2D(x(firstBreak), 163.37), "step-1");
			AddSegment(outline, new Point2D(x(firstBreak), 163.37), new Point2D(x(firstBreak), 289.48), "riser-1");
			AddSegment(outline, new Point2D(x(firstBreak), 289.48), new Point2D(x(secondBreak), 289.48), "step-2");
			AddSegment(outline, new Point2D(x(secondBreak), 289.48), new Point2D(x(secondBreak), maxY), "riser-2");
			AddSegment(outline, new Point2D(x(secondBreak), maxY), new Point2D(x(overallWidth), maxY), "top");
			AddSegment(outline, new Point2D(x(overallWidth), maxY), new Point2D(x(overallWidth), 0.0), "right");
			AddSegment(outline, new Point2D(x(overallWidth), 0.0), new Point2D(x(0.0), 0.0), "bottom");
			return outline;
		}

		private static OutlineFeature2D BuildTest2BottomContourOutline(bool mirrored)
		{
			const double overallWidth = 438.79648808;
			const double firstBreak = 134.79369829;
			const double secondBreak = 269.58739658;
			const double minY = -266.54414371;
			const double middleY = -126.10690670;
			const double upperY = 0.0;
			const double maxY = 163.36576550;
			Func<double, double> x = value => mirrored ? overallWidth - value : value;
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = minY,
				MaxX = overallWidth,
				MaxY = maxY
			};
			AddSegment(outline, new Point2D(x(0.0), maxY), new Point2D(x(0.0), minY), "left-outer");
			AddSegment(outline, new Point2D(x(0.0), minY), new Point2D(x(firstBreak), minY), "bottom-real-1");
			AddSegment(outline, new Point2D(x(firstBreak), minY), new Point2D(x(firstBreak), middleY), "riser-1");
			AddSegment(outline, new Point2D(x(firstBreak), middleY), new Point2D(x(secondBreak), middleY), "bottom-real-2");
			AddSegment(outline, new Point2D(x(secondBreak), middleY), new Point2D(x(secondBreak), upperY), "riser-2");
			AddSegment(outline, new Point2D(x(secondBreak), upperY), new Point2D(x(overallWidth), upperY), "bottom-real-3");
			AddSegment(outline, new Point2D(x(overallWidth), upperY), new Point2D(x(overallWidth), maxY), "right-outer");
			AddSegment(outline, new Point2D(x(overallWidth), maxY), new Point2D(x(0.0), maxY), "top");
			return outline;
		}

		private static OutlineFeature2D BuildProjectedVerticalChainOutline()
		{
			const double overallWidth = 438.7964881;
			const double overallHeight = 429.9099092;
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = overallWidth, MaxY = overallHeight };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 163.3658), "left-lower");
			AddSegment(outline, new Point2D(0.0, 163.3658), new Point2D(126.1069, 163.3658), "step-1");
			AddSegment(outline, new Point2D(126.1069, 163.3658), new Point2D(126.1069, 289.4727), "left-middle");
			AddSegment(outline, new Point2D(126.1069, 289.4727), new Point2D(266.5441, 289.4727), "step-2");
			AddSegment(outline, new Point2D(266.5441, 289.4727), new Point2D(266.5441, overallHeight), "left-upper");
			AddSegment(outline, new Point2D(266.5441, overallHeight), new Point2D(overallWidth, overallHeight), "top");
			AddSegment(outline, new Point2D(overallWidth, overallHeight), new Point2D(overallWidth, 0.0), "right");
			AddSegment(outline, new Point2D(overallWidth, 0.0), new Point2D(0.0, 0.0), "bottom");
			return outline;
		}

		private static void DatumRootedLeftOuterEnvelopeDimensionsAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 36.0,
				MaxY = 35.5
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(36.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(36.0, 0.0), new Point2D(36.0, 35.5), "right");
			AddSegment(outline, new Point2D(36.0, 35.5), new Point2D(18.0, 35.5), "tower-top");
			AddSegment(outline, new Point2D(18.0, 35.5), new Point2D(18.0, 20.0), "tower-riser");
			AddSegment(outline, new Point2D(18.0, 20.0), new Point2D(0.0, 20.0), "left-step");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(0.0, 10.0), "left-upper");
			AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(0.0, 0.0), "left-lower");
			AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(36.0, 10.0), "internal-full-width");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(GetSpan(d) - 36.0) <= config.GeometryTolerance),
				"overall width 36 must remain");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight
					&& Math.Abs(GetSpan(d) - 35.5) <= config.GeometryTolerance),
				"overall height 35.5 must remain");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "TopStructWidth"
					&& Math.Abs(GetSpan(d) - 18.0) <= config.GeometryTolerance),
				"top tower width 18 on partial MaxY must be kept");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "LeftStructHeight"
					&& Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance)
				|| plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "LeftStructHeight"
					&& Math.Abs(c.Value - 20.0) <= config.GeometryTolerance
					&& c.SuppressedReason != "LocalGeometryOnOverallEnvelope"),
				"left step height 20 must not be removed solely as full-envelope local geometry");
			Assert(!plan.Dimensions.Any(d => d.Kind == DimensionKind.Normal
					&& d.Orientation == DimensionOrientation.Vertical
					&& (Math.Abs(GetSpan(d) - 10.0) <= config.GeometryTolerance
						|| Math.Abs(GetSpan(d) - 15.5) <= config.GeometryTolerance)),
				"internal 10 and complementary 15.5 must not remain");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "OutlineSegment"
					&& Math.Abs(c.Value - 15.5) <= config.GeometryTolerance
					&& c.SuppressedReason == "ComplementaryOutlineRemainder"),
				"complementary 15.5 must record ComplementaryOutlineRemainder");
		}

		private static void DatumRootedBottomAndLeftOuterEnvelopeDimensionsAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 96.0,
				MaxY = 36.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(25.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(96.0, 16.0), new Point2D(96.0, 36.0), "right");
			AddSegment(outline, new Point2D(96.0, 36.0), new Point2D(0.0, 36.0), "top");
			AddSegment(outline, new Point2D(0.0, 36.0), new Point2D(0.0, 18.0), "left-upper");
			AddSegment(outline, new Point2D(0.0, 18.0), new Point2D(0.0, 0.0), "left-lower");
			AddSegment(outline, new Point2D(0.0, 18.0), new Point2D(25.0, 18.0), "left-ledge");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(25.0, 18.0), "left-riser");
			AddSegment(outline, new Point2D(25.0, 18.0), new Point2D(28.0, 16.0), "transition");
			AddSegment(outline, new Point2D(28.0, 16.0), new Point2D(96.0, 16.0), "arm-top");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& d.Side == DimensionSide.Bottom
					&& Math.Abs(GetSpan(d) - 96.0) <= config.GeometryTolerance),
				"bottom overall width 96 must remain");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "TopStructWidth"
					&& Math.Abs(c.Value - 96.0) <= config.GeometryTolerance
					&& c.SuppressedReason == "LocalGeometryOnOverallEnvelope"),
				"full-span top-envelope structure width 96 must be suppressed");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight
					&& Math.Abs(GetSpan(d) - 36.0) <= config.GeometryTolerance),
				"overall height 36 must remain");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "BottomStructWidth"
					&& Math.Abs(GetSpan(d) - 25.0) <= config.GeometryTolerance),
				"bottom step width 25 on partial MinY must be kept");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "LeftStructHeight"
					&& Math.Abs(GetSpan(d) - 18.0) <= config.GeometryTolerance)
				|| plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "LeftStructHeight"
					&& Math.Abs(c.Value - 18.0) <= config.GeometryTolerance
					&& c.SuppressedReason != "LocalGeometryOnOverallEnvelope"),
				"left step height 18 must not be removed solely as full-envelope local geometry");
			Assert(!plan.Dimensions.Any(d => d.Kind == DimensionKind.Normal
					&& d.Orientation == DimensionOrientation.Horizontal
					&& (Math.Abs(GetSpan(d) - 3.0) <= config.GeometryTolerance
						|| Math.Abs(GetSpan(d) - 68.0) <= config.GeometryTolerance)),
				"projected transition 3 and residual arm 68 must not remain");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "OutlineSegment"
					&& Math.Abs(c.Value - 68.0) <= config.GeometryTolerance
					&& c.SuppressedReason == "StructureDuplicateOfEnvelopeOutlineSegment"),
				"inner top arm residual 68 must record the envelope-duplicate reason");
			Assert(plan.Dimensions.Any(d => Math.Abs(GetSpan(d) - 25.0) <= config.GeometryTolerance
					&& (d.DebugRole == "BottomStructWidth" || d.DebugRole == "TopStructWidth")),
				"step width 25 on a partial envelope edge must remain available");
		}

		private static void DatumRootedBottomEnvelopeStepAndArcResidualAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 96.0,
				MaxY = 36.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(25.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(25.0, 0.0), new Point2D(25.0, 18.0), "root-riser");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(28.0, 16.0),
				End = new Point2D(25.0, 13.0),
				Center = new Point2D(28.0, 13.0),
				Radius = 3.0,
				Bulge = Math.Tan(Math.PI / 8.0),
				SourceKey = "R3"
			});
			AddSegment(outline, new Point2D(28.0, 16.0), new Point2D(96.0, 16.0), "arm-top");
			AddSegment(outline, new Point2D(96.0, 16.0), new Point2D(96.0, 36.0), "right");
			AddSegment(outline, new Point2D(96.0, 36.0), new Point2D(0.0, 36.0), "top");
			AddSegment(outline, new Point2D(0.0, 36.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.DebugRole == "BottomStructWidth"
					&& Math.Abs(GetSpan(d) - 25.0) <= config.GeometryTolerance),
				"datum-rooted bottom step width 25 on partial MinY must be kept");
			Assert(!plan.Dimensions.Any(d => d.Orientation == DimensionOrientation.Horizontal
					&& Math.Abs(GetSpan(d) - 68.0) <= config.GeometryTolerance),
				"outer arm residual 68 connected by a small real arc must not remain");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.DebugRole == "OutlineSegment"
					&& Math.Abs(c.Value - 68.0) <= config.GeometryTolerance
					&& c.SuppressedReason == "StructureDuplicateOfEnvelopeOutlineSegment"),
				"arc-connected arm residual 68 must record the envelope-duplicate reason");
		}

		/// <summary>
		/// L profile regression: topology derives the two 25 dimensions, removes 22/15,
		/// and suppresses the redundant inner edge 52 under rotations and mirror.
		/// </summary>
		private static void OutlineTopologyCapturesActualBoundaryWalk()
		{
			var graph = new DimensionPlanner(DimensionRuleConfig.CreateDefault()).CreateOutlinePlan(CreateRectangle(145, 65)).Diagnostics.OutlineTopology;
			Assert(graph != null && graph.Status == "UniqueExteriorWalk" && graph.IsClosedWalk,
				"a non-L rectangle must still expose its actual boundary graph");
			Assert(graph.Nodes.Count == 4 && graph.Edges.Count == 4 && graph.BoundaryPath.Count == 4,
				"the snapshot must retain every actual rectangle edge and node");
			Assert(graph.Edges.All(e => e.IsBoundary) && !graph.HasRepeatedBoundaryEdges,
				"rectangle traversal must not repeat an edge or substitute a hull");
			for (int i = 0; i < graph.BoundaryPath.Count; i++)
			{
				var step = graph.BoundaryPath[i];
				Assert(step.Order == i + 1 && step.ToNode == graph.BoundaryPath[(i + 1) % graph.BoundaryPath.Count].FromNode,
					"boundary order must be the connected traversal order");
			}
		}

		private static void OutlineTopologyDoesNotCloseGaps()
		{
			var outline = CreateRectangle(145, 65);
			outline.Segments.RemoveAt(3);
			var graph = new DimensionPlanner(DimensionRuleConfig.CreateDefault()).CreateOutlinePlan(outline).Diagnostics.OutlineTopology;
			Assert(graph != null && graph.Status == "Unavailable" && graph.Reason == "NoExteriorFace",
				"an open outline must explain the missing exterior face");
			Assert(graph.Edges.Count == 3 && graph.Nodes.Count(n => n.Kind == "Dangling") == 2
				&& graph.BoundaryPath.Count == 0 && !graph.IsClosedWalk,
				"open geometry must remain visible without an invented closing edge");
			Assert(OutlineTopologyExporter.ToSvg(graph, "open-test").Contains("NoExteriorFace"),
				"failed recognition must still produce a viewable diagnostic");
		}

		private static void OutlineTopologyReportsAmbiguousComponents()
		{
			var outline = CreateRectangle(20, 10);
			foreach (var segment in CreateRectangleAt(40, 0, 20, 10).Segments) { outline.Segments.Add(segment); }
			outline.MaxX = 60;
			var graph = new DimensionPlanner(DimensionRuleConfig.CreateDefault()).CreateOutlinePlan(outline).Diagnostics.OutlineTopology;
			Assert(graph.Status == "Ambiguous" && graph.Reason == "MultipleExteriorFaces" && graph.ExteriorFaceCount == 2,
				"disjoint loops must not silently become one contour");
			Assert(graph.Edges.Count == 8 && graph.BoundaryPath.Count == 0,
				"ambiguous geometry must be shown without selecting a guessed exterior path");
		}

		private static void OutlineTopologyExportsArcsAndEscapesText()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateLProfileAnnotationFixture();
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			var graph = new DimensionPlanner(config).CreateOutlinePlan(outline).Diagnostics.OutlineTopology;
			Assert(graph.Edges.Any(e => e.Kind == "Arc" && e.Radius > 0 && e.Bulge != 0),
				"the actual snapshot must preserve circular geometry, not replace it by chords");
			graph.Edges[0].SourceKey = "edge\"\\\n<&";
			string json = OutlineTopologyExporter.ToJson(graph);
			Assert(json.Contains("edge\\\"\\\\\\u000a<&") && json.Contains("\"boundaryPath\""),
				"JSON must escape control characters and include the ordered path");
			string svg = OutlineTopologyExporter.ToSvg(graph, "run<&");
			Assert(svg.Contains(" A ") && svg.Contains("run&lt;&amp;") && svg.Contains("edge&quot;"),
				"SVG must render true arcs and escape embedded source text");
			Assert(svg.Contains("intersections are NOT split"), "the view must expose the endpoint-only limitation");
		}

		private static PlannedDimension CreateCoverageTestDimension(string source, double span = 20.0)
		{
			return new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Role = DimensionCandidateRole.Structure,
				OwnerKind = DimensionCandidateOwnerKind.Outline,
				Orientation = DimensionOrientation.Horizontal,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(span, 0.0),
				SourceKey = source,
				SourceGeometryIds = new List<string> { "real-edge-a" }
			};
		}

		private static void StructureCoverageEligibilityIgnoresSourceLabels()
		{
			foreach (string source in new[] { "StepRiser:edge-a", "OtherGenerator:edge-a", "", null })
			{
				Assert(StructureCoveragePolicy.GetIneligibilityReason(CreateCoverageTestDimension(source)) == null,
					"typed outline structure eligibility must not depend on source labels");
			}
			var unsupported = CreateCoverageTestDimension("StepRiser:edge-a");
			unsupported.SourceGeometryIds.Clear();
			Assert(StructureCoveragePolicy.GetIneligibilityReason(unsupported) == "MissingSourceGeometry",
				"a familiar source prefix alone is not real geometry evidence");
		}

		private static void StructureCoverageProtectsIndependentRequirements()
		{
			var candidate = CreateCoverageTestDimension("StepRiser:edge-a");
			candidate.OverrideText = "<> ±0.02";
			Assert(StructureCoveragePolicy.GetIneligibilityReason(candidate) == "IndependentAnnotationRequirement",
				"coverage must not discard explicit tolerance text");
			candidate.OverrideText = null;
			candidate.ForceOuterLevel = true;
			Assert(StructureCoveragePolicy.GetIneligibilityReason(candidate) == "IndependentAnnotationRequirement",
				"forced rule-significant dimensions need independent review");
			candidate.ForceOuterLevel = false;
			candidate.OwnerKind = DimensionCandidateOwnerKind.PinGroup;
			Assert(StructureCoveragePolicy.GetIneligibilityReason(candidate) == "ProtectedSemanticIdentity",
				"outline coverage must not consume a pin-group candidate even at the same value");
			candidate.OwnerKind = DimensionCandidateOwnerKind.Outline;
			candidate.RuleId = "OtherRule.DefinesFeature";
			Assert(StructureCoveragePolicy.GetIneligibilityReason(candidate) == "ExistingRuleRequiresReview",
				"coverage must not overwrite an existing rule identity");
			candidate.RuleId = null;
			candidate.AttachmentValidity = false;
			Assert(StructureCoveragePolicy.GetIneligibilityReason(candidate) == "InvalidAttachment",
				"invalid attachments cannot support coverage eligibility");
			candidate.AttachmentValidity = null;
			candidate.Role = DimensionCandidateRole.Hole;
			Assert(StructureCoveragePolicy.GetIneligibilityReason(candidate) == "ProtectedSemanticIdentity",
				"outline coverage must not consume functional-hole dimensions");
		}

		private static void StructureCoverageRequiresLiveProvidersAndEvidence()
		{
			var plan = new DimensionPlan();
			var residual = CreateCoverageTestDimension("OtherGenerator:residual");
			var sameValue = CreateCoverageTestDimension("OtherFeature:legal", 20.0);
			var width = CreateCoverageTestDimension("ArmWidth", 25.0);
			var height = CreateCoverageTestDimension("ArmHeight", 25.0);
			height.Orientation = DimensionOrientation.Vertical;
			height.SecondPoint = new Point2D(0.0, 25.0);
			plan.Add(residual);
			plan.Add(sameValue);
			plan.Add(width);
			plan.Add(height);
			Assert(!plan.TrySuppressCoveredStructure(residual, "Test.Coverage", new[] { width },
				new[] { "real-edge-a" }, null), "missing topology proof must not suppress a residual");
			Assert(!plan.TrySuppressCoveredStructure(residual, "Test.Coverage", new PlannedDimension[0],
				new[] { "real-edge-a" }, "TopologyClosed=True"), "missing providers must not suppress a residual");
			Assert(!plan.TrySuppressCoveredStructure(residual, "Test.Coverage", new[] { residual },
				new[] { "real-edge-a" }, "TopologyClosed=True"), "a candidate cannot cover itself");
			Assert(!plan.TrySuppressCoveredStructure(residual, "Test.Coverage",
				new[] { CreateCoverageTestDimension("AbsentProvider", 25.0) },
				new[] { "real-edge-a" }, "TopologyClosed=True"), "a provider outside the plan cannot justify suppression");
			Assert(plan.Dimensions.Contains(residual), "unproven candidates must be retained");
			Assert(plan.TrySuppressCoveredStructure(residual, "Test.Coverage", new[] { width },
				new[] { "real-edge-a" }, "TopologyClosed=True"), "checked proof and a live provider permit suppression");
			plan.CaptureFinalDimensions();
			Assert(plan.Dimensions.Contains(sameValue) && plan.Dimensions.Contains(width) && plan.Dimensions.Contains(height),
				"suppression must preserve a same-valued unrelated feature and two distinct 25 dimensions");
			var diagnostic = plan.Diagnostics.DimensionCandidates.Single(d => d.Id == residual.DiagnosticId);
			Assert(diagnostic.IsSuppressed && diagnostic.TopologyEvidence.Contains("CoveredByIds=" + width.DiagnosticId),
				"the suppressed candidate must identify its actual information provider");
			Assert(!plan.Diagnostics.Warnings.Any(w => w.StartsWith("StructureCoverage.Incomplete|", StringComparison.Ordinal)),
				"live coverage dependencies must remain complete");
		}

		private static void StructureCoverageTracksMissingProviders()
		{
			var plan = new DimensionPlan();
			var residual = CreateCoverageTestDimension("Residual", 15.0);
			var provider = CreateCoverageTestDimension("Total", 25.0);
			plan.Add(residual);
			plan.Add(provider);
			Assert(plan.TrySuppressCoveredStructure(residual, "Test.Coverage", new[] { provider },
				new[] { "real-edge-a" }, "TopologyClosed=True"), "coverage setup must succeed");
			plan.Dimensions.Remove(provider);
			plan.CaptureFinalDimensions();
			string warning = plan.Diagnostics.Warnings.Single(w => w.StartsWith("StructureCoverage.Incomplete|", StringComparison.Ordinal));
			Assert(warning.Contains("Status=PendingConfirmation")
				&& warning.Contains("MissingCoveredByIds=" + provider.DiagnosticId),
				"later removal of a provider must expose the completeness gap");
			Assert(plan.Diagnostics.StructureCoverageStatus == "PendingConfirmation",
				"unresolved coverage must be exposed as a machine-readable non-pass status");
			Assert(!plan.Dimensions.Contains(residual), "completeness validation must not invent replacement dimensions");
			plan.CaptureFinalDimensions();
			Assert(plan.Diagnostics.Warnings.Count(w => w.StartsWith("StructureCoverage.Incomplete|", StringComparison.Ordinal)) == 1,
				"repeat finalization must not duplicate completeness warnings");
		}

		private static void PinDatumFamilyKeepsOneSide()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(20, 65);
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new[] {
				CreateHole(10, 10, 8, HoleKind2D.Pin), CreateHole(10, 40, 8, HoleKind2D.Pin),
				CreateHole(10, 25, 6, HoleKind2D.Thread), CreateHole(10, 55, 6, HoleKind2D.Thread) });
			var datum = plan.Dimensions.Single(d => d.Kind == DimensionKind.DatumHoleLocationY);
			var pin = plan.Dimensions.Single(d => d.Kind == DimensionKind.PinDistance);
			Assert(datum.Side == DimensionSide.Right && pin.Side == datum.Side,
				"pin spacing must inherit its group's datum side rather than independently selecting the opposite side");
			Assert(!string.IsNullOrEmpty(datum.DatumFamilyKey) && datum.DatumFamilyKey == pin.DatumFamilyKey
				&& datum.AlignmentKey == pin.AlignmentKey, "first-group datum location and pin spacing must request the same rooted alignment chain");
			var functional = plan.Dimensions.Where(d => d.DebugRole == "FunctionalHole" && d.Orientation == DimensionOrientation.Vertical).ToList();
			Assert(functional.Count == 2 && functional.All(d => d.DatumFamilyKey == datum.DatumFamilyKey
				&& !string.IsNullOrEmpty(d.ParallelStackKey) && d.Side == datum.Side && d.PreservePreferredSide),
				"both functional dimensions must retain their shared datum side and independent parallel-stack ownership");
			Assert(!string.IsNullOrEmpty(pin.OverrideText), "family grouping must retain pin-spacing tolerance text");
		}

		private static void PinDatumSideIsInheritedOnAllFourSides()
		{
			var config = DimensionRuleConfig.CreateDefault();
			foreach (bool horizontal in new[] { false, true })
			{
				foreach (bool reverseDatum in new[] { false, true })
				{
					var outline = CreateRectangle(horizontal ? 65 : 20, horizontal ? 20 : 65);
					var datum = Datum2D.FromOutline(outline);
					if (reverseDatum) { if (horizontal) { datum.BaseY = outline.MaxY; } else { datum.BaseX = outline.MaxX; } }
					var holes = new[] {
						CreateHole(10, 10, 8, HoleKind2D.Pin),
						CreateHole(horizontal ? 40 : 10, horizontal ? 10 : 40, 8, HoleKind2D.Pin),
						CreateHole(horizontal ? 25 : 10, horizontal ? 10 : 25, 6, HoleKind2D.Thread),
						CreateHole(horizontal ? 55 : 10, horizontal ? 10 : 55, 6, HoleKind2D.Thread) };
					for (int i = 0; i < holes.Length; i++) { AddCenterlineCross(datum, holes[i].Center, "same-side:" + i); }
					var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);
					var expected = horizontal ? (reverseDatum ? DimensionSide.Bottom : DimensionSide.Top)
						: (reverseDatum ? DimensionSide.Left : DimensionSide.Right);
					var orientation = horizontal ? DimensionOrientation.Horizontal : DimensionOrientation.Vertical;
					var family = plan.Dimensions.Where(d => d.Orientation == orientation
						&& (d.Kind == DimensionKind.DatumHoleLocationX || d.Kind == DimensionKind.DatumHoleLocationY
							|| d.Kind == DimensionKind.PinDistance || d.DebugRole == "FunctionalHole")).ToList();
					Assert(family.Count == 4 && family.All(d => d.Side == expected && d.PreservePreferredSide),
						"one datum-side decision must govern all same-orientation members, expected=" + expected);
					Assert(family.All(d => d.AttachmentKind == "SelectedCenterlineEndpoint"), "side inheritance must happen before centerline-endpoint selection");
					double endpoint = reverseDatum ? 5 : 15;
					Assert(family.All(d => Math.Abs((horizontal ? d.SecondPoint.Y : d.SecondPoint.X) - endpoint) <= config.GeometryTolerance),
						"all target grips must use the inherited side's real centerline endpoint");
					var pin = family.Single(d => d.Kind == DimensionKind.PinDistance);
					Assert(Math.Abs(GetSpan(pin) - 30) <= config.GeometryTolerance && !string.IsNullOrEmpty(pin.OverrideText),
						"changing placement side must preserve pin pair, measured span and tolerance text");
					var items = CreatePinDatumAlignmentLayout(family);
					var placements = new DimensionLayoutRules(config).CreateStackingPlan(items, expected, outline, 3, 1.5, 10, 5.5, horizontal);
					var datumIndex = family.FindIndex(d => d.Kind == DimensionKind.DatumHoleLocationX || d.Kind == DimensionKind.DatumHoleLocationY);
					var pinIndex = family.IndexOf(pin);
					var datumPlacement = placements.Single(p => p.Index == datumIndex);
					var pinPlacement = placements.Single(p => p.Index == pinIndex);
					Assert(datumPlacement.LayoutBlockId == pinPlacement.LayoutBlockId && datumPlacement.AlignmentLaneMemberCount == 2
						&& datumPlacement.DimLineCoordinateOverride.HasValue && pinPlacement.DimLineCoordinateOverride.HasValue
						&& Math.Abs(datumPlacement.DimLineCoordinateOverride.Value - pinPlacement.DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
						"the real 10-to-30 chain must resolve to one dimension-line coordinate, not merely share a key, side=" + expected);
					Assert(placements.Where(p => family[p.Index].DebugRole == "FunctionalHole")
						.All(p => p.LayoutBlockId != datumPlacement.LayoutBlockId
							&& family[p.Index].AlignmentKey != pin.AlignmentKey),
						"15/45 functional dimensions must retain independent alignment lanes");
				}
			}
		}

		private static List<DimensionLayoutItem> CreatePinDatumAlignmentLayout(IEnumerable<PlannedDimension> dimensions)
		{
			return dimensions.Select(d => new DimensionLayoutItem { FirstPoint = d.FirstPoint, SecondPoint = d.SecondPoint,
				Kind = d.Kind, Span = GetSpan(d), SourceFeatureId = d.DebugOwner, AlignmentKey = d.AlignmentKey,
				DatumFamilyKey = d.DatumFamilyKey, ParallelStackKey = d.ParallelStackKey,
				AlignmentPriority = d.AlignmentPriority, PreserveAlignmentLevel = d.PreserveAlignmentLevel,
				ReadingLevel = d.ReadingLevel, OverrideText = d.OverrideText, PreferLocalBoundary = d.PreferLocalBoundary,
				ForceOuterLevel = d.ForceOuterLevel, PreferFeatureLocalPlacement = d.PreferFeatureLocalPlacement,
				PreservePreferredSide = d.PreservePreferredSide, LooseChainId = d.ChainId }).ToList();
		}

		private static void FirstPinDatumAlignmentRejectsOverlappingIntervals()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(20, 65);
			var datum = Datum2D.FromOutline(outline);
			datum.BaseY = 25;
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[] {
				CreateHole(10, 10, 8, HoleKind2D.Pin), CreateHole(10, 40, 8, HoleKind2D.Pin) });
			var pair = plan.Dimensions.Where(d => d.Kind == DimensionKind.DatumHoleLocationY || d.Kind == DimensionKind.PinDistance).ToList();
			Assert(pair.Count == 2 && pair[0].AlignmentKey == pair[1].AlignmentKey,
				"first-group dimensions may request one chain even when geometry later prevents alignment");
			var items = CreatePinDatumAlignmentLayout(pair);
			var rules = new DimensionLayoutRules(config);
			var placements = rules.CreateStackingPlan(items, DimensionSide.Right, outline, 3, 1.5, 10, 5.5, false);
			var a = placements[0]; var b = placements[1];
			double first = a.DimLineCoordinateOverride ?? rules.GetDimLineCoordinate(items[a.Index], DimensionSide.Right, outline, a.Offset);
			double second = b.DimLineCoordinateOverride ?? rules.GetDimLineCoordinate(items[b.Index], DimensionSide.Right, outline, b.Offset);
			Assert(a.LayoutBlockId != b.LayoutBlockId && Math.Abs(first - second) > config.GeometryTolerance,
				"nested [10,25] and [10,40] intervals must not be forced onto one line just because their keys match");
		}

		private static Datum2D CreateVerticalPreferenceDatum(OutlineFeature2D outline, HoleFeature2D[] holes,
			HoleFeature2D selected, PinGroupVerticalLayoutPreference preference)
		{
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = selected;
			datum.PinGroupVerticalLayout = preference;
			for (int i = 0; i < holes.Length; i++) { AddCenterlineCross(datum, holes[i].Center, "preference:" + i); }
			return datum;
		}

		private static void DatumPinVerticalPreferenceOnlyChangesSelectedGroup()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100, 100);
			var holes = new[] { CreateHole(10, 10, 6, HoleKind2D.Pin), CreateHole(10, 30, 6, HoleKind2D.Pin),
				CreateHole(90, 70, 6, HoleKind2D.Pin), CreateHole(90, 90, 6, HoleKind2D.Pin),
				CreateHole(10, 20, 8, HoleKind2D.Thread), CreateHole(90, 80, 8, HoleKind2D.Thread) };
			foreach (int selectedIndex in new[] { 0, 2 })
			{
				var selected = holes[selectedIndex];
				var automatic = new DimensionPlanner(config).CreateDimensionPlan(outline,
					CreateVerticalPreferenceDatum(outline, holes, selected, PinGroupVerticalLayoutPreference.Automatic), holes);
				foreach (var preference in new[] { PinGroupVerticalLayoutPreference.Left, PinGroupVerticalLayoutPreference.Right })
				{
					var plan = new DimensionPlanner(config).CreateDimensionPlan(outline,
						CreateVerticalPreferenceDatum(outline, holes, selected, preference), holes);
					Assert(plan.PinGroups.Count == 2, "side preference must not change pin grouping");
					foreach (var group in plan.PinGroups)
					{
						var original = automatic.PinGroups.Single(g => g.GroupIndex == group.GroupIndex);
						bool ownsSelected = group.Pins.Any(p => p.Center.Equals(selected.Center));
						var expected = ownsSelected ? (preference == PinGroupVerticalLayoutPreference.Left ? DimensionSide.Left : DimensionSide.Right)
							: original.VerticalSide;
						Assert(group.VerticalSide == expected && group.HorizontalSide == original.HorizontalSide,
							"A/D affects only selected-pin group vertical placement, not other groups or horizontal decisions");
						var vertical = plan.Dimensions.Where(d => d.DebugOwner == "PG" + group.GroupIndex
							&& d.Orientation == DimensionOrientation.Vertical).ToList();
						Assert(vertical.Any(d => d.Kind == DimensionKind.PinDistance) && vertical.All(d => d.Side == expected && d.PreservePreferredSide),
							"all owned vertical dimensions, including functional holes/transfers, must follow their own group's decision");
						if (ownsSelected)
						{
							Assert(vertical.Any(d => d.DebugRole == "FunctionalHole"), "fixture must exercise functional-hole inheritance");
							double endpointX = selected.Center.X + (expected == DimensionSide.Left ? -5 : 5);
							Assert(vertical.All(d => d.AttachmentKind == "SelectedCenterlineEndpoint"
								&& Math.Abs(d.SecondPoint.X - endpointX) <= config.GeometryTolerance),
								"endpoint selection must use the requested side, not retain automatic-side grips");
						}
						var pin = vertical.Single(d => d.Kind == DimensionKind.PinDistance);
						var originalPin = automatic.Dimensions.Single(d => d.DebugOwner == pin.DebugOwner && d.Kind == DimensionKind.PinDistance);
						Assert(Math.Abs(GetSpan(pin) - GetSpan(originalPin)) <= config.GeometryTolerance && pin.OverrideText == originalPin.OverrideText,
							"side choice must preserve pin-pair span and tolerance");
					}
					var before = automatic.Dimensions.Where(d => d.Orientation == DimensionOrientation.Horizontal).ToList();
					var after = plan.Dimensions.Where(d => d.Orientation == DimensionOrientation.Horizontal).ToList();
					Assert(before.Count == after.Count && before.Zip(after, (a, b) => a.Side == b.Side
						&& a.FirstPoint.Equals(b.FirstPoint) && a.SecondPoint.Equals(b.SecondPoint)).All(equal => equal),
						"vertical preference must not move horizontal dimensions or their attachments");
				}
			}
		}

		private static void DatumPinVerticalPreferenceDefaultsToAutomatic()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(20, 65);
			var holes = new[] { CreateHole(10, 10, 8, HoleKind2D.Pin), CreateHole(10, 40, 8, HoleKind2D.Pin) };
			var forced = CreateVerticalPreferenceDatum(outline, holes, holes[0], PinGroupVerticalLayoutPreference.Left);
			new DimensionPlanner(config).CreateDimensionPlan(outline, forced, holes);
			var fresh = Datum2D.FromOutline(outline);
			fresh.DatumHole = holes[0];
			Assert(fresh.PinGroupVerticalLayout == PinGroupVerticalLayoutPreference.Automatic
				&& fresh.PinGroupHorizontalLayout == PinGroupHorizontalLayoutPreference.Automatic,
				"new runs must never inherit the preceding A/D/W/S choice");
			var automatic = new DimensionPlanner(config).CreateDimensionPlan(outline, fresh, holes);
			Assert(automatic.PinGroups.Single().VerticalSide == DimensionSide.Right, "empty input must retain the existing automatic centered-hole rule");
			fresh.DatumHole = null;
			fresh.PinGroupVerticalLayout = PinGroupVerticalLayoutPreference.Left;
			var unowned = new DimensionPlanner(config).CreateDimensionPlan(outline, fresh, holes);
			Assert(unowned.PinGroups.Single().VerticalSide == DimensionSide.Right
				&& unowned.Diagnostics.Warnings.Any(w => w.StartsWith("PinGroup.VerticalLayoutPreference.NotApplied|", StringComparison.Ordinal)),
				"an unscoped preference must not silently target the first or every group");
		}

		private static void DatumPinVerticalPreferenceSurvivesFrameTransform()
		{
			var datum = new Datum2D { BaseX = 100, BaseY = 200, DatumHole = CreateHole(110, 210, 6, HoleKind2D.Pin),
				PinGroupVerticalLayout = PinGroupVerticalLayoutPreference.Left, PinGroupHorizontalLayout = PinGroupHorizontalLayoutPreference.Bottom };
			var frame = new CoordinateFrame2D(new Point2D(100, 200), new Point2D(0, 1));
			var local = CoordinateFrameModelTransform.ToLocal(datum, frame);
			Assert(local.PinGroupVerticalLayout == PinGroupVerticalLayoutPreference.Left
				&& local.PinGroupHorizontalLayout == PinGroupHorizontalLayoutPreference.Bottom && local.DatumHole != null
				&& local.DatumHole.Center.Equals(frame.ToLocal(datum.DatumHole.Center)),
				"frame conversion must retain the preference and the selected pin identity together");
		}

		private static void DatumPinHorizontalPreferenceOnlyChangesSelectedGroup()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100, 100);
			var holes = new[] { CreateHole(10, 10, 6, HoleKind2D.Pin), CreateHole(30, 10, 6, HoleKind2D.Pin),
				CreateHole(70, 90, 6, HoleKind2D.Pin), CreateHole(90, 90, 6, HoleKind2D.Pin),
				CreateHole(20, 10, 8, HoleKind2D.Thread), CreateHole(80, 90, 8, HoleKind2D.Thread) };
			foreach (int selectedIndex in new[] { 0, 2 })
			{
				var selected = holes[selectedIndex];
				var automatic = new DimensionPlanner(config).CreateDimensionPlan(outline,
					CreateVerticalPreferenceDatum(outline, holes, selected, PinGroupVerticalLayoutPreference.Automatic), holes);
				foreach (var preference in new[] { PinGroupHorizontalLayoutPreference.Top, PinGroupHorizontalLayoutPreference.Bottom })
				{
					var datum = CreateVerticalPreferenceDatum(outline, holes, selected, PinGroupVerticalLayoutPreference.Automatic);
					datum.PinGroupHorizontalLayout = preference;
					var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);
					Assert(plan.PinGroups.Count == 2, "W/S must not regroup pins");
					foreach (var group in plan.PinGroups)
					{
						var original = automatic.PinGroups.Single(g => g.GroupIndex == group.GroupIndex);
						bool ownsSelected = group.Pins.Any(p => p.Center.Equals(selected.Center));
						var expected = ownsSelected ? (preference == PinGroupHorizontalLayoutPreference.Top ? DimensionSide.Top : DimensionSide.Bottom)
							: original.HorizontalSide;
						Assert(group.HorizontalSide == expected && group.VerticalSide == original.VerticalSide,
							"W/S affects only selected group horizontal placement, not another group or vertical decisions");
						var horizontal = plan.Dimensions.Where(d => d.DebugOwner == "PG" + group.GroupIndex
							&& d.Orientation == DimensionOrientation.Horizontal).ToList();
						Assert(horizontal.Any(d => d.Kind == DimensionKind.PinDistance)
							&& horizontal.All(d => d.Side == expected && d.PreservePreferredSide), "horizontal dimensions must inherit their own group's side");
						if (ownsSelected)
						{
							Assert(horizontal.Any(d => d.DebugRole == "FunctionalHole"), "fixture must exercise functional-hole ownership");
							double endpointY = selected.Center.Y + (expected == DimensionSide.Top ? 5 : -5);
							Assert(horizontal.All(d => d.AttachmentKind == "SelectedCenterlineEndpoint"
								&& Math.Abs(d.SecondPoint.Y - endpointY) <= config.GeometryTolerance), "W/S must select existing endpoints on the requested side");
						}
						var pin = horizontal.Single(d => d.Kind == DimensionKind.PinDistance);
						var originalPin = automatic.Dimensions.Single(d => d.DebugOwner == pin.DebugOwner && d.Kind == DimensionKind.PinDistance);
						Assert(Math.Abs(GetSpan(pin) - GetSpan(originalPin)) <= config.GeometryTolerance && pin.OverrideText == originalPin.OverrideText,
							"W/S must preserve the real pin-pair span and tolerance");
					}
					var before = automatic.Dimensions.Where(d => d.Orientation == DimensionOrientation.Vertical).ToList();
					var after = plan.Dimensions.Where(d => d.Orientation == DimensionOrientation.Vertical).ToList();
					Assert(before.Count == after.Count && before.Zip(after, (a, b) => a.Side == b.Side
						&& a.FirstPoint.Equals(b.FirstPoint) && a.SecondPoint.Equals(b.SecondPoint)).All(equal => equal),
						"W/S must not move vertical dimension grips");
				}
			}
		}

		private static void DatumPinLayoutOrientationUsesSelectedGroup()
		{
			var planner = new DimensionPlanner(DimensionRuleConfig.CreateDefault());
			// Both axes exist in the selection; the wide outline alone must not decide the prompt.
			var outline = CreateRectangle(200, 100);
			var holes = new[] { CreateHole(10, 10, 6, HoleKind2D.Pin), CreateHole(30, 10, 6, HoleKind2D.Pin),
				CreateHole(150, 70, 6, HoleKind2D.Pin), CreateHole(150, 90, 6, HoleKind2D.Pin) };
			Assert(planner.GetSelectedPinGroupLayoutOrientation(outline, holes, holes[0]) == DimensionOrientation.Horizontal,
				"horizontal selected pin pair must offer W/S");
			Assert(planner.GetSelectedPinGroupLayoutOrientation(outline, holes, holes[2]) == DimensionOrientation.Vertical,
				"vertical selected pair must offer A/D even inside a wide outline");
			Assert(planner.GetSelectedPinGroupLayoutOrientation(outline, new[] { holes[0] }, holes[0]) == null
				&& planner.GetSelectedPinGroupLayoutOrientation(outline, holes, CreateHole(999, 999, 6, HoleKind2D.Pin)) == null,
				"singletons and unselected datum pins must not receive an invented axis");
			var oblique = new[] { CreateHole(10, 10, 6, HoleKind2D.Pin), CreateHole(30, 30, 6, HoleKind2D.Pin) };
			Assert(planner.GetSelectedPinGroupLayoutOrientation(outline, oblique, oblique[0]) == null,
				"two-axis pin pair must retain the explicit four-key fallback");
			double angle = Math.PI / 6;
			var rotatedOutline = RotateOutline(outline, angle);
			var rotatedHoles = holes.Select(h => { var p = RotatePoint(h.Center, angle); return CreateHole(p.X, p.Y, h.Diameter, HoleKind2D.Pin); }).ToArray();
			Assert(planner.GetSelectedPinGroupLayoutOrientation(rotatedOutline, rotatedHoles, rotatedHoles[0]) == DimensionOrientation.Horizontal,
				"prompt classification must follow the final planner's inferred frame");
		}

		private static void HorizontalPreferenceKeepsContinuousDatumChain()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(65, 20);
			var holes = new[] { CreateHole(55, 10, 8, HoleKind2D.Pin), CreateHole(25, 10, 8, HoleKind2D.Pin),
				CreateHole(40, 10, 6, HoleKind2D.Thread), CreateHole(10, 10, 6, HoleKind2D.Thread) };
			foreach (var preference in new[] { PinGroupHorizontalLayoutPreference.Top, PinGroupHorizontalLayoutPreference.Bottom })
			{
				var datum = CreateVerticalPreferenceDatum(outline, holes, holes[0], PinGroupVerticalLayoutPreference.Automatic);
				datum.DatumHoleLocationBaseX = 65;
				datum.DatumHoleLocationBaseY = 20;
				datum.PinGroupHorizontalLayout = preference;
				var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);
				var horizontal = plan.Dimensions.Where(d => d.DebugOwner == "PG1" && d.Orientation == DimensionOrientation.Horizontal).ToList();
				var location = horizontal.Single(d => d.Kind == DimensionKind.DatumHoleLocationX);
				var pin = horizontal.Single(d => d.Kind == DimensionKind.PinDistance);
				var side = preference == PinGroupHorizontalLayoutPreference.Top ? DimensionSide.Top : DimensionSide.Bottom;
				Assert(horizontal.All(d => d.Side == side) && Math.Abs(GetSpan(location) - 10) <= config.GeometryTolerance
					&& Math.Abs(GetSpan(pin) - 30) <= config.GeometryTolerance, "W/S must preserve the 10 + 30 horizontal chain");
				Assert(horizontal.Count(d => d.DebugRole == "FunctionalHole") == 2
					&& horizontal.Where(d => d.DebugRole == "FunctionalHole").All(d => d.AlignmentKey != location.AlignmentKey),
					"functional 15/45 must retain independent alignment lanes");
				var items = CreatePinDatumAlignmentLayout(horizontal);
				var placements = new DimensionLayoutRules(config).CreateStackingPlan(items, side, outline, 3, 1.5, 10, 5.5, false);
				var a = placements.Single(p => p.Index == horizontal.IndexOf(location));
				var b = placements.Single(p => p.Index == horizontal.IndexOf(pin));
				Assert(a.LayoutBlockId == b.LayoutBlockId && a.AlignmentLaneMemberCount == 2,
					"W/S should preserve the proven contiguous datum/pin alignment block");
			}
			var unownedDatum = Datum2D.FromOutline(outline);
			unownedDatum.PinGroupHorizontalLayout = PinGroupHorizontalLayoutPreference.Bottom;
			var unowned = new DimensionPlanner(config).CreateDimensionPlan(outline, unownedDatum, holes);
			Assert(unowned.PinGroups.Single().HorizontalSide == DimensionSide.Top
				&& unowned.Diagnostics.Warnings.Any(w => w.StartsWith("PinGroup.HorizontalLayoutPreference.NotApplied|", StringComparison.Ordinal)),
				"W/S without a selected datum pin must not silently target a group");
		}

		private static void SeparatePinGroupsKeepIndependentSides()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100, 100);
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new[] {
				CreateHole(10, 10, 6, HoleKind2D.Pin), CreateHole(10, 20, 6, HoleKind2D.Pin),
				CreateHole(90, 80, 6, HoleKind2D.Pin), CreateHole(90, 90, 6, HoleKind2D.Pin) });
			Assert(plan.PinGroups.Count == 2 && plan.PinGroups[0].VerticalSide == DimensionSide.Left
				&& plan.PinGroups[1].VerticalSide == DimensionSide.Right, "different groups must retain independently chosen datum sides");
			foreach (var group in plan.PinGroups)
			{
				var owned = plan.Dimensions.Where(d => d.DebugOwner == "PG" + group.GroupIndex
					&& d.Orientation == DimensionOrientation.Vertical && (d.Kind == DimensionKind.PinDistance || d.Kind == DimensionKind.PinGroupDistance)).ToList();
				Assert(owned.Any(d => d.Kind == DimensionKind.PinDistance) && owned.All(d => d.Side == group.VerticalSide && d.PreservePreferredSide),
					"pair and incoming transfer dimensions must follow their own group, not the first group's side");
			}
		}

		private static void ParallelDatumStacksKeepNestedDimensionsSeparated()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			foreach (bool horizontal in new[] { false, true })
			{
				foreach (bool negative in new[] { false, true })
				{
					var outline = CreateRectangle(horizontal ? 65 : 20, horizontal ? 20 : 65);
					var side = horizontal ? (negative ? DimensionSide.Bottom : DimensionSide.Top)
						: (negative ? DimensionSide.Left : DimensionSide.Right);
					var items = new List<DimensionLayoutItem>();
					foreach (double end in new[] { 10.0, 25.0, 55.0 })
					{
						double start = end == 10 ? 0 : 10;
						items.Add(new DimensionLayoutItem { FirstPoint = horizontal ? new Point2D(start, 10) : new Point2D(10, start),
							SecondPoint = horizontal ? new Point2D(end, 10) : new Point2D(10, end), Span = end - start,
							Kind = end == 10 ? (horizontal ? DimensionKind.DatumHoleLocationX : DimensionKind.DatumHoleLocationY) : DimensionKind.HoleLocation,
							AlignmentKey = end == 10 ? "datum" : "functional", AlignmentPriority = end == 10 ? 120 : 90,
							PreserveAlignmentLevel = end != 10, DatumFamilyKey = "real-base", ParallelStackKey = end == 10 ? null : "parallel",
							SourceFeatureId = "PG1", PreferLocalBoundary = end != 10 });
					}
					var compact = rules.CreateStackingPlan(items, side, outline, 3, 1.5, 10, 5.5, horizontal);
					foreach (var item in items) { item.ParallelStackKey = null; }
					var legacy = rules.CreateStackingPlan(items, side, outline, 3, 1.5, 10, 5.5, horizontal);
					var small = compact.Single(p => p.Index == 1); var large = compact.Single(p => p.Index == 2);
					Assert(large.PhysicalOutwardDistance - small.PhysicalOutwardDistance >= 5.5 - config.GeometryTolerance,
						"nested spans sharing a base must remain separated by physical spacing on every side");
					Assert(large.PhysicalOutwardDistance <= legacy.Single(p => p.Index == 2).PhysicalOutwardDistance + config.GeometryTolerance,
						"safe compaction must never move the family farther outward");
					Assert(compact.All(p => p.PhysicalOrderValidated), "compaction must preserve the existing physical ordering constraints");
				}
			}
		}

		private static Point2D MapExtensionFixture(Point2D point, DimensionSide side)
		{
			if (side == DimensionSide.Left) { return new Point2D(-point.X, point.Y); }
			if (side == DimensionSide.Top) { return new Point2D(point.Y, point.X); }
			if (side == DimensionSide.Bottom) { return new Point2D(point.Y, -point.X); }
			return point;
		}

		private static void ContinuousExtensionPolicyNeverBreaksOrDeduplicates()
		{
			foreach (var side in new[] { DimensionSide.Right, DimensionSide.Left, DimensionSide.Top, DimensionSide.Bottom })
			{
				var items = new[] {
					new ExtensionLineLayoutItem { DiagnosticId = 1, Side = side, Enabled = true, DatumFamilyKey = "base",
						FirstPoint = new Point2D(0, 0), SecondPoint = new Point2D(0, 15), DimLineCoordinate = 10,
						TextBounds = new TextBounds2D { MinX = 3, MaxX = 5, MinY = -1, MaxY = 20 } },
					new ExtensionLineLayoutItem { DiagnosticId = 2, Side = side, Enabled = true, DatumFamilyKey = "base",
						FirstPoint = new Point2D(0, 0), SecondPoint = new Point2D(0, 45), DimLineCoordinate = 20,
						NativeFirstSuppressed = true } };
				var result = DimensionExtensionLineRules.CreateContinuous(items);
				Assert(result.Count == items.Length && result.All(p => !p.SuppressFirst && !p.SuppressSecond
					&& p.FirstSegments.Count == 0 && p.SecondSegments.Count == 0),
					"production continuous policy must ignore old segmentation flags, overlaps and common-baseline deduplication");
				Assert(result.All(p => p.Decision == "NativeContinuous_NoAutomaticBreaks|PendingCadVerification")
					&& items[1].NativeFirstSuppressed, "native style suppression must remain untouched, with no claim of CAD verification");
			}
		}

		private static void ExtensionGeometrySegmentsAllFourSides()
		{
			foreach (var side in new[] { DimensionSide.Right, DimensionSide.Left, DimensionSide.Top, DimensionSide.Bottom })
			{
				Func<Point2D, Point2D> map = p => MapExtensionFixture(p, side);
				var box = new[] { map(new Point2D(3, -1)), map(new Point2D(5, -1)), map(new Point2D(3, 1)), map(new Point2D(5, 1)) };
				double sign = side == DimensionSide.Left || side == DimensionSide.Bottom ? -1 : 1;
				var source = new ExtensionLineLayoutItem { DiagnosticId = 1, Side = side, Enabled = true,
					FirstPoint = map(new Point2D(0, 0)), SecondPoint = map(new Point2D(0, 5)), DimLineCoordinate = sign * 10 };
				var obstacle = new ExtensionLineLayoutItem { DiagnosticId = 2, Side = side, Enabled = false,
					FirstPoint = map(new Point2D(0, 50)), SecondPoint = map(new Point2D(0, 55)), DimLineCoordinate = sign * 20,
					TextBounds = new TextBounds2D { MinX = box.Min(p => p.X), MaxX = box.Max(p => p.X), MinY = box.Min(p => p.Y), MaxY = box.Max(p => p.Y) } };
				var edge = new Segment2D(map(new Point2D(7, -2)), map(new Point2D(7, 2)));
				var plan = DimensionExtensionLineRules.Create(new[] { source, obstacle }, new[] { edge }, 1, 1, 0.5, 0.001)[0];
				Assert(plan.SuppressFirst && !plan.SuppressSecond && plan.FirstSegments.Count == 3,
					"only the affected native extension is replaced, with text/outline gaps, side=" + side);
				Assert(plan.FirstSegments.All(s => s.Start.DistanceTo(s.End) > 0.001), "segmentation must not emit zero-length lines");
				Assert(source.FirstPoint.DistanceTo(map(new Point2D(0, 0))) < 0.001
					&& source.SecondPoint.DistanceTo(map(new Point2D(0, 5))) < 0.001, "extension planning must never move real definition points");
				Assert(plan.Decision.Contains("PendingCadVerification"), "a geometry plan must not claim CAD rendering passed");
			}
		}

		private static void ExtensionSharingRequiresFamilyAndRealPoint()
		{
			var first = new ExtensionLineLayoutItem { DiagnosticId = 1, Side = DimensionSide.Right, Enabled = true,
				DatumFamilyKey = "base", FirstPoint = new Point2D(0, 0), SecondPoint = new Point2D(0, 5), DimLineCoordinate = 10 };
			var second = new ExtensionLineLayoutItem { DiagnosticId = 2, Side = DimensionSide.Right, Enabled = true,
				DatumFamilyKey = "base", FirstPoint = new Point2D(0, 0), SecondPoint = new Point2D(0, 8), DimLineCoordinate = 20 };
			var plan = DimensionExtensionLineRules.Create(new[] { first, second }, null, 1, 1, 0.5, 0.001);
			Assert(plan[0].SuppressFirst && plan[0].FirstSegments.Count == 0 && !plan[1].SuppressFirst
				&& plan[0].Decision.Contains("SharedExtensionOwnedBy:2"), "the longest proven common baseline owns the extension");
			second.DatumFamilyKey = "unrelated";
			plan = DimensionExtensionLineRules.Create(new[] { first, second }, null, 1, 1, 0.5, 0.001);
			Assert(plan.All(p => !p.Decision.Contains("SharedExtensionOwnedBy")), "coincident coordinates alone cannot prove a shared extension");
			second.DatumFamilyKey = "base";
			second.FirstPoint = new Point2D(2, 0);
			plan = DimensionExtensionLineRules.Create(new[] { first, second }, null, 1, 1, 0.5, 0.001);
			Assert(plan.All(p => !p.Decision.Contains("SharedExtensionOwnedBy")), "a family label alone cannot replace proof of the same real point");
			first.NativeFirstSuppressed = true;
			plan = DimensionExtensionLineRules.Create(new[] { first }, null, 1, 1, 0.5, 0.001);
			Assert(!plan[0].SuppressFirst && plan[0].FirstSegments.Count == 0, "native style suppression must not cause a replacement line to be created");
			first.NativeFirstSuppressed = false;
			plan = DimensionExtensionLineRules.Create(new[] { first }, new[] {
				new Segment2D(new Point2D(10, -1), new Point2D(10, 1)) }, 1, 1, 0.5, 0.001);
			Assert(!plan[0].SuppressFirst && plan[0].Decision.Contains("UnresolvedExtensionConflict"),
				"a cut that would disconnect the dimension's own arrow must retain native geometry and remain pending");
		}

		private static void SingletonAlignmentIsNotProof()
		{
			var plan = new DimensionPlan();
			var dimension = new PlannedDimension { Kind = DimensionKind.HoleLocation, Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right, FirstPoint = new Point2D(0, 0), SecondPoint = new Point2D(0, 15),
				DatumFamilyKey = "base", ParallelStackKey = "parallel", AlignmentKey = "lane" };
			plan.Add(dimension);
			plan.CaptureFinalDimensions();
			plan.Diagnostics.RecordFinalPlacement(dimension.DiagnosticId, "Right", 0, 10, 30, false, true, "lane#1", 1,
				"AlignedRootedLayoutBlock", "block", "RootedAlignmentLane", 15, 0, "", "", 10, true);
			plan.Diagnostics.ValidateDatumFamilyLayout(5.5, 0.001);
			var diagnostic = plan.Diagnostics.FinalDimensions.Single();
			Assert(diagnostic.AlignmentDecision == "SingleMemberNoAlignmentProof" && diagnostic.FamilySpacingValid == null,
				"singleton alignment and missing spacing comparisons must not be reported as passed");
			Assert(diagnostic.ExtensionLineDecision == "Unknown", "unrendered extension geometry must remain unknown");
			var nested = new PlannedDimension { Kind = DimensionKind.HoleLocation, Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right, FirstPoint = new Point2D(0, 0), SecondPoint = new Point2D(0, 45), DatumFamilyKey = "base" };
			plan.Add(nested);
			plan.CaptureFinalDimensions();
			plan.Diagnostics.ValidateDatumFamilyLayout(5.5, 0.001);
			Assert(plan.Diagnostics.FinalDimensions.All(d => d.FamilySpacingValid == null && d.DatumFamilySideDecision == "PendingPlacement"),
				"a partly unplaced family cannot pass a group check");
			plan.Diagnostics.RecordFinalPlacement(nested.DiagnosticId, "Right", 0, 10, 30, false, false, "", 0,
				"NotRequested", "other", "SingleDimension", 45, 1, "", "", 10, true);
			plan.Diagnostics.ValidateDatumFamilyLayout(5.5, 0.001);
			Assert(plan.Diagnostics.FinalDimensions.All(d => d.FamilySpacingValid == false),
				"physical-order success alone must not conceal overlapping nested family dimensions");
		}

		// Normalized outline from OP20-1-4: the 18-wide frame is internal to the 20 x 65 boundary.
		private static OutlineFeature2D CreateInternalTopFrameFixture()
		{
			var o = new OutlineFeature2D { MinX = 0, MinY = 0, MaxX = 20, MaxY = 65 };
			AddSegment(o, new Point2D(0, 0), new Point2D(20, 0), "outer-bottom");
			AddSegment(o, new Point2D(20, 0), new Point2D(20, 30), "outer-right-low");
			AddSegment(o, new Point2D(20, 30), new Point2D(20, 45), "outer-right-mid");
			AddSegment(o, new Point2D(20, 45), new Point2D(20, 65), "outer-right-high");
			AddSegment(o, new Point2D(20, 65), new Point2D(0, 65), "outer-top");
			AddSegment(o, new Point2D(0, 65), new Point2D(0, 45), "outer-left-high");
			AddSegment(o, new Point2D(0, 45), new Point2D(0, 30), "outer-left-mid");
			AddSegment(o, new Point2D(0, 30), new Point2D(0, 0), "outer-left-low");
			AddSegment(o, new Point2D(1, 64), new Point2D(19, 64), "inner-top18");
			AddSegment(o, new Point2D(19, 64), new Point2D(19, 46), "inner-right");
			AddSegment(o, new Point2D(19, 46), new Point2D(1, 46), "inner-bottom");
			AddSegment(o, new Point2D(1, 46), new Point2D(1, 64), "inner-left");
			AddSegment(o, new Point2D(0, 65), new Point2D(1, 64), "inner-cut-tl");
			AddSegment(o, new Point2D(20, 65), new Point2D(19, 64), "inner-cut-tr");
			AddSegment(o, new Point2D(20, 45), new Point2D(19, 46), "inner-cut-br");
			AddSegment(o, new Point2D(0, 45), new Point2D(1, 46), "inner-cut-bl");
			AddSegment(o, new Point2D(0, 45), new Point2D(20, 45), "inner-cross45");
			AddSegment(o, new Point2D(0, 30), new Point2D(20, 30), "inner-cross30");
			return o;
		}

		private static void OuterBoundaryOwnershipRejectsInternalTopFrame()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			foreach (double angle in new[] { 0.0, 90.0, 180.0, 270.0 })
			{
				var outline = TransformLProfileFixture(CreateInternalTopFrameFixture(), angle, false);
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
				var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
				Assert(!plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Structure
					&& (Math.Abs(GetSpan(d) - 18) <= config.GeometryTolerance || Math.Abs(GetSpan(d) - 19) <= config.GeometryTolerance)),
					"internal frame and its coordinate-only complement must not become outer structure dimensions, rotation=" + angle);
				Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Overall && Math.Abs(GetSpan(d) - 20) <= config.GeometryTolerance)
					&& plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Overall && Math.Abs(GetSpan(d) - 65) <= config.GeometryTolerance),
					"rejecting internal frame dimensions must retain both real overall dimensions");
				Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.SourceFeatureId == "inner-top18"
					&& !c.IsSelected && c.DecisionReason == "StructureSourceNotOnExteriorBoundary"),
					"the rejected raw internal edge must carry its ownership reason");
				Assert(outline.Segments.Count == 18, "ownership filtering must not delete source geometry");
			}
		}

		private static void ChamferComplementRequiresBoundaryWalk()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D { MinX = 0, MinY = 0, MaxX = 10, MaxY = 10 };
			AddSegment(outline, new Point2D(0, 0), new Point2D(9, 0), "seed");
			AddSegment(outline, new Point2D(9, 0), new Point2D(10, 1), "cut");
			AddSegment(outline, new Point2D(10, 1), new Point2D(10, 10), "right");
			AddSegment(outline, new Point2D(10, 10), new Point2D(0, 10), "top");
			AddSegment(outline, new Point2D(0, 10), new Point2D(0, 0), "left");
			outline.Chamfers.Add(new ChamferFeature2D { StartPoint = new Point2D(9, 0), EndPoint = new Point2D(10, 1), Value = 1 });
			var boundary = new StructureBoundaryEvidence(DimensionPlanner.InspectOutlineTopology(outline, config.GeometryTolerance), config.GeometryTolerance);
			var seed = new StructureFeature { Axis = StructureFeatureAxis.Horizontal, FirstPoint = new Point2D(0, 0),
				SecondPoint = new Point2D(9, 0), CrossPosition = 0, BoundaryMembership = boundary.GetMembership(outline.Segments[0]) };
			string proof;
			List<string> sources;
			Assert(boundary.TryProveChamferComplement(seed, new Point2D(0, 0), new Point2D(10, 1), outline, 8, out proof, out sources)
				&& sources.Contains("seed") && sources.Contains("cut"), "real connected endpoints must admit a traceable boundary proof");
			Assert(!boundary.TryProveChamferComplement(seed, new Point2D(0, 0), new Point2D(10, 0), outline, 8, out proof, out sources),
				"the same numeric span with a theoretical corner must not be emitted");
			outline.Chamfers.Clear();
			Assert(!boundary.TryProveChamferComplement(seed, new Point2D(0, 0), new Point2D(10, 1), outline, 8, out proof, out sources),
				"a coordinate difference and inclined edge cannot replace a recognized chamfer definition");
		}

		private static void BoundarySelectionCannotRestoreInternalEdges()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateInternalTopFrameFixture();
			var boundary = new StructureBoundaryEvidence(DimensionPlanner.InspectOutlineTopology(outline, config.GeometryTolerance), config.GeometryTolerance);
			var features = new StructureFeatureExtractor(config).Extract(outline, boundary);
			var inner = features.Single(f => f.SourceKey == "inner-top18");
			inner.Keep = true;
			inner.IsInset = false;
			inner.SourceKey = "OuterTip:MisleadingLabel";
			new StructureMeasurementSelector(config).Select(features, outline, boundary);
			Assert(!inner.Keep && inner.BoundaryMembership == "NonBoundary", "neither proximity, restoration nor a source label may override real ownership");
			var independent = new StructureFeature { Kind = StructureFeatureKind.NotchOpening, Keep = true, IsInset = true };
			StructureBoundaryEvidence.EnforceSelection(new[] { independent });
			Assert(independent.Keep, "the outer-edge guard must not blanket-delete independent feature paths");
			var unknown = new StructureFeature { Kind = StructureFeatureKind.RealStep, Keep = true, RequiresOuterBoundarySupport = true };
			StructureBoundaryEvidence.EnforceSelection(new[] { unknown });
			Assert(!unknown.Keep && unknown.SuppressReason == "StructureBoundaryEvidenceInsufficient", "missing ownership must remain unproven, not default to outer structure");
		}

		private static void UnverifiedAttachmentRemainsUnknown()
		{
			var plan = new DimensionPlan();
			var candidate = CreateCoverageTestDimension("unverified");
			plan.Add(candidate);
			plan.CaptureFinalDimensions();
			Assert(plan.Diagnostics.FinalDimensions.Single().IsAttachmentValid == null
				&& plan.Diagnostics.FinalDimensions.Single().AttachmentValidationStatus == "Unknown",
				"unverified attachment must not default to true in either candidate or final diagnostics");
			plan.SetAttachmentValidity(candidate, true);
			plan.CaptureFinalDimensions();
			Assert(plan.Diagnostics.FinalDimensions.Single().IsAttachmentValid == true, "an actual positive validation must remain distinguishable");
			plan.SetAttachmentValidity(candidate, false);
			plan.CaptureFinalDimensions();
			Assert(plan.Diagnostics.FinalDimensions.Single().AttachmentValidationStatus == "Invalid", "a failed validation must not be confused with unknown");
		}

		// Normalized real L01-13 geometry, including the internal branch and the split right edge.
		private static OutlineFeature2D CreateL01ChamferResidualFixture(double armWidth, double topChamfer, double splitHeight = 15)
		{
			var outline = new OutlineFeature2D { MinX = 0, MinY = 0, MaxX = 145, MaxY = 65 };
			double innerX = 145 - armWidth;
			AddSegment(outline, new Point2D(145, splitHeight), new Point2D(145, 0), "4EF");
			AddSegment(outline, new Point2D(145, 0), new Point2D(100, 0), "4EE");
			AddSegment(outline, new Point2D(145, splitHeight), new Point2D(105, splitHeight), "4DB");
			AddSegment(outline, new Point2D(145, 65), new Point2D(145, splitHeight), "4DA");
			AddSegment(outline, new Point2D(100, 0), new Point2D(0, 0), "4D2");
			AddSegment(outline, new Point2D(100, 0), new Point2D(100, splitHeight - 5), "4D1");
			AddSegment(outline, new Point2D(innerX + topChamfer, 65), new Point2D(145, 65), "4D9");
			AddSegment(outline, new Point2D(0, 0), new Point2D(0, 20), "4D3");
			AddSegment(outline, new Point2D(innerX + topChamfer, 65), new Point2D(innerX, 65 - topChamfer), "4D8");
			AddSegment(outline, new Point2D(0, 20), new Point2D(5, 25), "4D4");
			AddSegment(outline, new Point2D(innerX, 30), new Point2D(innerX, 65 - topChamfer), "4D7");
			AddSegment(outline, new Point2D(5, 25), new Point2D(innerX - 5, 25), "4D5");
			outline.Arcs.Add(new Arc2D { Start = new Point2D(105, splitHeight), End = new Point2D(100, splitHeight - 5),
				Center = new Point2D(105, splitHeight - 5), Radius = 5, Bulge = Math.Tan(Math.PI / 8), SourceKey = "4D0" });
			outline.Arcs.Add(new Arc2D { Start = new Point2D(innerX - 5, 25), End = new Point2D(innerX, 30),
				Center = new Point2D(innerX - 5, 30), Radius = 5, Bulge = Math.Tan(Math.PI / 8), SourceKey = "4D6" });
			return outline;
		}

		private static void CollinearExteriorBranchFragmentsUseTopology()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			foreach (double split in new[] { 13.0, 15.0, 17.0 })
			foreach (double rotation in new[] { 0.0, 90.0, 180.0, 270.0 })
			foreach (bool mirror in new[] { false, true })
			{
				var outline = TransformLProfileFixture(CreateL01ChamferResidualFixture(25, 5, split), rotation, mirror);
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
				var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
				var removed = plan.Diagnostics.DimensionCandidates.Where(c => c.RuleId == "Structure.CollinearBoundaryBranchFragment").ToList();
				Assert(removed.Any(c => c.IsSuppressed && Math.Abs(c.Value - split) <= config.GeometryTolerance
					&& c.TopologyEvidence.Contains("InternalBranchOnContinuousExterior") && c.TopologyEvidence.Contains("CoveredByIds=")),
					"split exterior fragment needs real branch/continuation/provider proof, independent of value, rotation and mirror");
				Assert(!plan.Dimensions.Any(d => d.SourceGeometryIds.Contains("4EF") && d.SourceKey == "OuterTip:4EF"),
					"the pseudo outer tip must not survive through its alternate generation path");
				Assert(plan.Dimensions.Count(d => d.Role == DimensionCandidateRole.Overall) == 2
					&& plan.Dimensions.Count(d => d.RuleId == "LProfile.VerticalArmWidth" || d.RuleId == "LProfile.HorizontalArmHeight") == 2,
					"both overall dimensions and real arm thicknesses must survive");
				Assert(!plan.Diagnostics.Warnings.Any(w => w.StartsWith("StructureCoverage.Incomplete|", StringComparison.Ordinal)),
					"the full-side provider must remain live");
			}
		}

		private static void InvokeExteriorFragmentPass(DimensionPlan plan, OutlineFeature2D outline)
		{
			typeof(DimensionPlanner).GetMethod("SuppressCollinearExteriorBranchFragments",
				System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
				.Invoke(new DimensionPlanner(DimensionRuleConfig.CreateDefault()), new object[] { plan, outline });
		}

		private static void CollinearExteriorBranchFragmentsProtectRequirements()
		{
			foreach (string variant in new[] { "plain", "raw", "tolerance", "functional", "feature", "outerLevel", "rule", "unknown", "noProvider", "wrongProvider", "noBranch", "corner" })
			{
				var outline = CreateL01ChamferResidualFixture(25, 5);
				if (variant == "noBranch")
				{
					outline.Segments.RemoveAll(s => s.SourceKey == "4DB" || s.SourceKey == "4D1");
					outline.Arcs.RemoveAll(a => a.SourceKey == "4D0");
				}
				if (variant == "corner")
				{
					outline = new OutlineFeature2D { MinX = 0, MinY = 0, MaxX = 145, MaxY = 65 };
					var points = new[] { new Point2D(145, 0), new Point2D(145, 15), new Point2D(135, 15),
						new Point2D(135, 65), new Point2D(0, 65), new Point2D(0, 0) };
					for (int i = 0; i < points.Length; i++) { AddSegment(outline, points[i], points[(i + 1) % points.Length], i == 0 ? "4EF" : "corner" + i); }
				}
				var plan = new DimensionPlan();
				plan.Diagnostics.OutlineTopology = DimensionPlanner.InspectOutlineTopology(outline, 0.001);
				if (variant == "unknown") { plan.Diagnostics.OutlineTopology.Status = "Unavailable"; }
				var candidate = CreateCoverageTestDimension("OuterTip:4EF", 15);
				candidate.Orientation = DimensionOrientation.Vertical;
				candidate.Side = DimensionSide.Right;
				candidate.RequiresOuterBoundarySupport = true;
				candidate.FirstPoint = new Point2D(145, 0); candidate.SecondPoint = new Point2D(145, 15);
				candidate.SourceGeometryIds = new List<string> { "4EF" };
				if (variant == "raw") { candidate.SourceKey = "4EF"; }
				if (variant == "feature") { candidate.SourceKey = "StepGroove:4EF"; }
				if (variant == "tolerance") { candidate.OverrideText = "15±0.02"; }
				if (variant == "functional") { candidate.Kind = DimensionKind.HoleLocation; }
				if (variant == "outerLevel") { candidate.ForceOuterLevel = true; }
				if (variant == "rule") { candidate.RuleId = "IndependentFeatureRequirement"; }
				plan.Add(candidate);
				var provider = new PlannedDimension { Kind = DimensionKind.OverallHeight, Role = DimensionCandidateRole.Overall,
					Orientation = DimensionOrientation.Vertical, FirstPoint = new Point2D(145, 0),
					SecondPoint = new Point2D(145, variant == "wrongProvider" ? 60 : 65) };
				if (variant != "noProvider") { plan.Add(provider); }
				InvokeExteriorFragmentPass(plan, outline);
				Assert(plan.Dimensions.Contains(candidate) == (variant != "plain" && variant != "raw"),
					"only the proven unannotated fragment is removable; protected/unknown/real-corner case=" + variant);
			}
		}

		private static void OutlineTopologyNonExteriorEntitiesUseYellowArrows()
		{
			var graph = DimensionPlanner.InspectOutlineTopology(CreateL01ChamferResidualFixture(25, 5), 0.001);
			string svg = OutlineTopologyExporter.ToSvg(graph, "yellow-arrows");
			Assert(svg.Contains("data-membership=\"NonBoundary\"") && svg.Contains("marker-end=\"url(#nonExteriorArrow)\"")
				&& svg.Contains("stroke=\"#e6b800\"") && svg.Contains("非外轮廓实体") && svg.Contains("marker-end=\"url(#arrow)\""),
				"confirmed non-exterior lines/arcs need yellow source-direction arrows while exterior traversal stays green");
			Assert(OutlineTopologyExporter.ToJson(graph).Contains("\"boundaryMembership\":\"NonBoundary\""),
				"JSON must expose the same explicit non-exterior ownership");
			graph.Status = "Unavailable";
			string unknown = OutlineTopologyExporter.ToSvg(graph, "unknown");
			Assert(!unknown.Contains("marker-end=\"url(#nonExteriorArrow)\"") && unknown.Contains("data-membership=\"Unknown\"")
				&& !OutlineTopologyExporter.ToJson(graph).Contains("\"boundaryMembership\":\"NonBoundary\""),
				"unresolved topology must remain gray/unknown, never relabeled as non-exterior");
		}

		private static OutlineFeature2D CreateObliqueBoundaryInformationFixture(double scale = 1, bool equalProjections = false)
		{
			var outline = new OutlineFeature2D { MinX = 0, MinY = 0, MaxX = 89 * scale, MaxY = 62.022 * scale };
			double innerX = equalProjections ? 79 : 69;
			var points = new[] { new Point2D(innerX, 1), new Point2D(innerX, 17.022), new Point2D(54, 42.022),
				new Point2D(0, 42.022), new Point2D(0, 62.022), new Point2D(65, 62.022),
				new Point2D(89, 12.022), new Point2D(89, 1), new Point2D(88, 0), new Point2D(innerX + 1, 0) };
			string[] sources = { "B8F", "B87", "B85", "B88", "B86", "B89", "B8E", "B92", "B91", "B93" };
			for (int i = 0; i < points.Length; i++)
			{
				var a = points[i]; var b = points[(i + 1) % points.Length];
				AddSegment(outline, new Point2D(a.X * scale, a.Y * scale), new Point2D(b.X * scale, b.Y * scale), sources[i]);
			}
			AddSegment(outline, new Point2D(innerX * scale, scale), new Point2D(89 * scale, scale), "B90");
			return outline;
		}

		private static void ObliqueBoundaryInformationMatchesUserScheme()
		{
			var config = DimensionRuleConfig.CreateDefault(); config.UseFeatureFirstStructurePipeline = true;
			foreach (double scale in new[] { 1.0, 1.3 })
			foreach (double rotation in new[] { 0.0, 90.0, 180.0, 270.0 })
			foreach (bool mirror in new[] { false, true })
			{
				var outline = TransformLProfileFixture(CreateObliqueBoundaryInformationFixture(scale), rotation, mirror);
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
				var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
				var values = plan.Dimensions.Select(GetSpan).OrderBy(v => v).ToList();
				var expected = new[] { 15, 20, 20, 25, 50, 62.022, 65, 89 }.Select(v => v * scale).OrderBy(v => v).ToList();
				Assert(values.Count == expected.Count && values.Zip(expected, (a, b) => Math.Abs(a - b) <= config.GeometryTolerance).All(equal => equal),
					"the user scheme needs the eight independent boundary dimensions, not raw 54/18/short walls; scale=" + scale + " rotation=" + rotation + " mirror=" + mirror);
				Assert(plan.Diagnostics.OutlineInformationStatus == "CompleteForRecognizedBoundaryRequirements"
					&& plan.Diagnostics.OutlineInformationDecisions.All(d => !d.Contains("PendingConfirmation")), "every recognized real-edge/projection requirement needs a live explanation");
				var face = plan.Dimensions.Single(d => d.DebugRole == "BoundaryChamferSpan");
				Assert(!face.SourceGeometryIds.Contains("B90") && face.AttachmentValidity == true,
					"the foot span must use the real exterior chamfer route, never the internal chord or missing sharp corners");
				Assert(plan.Diagnostics.DimensionCandidates.Any(d => d.RuleId == "BoundaryInformation.Covered" && d.TopologyEvidence.Contains("ConnectedProjectedConstraintPath")),
					"remainder suppression requires connected station identities and live providers");
				if (rotation == 0 && !mirror)
				{
					Assert(plan.Dimensions.Single(d => d.DebugRole == "BoundaryObliqueProjection" && Math.Abs(GetSpan(d) - 15 * scale) < config.GeometryTolerance).Side == DimensionSide.Bottom,
						"inner horizontal slope projection belongs below the contour");
					Assert(plan.Dimensions.Single(d => d.DebugRole == "BoundaryObliqueProjection" && Math.Abs(GetSpan(d) - 25 * scale) < config.GeometryTolerance).Side == DimensionSide.Left,
						"inner vertical slope projection follows the empty left side, not the nearest bounding-box side");
					Assert(plan.Dimensions.Single(d => d.DebugRole == "BoundaryObliqueProjection" && Math.Abs(GetSpan(d) - 50 * scale) < config.GeometryTolerance).Side == DimensionSide.Right,
						"outer vertical slope projection belongs on the right");
				}
			}
		}

		private static void ObliqueBoundaryInformationProtectsEqualProjections()
		{
			var config = DimensionRuleConfig.CreateDefault(); config.UseFeatureFirstStructurePipeline = true;
			var outline = CreateObliqueBoundaryInformationFixture(1, equalProjections: true);
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var projections = plan.Dimensions.Where(d => d.DebugRole == "BoundaryObliqueProjection" && d.SourceGeometryIds.Contains("B87")).ToList();
			Assert(projections.Count == 2 && projections.Select(d => d.Orientation).Distinct().Count() == 2
				&& projections.All(d => Math.Abs(GetSpan(d) - 25) <= config.GeometryTolerance),
				"a body 45-degree edge needs both independent projections unless one is proved covered; equal values are not duplicates");
			Assert(plan.Dimensions.Where(d => d.DebugRole == "BoundaryObliqueProjection").All(d => !d.SourceGeometryIds.Contains("B92") && !d.SourceGeometryIds.Contains("B93")),
				"recognized C1 edges must remain chamfer definitions rather than body-slope candidates");
		}

		private static void ObliqueBoundaryInformationFallsBackAndAuditsMissingProviders()
		{
			var config = DimensionRuleConfig.CreateDefault(); config.UseFeatureFirstStructurePipeline = true;
			var outline = CreateObliqueBoundaryInformationFixture();
			var fallback = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(!fallback.Dimensions.Any(d => d.DebugRole == "BoundaryChamferSpan")
				&& fallback.Dimensions.Any(d => d.SourceKey == "B91" && Math.Abs(GetSpan(d) - 18) <= config.GeometryTolerance),
				"without recognized chamfer replacements, the real original foot edge must remain available");
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var provider = plan.Dimensions.Single(d => d.DebugRole == "BoundaryObliqueProjection" && d.Orientation == DimensionOrientation.Horizontal && d.SourceGeometryIds.Contains("B87"));
			plan.Dimensions.Remove(provider);
			typeof(DimensionPlanner).GetMethod("AuditBoundaryInformationPlan", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)
				.Invoke(new DimensionPlanner(config), new object[] { plan, outline });
			Assert(plan.Diagnostics.OutlineInformationStatus == "PendingConfirmation", "provider loss must invalidate the scoped completeness claim");
		}

		private static void LProfileChamferedArmResidualUsesBoundarySequence()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			foreach (var sizes in new[] { new[] { 25.0, 5.0 }, new[] { 32.0, 7.0 } })
			foreach (double rotation in new[] { 0.0, 90.0, 180.0, 270.0 })
			foreach (bool mirror in new[] { false, true })
			{
				var outline = TransformLProfileFixture(CreateL01ChamferResidualFixture(sizes[0], sizes[1]), rotation, mirror);
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
				var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
				string context = " width=" + sizes[0] + " chamfer=" + sizes[1] + " rotation=" + rotation + " mirror=" + mirror;
				var suppressed = plan.Diagnostics.DimensionCandidates.Where(c => c.RuleId == "LProfile.ChamferedArmResidual").ToList();
				Assert(suppressed.Count == 1 && suppressed[0].IsSuppressed
					&& Math.Abs(suppressed[0].Value - (sizes[0] - sizes[1])) <= config.GeometryTolerance,
					"the real short edge must be suppressed by boundary topology, not a fixed numeric value" + context);
				Assert(suppressed[0].TopologyEvidence.Contains("InnerFaceChamferShortEdgeOuterFace")
					&& suppressed[0].TopologyEvidence.Contains("CoveredByIds="),
					"coverage must identify the actual boundary relation and provider" + context);
				Assert(plan.Dimensions.Any(d => (d.RuleId == "LProfile.VerticalArmWidth" || d.RuleId == "LProfile.HorizontalArmHeight")
					&& Math.Abs(GetSpan(d) - sizes[0]) <= config.GeometryTolerance),
					"the defining arm width must survive" + context);
				Assert(plan.Dimensions.Any(d => (d.RuleId == "LProfile.VerticalArmWidth" || d.RuleId == "LProfile.HorizontalArmHeight")
					&& Math.Abs(GetSpan(d) - 25) <= config.GeometryTolerance),
					"the independent horizontal-arm thickness must survive, including the same-valued residual variant" + context);
				Assert(plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Overall && Math.Abs(GetSpan(d) - 145) <= config.GeometryTolerance)
					&& plan.Dimensions.Any(d => d.Role == DimensionCandidateRole.Overall && Math.Abs(GetSpan(d) - 65) <= config.GeometryTolerance),
					"both overall dimensions must survive" + context);
				Assert(!plan.Diagnostics.Warnings.Any(w => w.StartsWith("StructureCoverage.Incomplete|", StringComparison.Ordinal)),
					"the defining width must remain available after later suppression" + context);
			}
		}

		private static void LProfileChamferedArmResidualRequiresChamferDefinition()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var outline = CreateL01ChamferResidualFixture(25, 5);
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			outline.Chamfers.Clear();
			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(!plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.ChamferedArmResidual"),
				"an inclined boundary alone must not stand in for a recognized chamfer definition");
			Assert(plan.Dimensions.Any(d => d.SourceKey == "4D9" && Math.Abs(GetSpan(d) - 20) <= config.GeometryTolerance),
				"without a chamfer definition the short-edge information must not be discarded");
		}

		private static void LProfileAnnotationRulesUseTopology()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var cases = new[]
			{
				CreateLProfileAnnotationFixture(),
				TransformLProfileFixture(CreateLProfileAnnotationFixture(), 90.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileAnnotationFixture(), 180.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileAnnotationFixture(), 270.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileAnnotationFixture(), 0.0, mirrorX: true)
			};
			int caseIndex = 0;
			foreach (OutlineFeature2D outline in cases)
			{
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);

				var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			var selected = plan.Dimensions
				.Where(d => d.Kind == DimensionKind.OverallWidth
					|| d.Kind == DimensionKind.OverallHeight
					|| d.Kind == DimensionKind.Normal)
				.ToList();
			Assert(selected.Any(d => (d.Kind == DimensionKind.OverallWidth || d.Kind == DimensionKind.OverallHeight)
				&& Math.Abs(GetSpan(d) - 170.0) <= config.GeometryTolerance),
				"L profile must keep overall span 170");
			Assert(selected.Any(d => (d.Kind == DimensionKind.OverallWidth || d.Kind == DimensionKind.OverallHeight)
				&& Math.Abs(GetSpan(d) - 85.0) <= config.GeometryTolerance),
				"L profile must keep overall span 85");
			Assert(selected.Count(d => d.Kind == DimensionKind.Normal && Math.Abs(GetSpan(d) - 25.0) <= config.GeometryTolerance) == 2,
				"L profile must keep exactly two orthogonal 25 dimensions");
			Assert(!selected.Any(d => d.Kind == DimensionKind.Normal
				&& (Math.Abs(GetSpan(d) - 15.0) <= config.GeometryTolerance
					|| Math.Abs(GetSpan(d) - 22.0) <= config.GeometryTolerance
					|| Math.Abs(GetSpan(d) - 52.0) <= config.GeometryTolerance)),
				"L profile must remove 15, 22 and derived 52, case=" + caseIndex
				+ " selected=" + string.Join(",", selected.Select(d => d.DebugRole + ":" + GetSpan(d) + ":" + d.RuleId)));
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.VerticalArmWidth"
				&& c.IsSelected && Math.Abs(c.Value - 25.0) <= config.GeometryTolerance && c.IsAttachmentValid == true),
				"top 25 replacement must retain an attachment-valid rule diagnostic");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.HorizontalArmHeight"
				&& c.IsSelected && Math.Abs(c.Value - 25.0) <= config.GeometryTolerance),
				"horizontal-arm height 25 must be retained by topology");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.DerivedInnerEdge"
				&& c.IsSuppressed && Math.Abs(c.Value - 52.0) <= config.GeometryTolerance),
				"derived inner edge 52 must be suppressed by the closure formula, case=" + caseIndex
				+ " rules=" + string.Join(",", plan.Diagnostics.DimensionCandidates.Select(c => c.RuleId + ":" + c.Value + ":" + c.Orientation + ":" + c.FirstPointX + "," + c.FirstPointY + "-" + c.SecondPointX + "," + c.SecondPointY + ":" + c.SuppressedReason + ":" + c.TopologyEvidence)));
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.InternalChordEndpoint"
				&& c.IsSuppressed && Math.Abs(c.Value - 15.0) <= config.GeometryTolerance),
				"bottom 15 must be suppressed by the internal-chord endpoint rule");
			List<DimensionCandidateDiagnostic> stepGrooves = plan.Diagnostics.DimensionCandidates
				.Where(c => c.SourceFeatureId != null
					&& c.SourceFeatureId.StartsWith("StepGroove:", StringComparison.Ordinal))
				.ToList();
			Assert(!stepGrooves.Any(c => c.IsSelected),
				"an L-profile StepGroove candidate must not remain selected after open-interior-chord suppression, case=" + caseIndex);
			AssertLProfileRuleEndpointsOnBoundary(plan, outline, config.GeometryTolerance, "case=" + caseIndex);
			caseIndex++;
			}
		}

		private static void LProfileTopologyRejectionIsDiagnostic()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var plan = new DimensionPlanner(config).CreateOutlinePlan(CreateRectangle(95.0, 95.0));

			Assert(plan.Diagnostics.Warnings.Any(w => w.StartsWith("LProfile.NotApplied|", StringComparison.Ordinal)
				&& w.IndexOf("ConnectedCornerPairCount=0", StringComparison.Ordinal) >= 0),
				"a non-L outline must explain why the L profile rule was not applied");
		}

		private static void RoundedRectangleOuterContourIsNotLProfile()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var segments = new[]
			{
				new Segment2D(new Point2D(0.0, 0.0), new Point2D(100.0, 0.0)) { SourceKey = "bottom" },
				new Segment2D(new Point2D(100.0, 0.0), new Point2D(100.0, 40.0)) { SourceKey = "right" },
				new Segment2D(new Point2D(90.0, 50.0), new Point2D(10.0, 50.0)) { SourceKey = "top" },
				new Segment2D(new Point2D(0.0, 40.0), new Point2D(0.0, 0.0)) { SourceKey = "left" }
			};
			var arcs = new[]
			{
				new Arc2D
				{
					Start = new Point2D(100.0, 40.0),
					End = new Point2D(90.0, 50.0),
					Center = new Point2D(90.0, 40.0),
					Radius = 10.0,
					Bulge = Math.Tan(Math.PI / 8.0),
					SourceKey = "top-right-fillet"
				},
				new Arc2D
				{
					Start = new Point2D(10.0, 50.0),
					End = new Point2D(0.0, 40.0),
					Center = new Point2D(10.0, 40.0),
					Radius = 10.0,
					Bulge = Math.Tan(Math.PI / 8.0),
					SourceKey = "top-left-fillet"
				}
			};
			DimensionPlan plan = new DimensionPlanner(config).CreateOutlinePlan(
				new FeatureRecognizer2D(config).RecognizeOutlineFromSegments(segments, arcs));

			Assert(plan.Diagnostics.Warnings.Any(w => w.StartsWith("OuterContour|Shape=RoundedRectangle|", StringComparison.Ordinal)),
				"rounded rectangle must be recognized before L-profile matching");
			Assert(plan.Diagnostics.Warnings.Any(w => w == "LProfile.NotApplied|Reason=RoundedRectangle"),
				"rounded rectangle must skip L-profile rules");
			Assert(!plan.Diagnostics.Warnings.Any(w => w.StartsWith("LProfile.Applied|", StringComparison.Ordinal)),
				"rounded rectangle must not apply L-profile dimensions");
		}

		private static void LProfileFarEndCornerUsesAdjacentVerticalChain()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var cases = new[]
			{
				CreateLProfileWithFarEndCornerFixture(),
				TransformLProfileFixture(CreateLProfileWithFarEndCornerFixture(), 90.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileWithFarEndCornerFixture(), 180.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileWithFarEndCornerFixture(), 270.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileWithFarEndCornerFixture(), 0.0, mirrorX: true)
			};
			int caseIndex = 0;
			foreach (OutlineFeature2D outline in cases)
			{
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
				var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
				var selected = plan.Dimensions
					.Where(d => d.Kind == DimensionKind.OverallWidth
						|| d.Kind == DimensionKind.OverallHeight
						|| d.Kind == DimensionKind.Normal)
					.ToList();
				Assert(!plan.Diagnostics.Warnings.Any(w => w.StartsWith("LProfile.NotApplied|", StringComparison.Ordinal)),
					"L profile with a far-end corner must resolve its adjacent vertical chain, case=" + caseIndex
					+ ": " + string.Join(";", plan.Diagnostics.Warnings));
				Assert(selected.Count(d => d.Kind == DimensionKind.Normal
					&& Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance) == 2,
					"far-end corner L profile must keep exactly two 20 dimensions, case=" + caseIndex);
				Assert(!selected.Any(d => d.Kind == DimensionKind.Normal
					&& Math.Abs(GetSpan(d) - 69.0) <= config.GeometryTolerance),
					"far-end corner L profile must suppress the derived 69 inner edge, case=" + caseIndex);
				Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.HorizontalArmHeight"
					&& c.IsSelected && Math.Abs(c.Value - 20.0) <= config.GeometryTolerance),
					"far-end corner must retain the topology-derived horizontal-arm height, case=" + caseIndex);
				Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.DerivedInnerEdge"
					&& c.IsSuppressed && Math.Abs(c.Value - 69.0) <= config.GeometryTolerance),
					"far-end corner must mark the derived inner edge diagnostic, case=" + caseIndex);
				AssertLProfileRuleEndpointsOnBoundary(plan, outline, config.GeometryTolerance, "case=" + caseIndex);
				caseIndex++;
			}
		}

		private static void LProfileOuterContourAnnotationRulesUseTopology()
		{
			var config = DimensionRuleConfig.CreateDefault();
			config.UseFeatureFirstStructurePipeline = true;
			var cases = new[]
			{
				CreateLProfileOuterContourFixture(),
				TransformLProfileFixture(CreateLProfileOuterContourFixture(), 90.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileOuterContourFixture(), 180.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileOuterContourFixture(), 270.0, mirrorX: false),
				TransformLProfileFixture(CreateLProfileOuterContourFixture(), 0.0, mirrorX: true)
			};
			int caseIndex = 0;
			foreach (OutlineFeature2D outline in cases)
			{
				new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
				DimensionPlan plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
				List<PlannedDimension> selected = plan.Dimensions
					.Where(d => d.Kind == DimensionKind.OverallWidth
						|| d.Kind == DimensionKind.OverallHeight
						|| d.Kind == DimensionKind.Normal)
					.ToList();
				Assert(plan.Diagnostics.Warnings.Any(w => w.StartsWith("LProfile.Recognized|", StringComparison.Ordinal)),
					"outer-contour L must be recognized, case=" + caseIndex);
				Assert(plan.Diagnostics.Warnings.Any(w => w.StartsWith("LProfile.Applied|Strategy=ConcaveCornerInnerChains", StringComparison.Ordinal)),
					"outer-contour L must use the connected inner-chain strategy, case=" + caseIndex
					+ " warnings=" + string.Join(";", plan.Diagnostics.Warnings));
				Assert(!plan.Diagnostics.Warnings.Any(w => w.StartsWith("LProfile.NotApplied|", StringComparison.Ordinal)),
					"outer-contour L must not be reported as unapplied, case=" + caseIndex);
				Assert(selected.Count(d => d.Kind == DimensionKind.Normal && Math.Abs(GetSpan(d) - 20.0) <= config.GeometryTolerance) == 2,
					"outer-contour L must keep exactly two 20 dimensions, case=" + caseIndex);
				Assert(!selected.Any(d => d.Kind == DimensionKind.Normal && Math.Abs(GetSpan(d) - 52.0) <= config.GeometryTolerance),
					"outer-contour L must suppress derived inner 52, case=" + caseIndex);
				Assert(!selected.Any(d => d.Kind == DimensionKind.Normal
					&& (Math.Abs(GetSpan(d) - 70.0) <= config.GeometryTolerance
						|| Math.Abs(GetSpan(d) - 17.0) <= config.GeometryTolerance)),
					"outer-contour L must suppress redundant inner-horizontal/outer-vertical segments, case=" + caseIndex);
				Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.VerticalArmWidth"
					&& c.IsSelected && Math.Abs(c.Value - 20.0) <= config.GeometryTolerance),
					"outer-contour L must keep vertical-arm width, case=" + caseIndex);
				Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.HorizontalArmHeight"
					&& c.IsSelected && Math.Abs(c.Value - 20.0) <= config.GeometryTolerance),
					"outer-contour L must keep horizontal-arm height, case=" + caseIndex);
				Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.RuleId == "LProfile.DerivedInnerEdge"
					&& c.IsSuppressed && Math.Abs(c.Value - 52.0) <= config.GeometryTolerance),
					"outer-contour L must diagnose derived inner 52 suppression, case=" + caseIndex);
				AssertLProfileRuleEndpointsOnBoundary(plan, outline, config.GeometryTolerance, "outer-contour case=" + caseIndex);
				caseIndex++;
			}
		}

		private static void AssertLProfileRuleEndpointsOnBoundary(
			DimensionPlan plan,
			OutlineFeature2D outline,
			double tolerance,
			string context)
		{
			foreach (string ruleId in new[] { "LProfile.VerticalArmWidth", "LProfile.HorizontalArmHeight" })
			{
				DimensionCandidateDiagnostic candidate = plan.Diagnostics.DimensionCandidates
					.Single(d => d.RuleId == ruleId && d.IsSelected);
				Point2D first = new Point2D(candidate.FirstPointX, candidate.FirstPointY);
				Point2D second = new Point2D(candidate.SecondPointX, candidate.SecondPointY);
				Assert(OutlineGeometryQuery.IsPointOnBoundary(first, outline, tolerance)
					&& OutlineGeometryQuery.IsPointOnBoundary(second, outline, tolerance),
					ruleId + " must keep both defining points on the outer contour, " + context
					+ " first=" + candidate.FirstPointX + "," + candidate.FirstPointY
					+ " second=" + candidate.SecondPointX + "," + candidate.SecondPointY);
			}
		}

		private static OutlineFeature2D CreateLProfileAnnotationFixture()
		{
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 170.0,
				MaxY = 85.0
			};
			AddSegment(outline, new Point2D(0.0, 5.0), new Point2D(0.0, 85.0), "left");
			AddSegment(outline, new Point2D(0.0, 85.0), new Point2D(22.0, 85.0), "top");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(22.0, 85.0),
				End = new Point2D(25.0, 82.0),
				Center = new Point2D(22.0, 82.0),
				Radius = 3.0,
				Bulge = -Math.Tan(Math.PI / 8.0),
				SourceKey = "R3"
			});
			AddSegment(outline, new Point2D(25.0, 30.0), new Point2D(25.0, 82.0), "inner-vertical");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(25.0, 30.0),
				End = new Point2D(30.0, 25.0),
				Center = new Point2D(30.0, 30.0),
				Radius = 5.0,
				Bulge = Math.Tan(Math.PI / 8.0),
				SourceKey = "R5"
			});
			AddSegment(outline, new Point2D(30.0, 25.0), new Point2D(155.0, 25.0), "arm-top-left");
			AddSegment(outline, new Point2D(155.0, 25.0), new Point2D(170.0, 25.0), "arm-top-right");
			AddSegment(outline, new Point2D(170.0, 25.0), new Point2D(170.0, 0.0), "right-arm");
			AddSegment(outline, new Point2D(170.0, 0.0), new Point2D(155.0, 0.0), "bottom-right");
			AddSegment(outline, new Point2D(155.0, 0.0), new Point2D(155.0, 25.0), "internal-chord");
			AddSegment(outline, new Point2D(155.0, 0.0), new Point2D(5.0, 0.0), "bottom-left");
			AddSegment(outline, new Point2D(5.0, 0.0), new Point2D(0.0, 5.0), "C5");
			return outline;
		}

		private static OutlineFeature2D CreateLProfileWithFarEndCornerFixture()
		{
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 95.0,
				MaxY = 95.0
			};
			AddSegment(outline, new Point2D(0.0, 3.0), new Point2D(0.0, 95.0), "left");
			AddSegment(outline, new Point2D(0.0, 95.0), new Point2D(17.0, 95.0), "top");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(17.0, 95.0),
				End = new Point2D(20.0, 92.0),
				Center = new Point2D(17.0, 92.0),
				Radius = 3.0,
				Bulge = -Math.Tan(Math.PI / 8.0),
				SourceKey = "R3-top"
			});
			AddSegment(outline, new Point2D(20.0, 23.0), new Point2D(20.0, 92.0), "inner-vertical");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(20.0, 23.0),
				End = new Point2D(23.0, 20.0),
				Center = new Point2D(23.0, 23.0),
				Radius = 3.0,
				Bulge = Math.Tan(Math.PI / 8.0),
				SourceKey = "R3-inner"
			});
			AddSegment(outline, new Point2D(23.0, 20.0), new Point2D(92.0, 20.0), "arm-top");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(92.0, 20.0),
				End = new Point2D(95.0, 17.0),
				Center = new Point2D(92.0, 17.0),
				Radius = 3.0,
				Bulge = -Math.Tan(Math.PI / 8.0),
				SourceKey = "R3-right"
			});
			AddSegment(outline, new Point2D(95.0, 17.0), new Point2D(95.0, 0.0), "right-arm");
			AddSegment(outline, new Point2D(95.0, 0.0), new Point2D(5.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(5.0, 0.0), new Point2D(0.0, 3.0), "C5");
			return outline;
		}

		private static OutlineFeature2D CreateLProfileOuterContourFixture()
		{
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 90.0,
				MaxY = 75.0
			};
			AddSegment(outline, new Point2D(0.0, 55.0), new Point2D(0.0, 72.0), "left-arm");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(0.0, 72.0),
				End = new Point2D(3.0, 75.0),
				Center = new Point2D(3.0, 72.0),
				Radius = 3.0,
				Bulge = -Math.Tan(Math.PI / 8.0),
				SourceKey = "R3-top-left"
			});
			AddSegment(outline, new Point2D(3.0, 75.0), new Point2D(85.0, 75.0), "top-arm");
			AddSegment(outline, new Point2D(85.0, 75.0), new Point2D(90.0, 70.0), "C5-top-right");
			AddSegment(outline, new Point2D(90.0, 70.0), new Point2D(90.0, 0.0), "right-arm");
			AddSegment(outline, new Point2D(90.0, 0.0), new Point2D(73.0, 0.0), "bottom-right");
			outline.Arcs.Add(new Arc2D
			{
				Start = new Point2D(73.0, 0.0),
				End = new Point2D(70.0, 3.0),
				Center = new Point2D(73.0, 3.0),
				Radius = 3.0,
				Bulge = -Math.Tan(Math.PI / 8.0),
				SourceKey = "R3-bottom-inner"
			});
			AddSegment(outline, new Point2D(70.0, 3.0), new Point2D(70.0, 55.0), "inner-vertical");
			AddSegment(outline, new Point2D(70.0, 55.0), new Point2D(0.0, 55.0), "inner-horizontal");
			return outline;
		}

		private static OutlineFeature2D TransformLProfileFixture(OutlineFeature2D source, double degrees, bool mirrorX)
		{
			var transformed = new OutlineFeature2D();
			Func<Point2D, Point2D> transform = point =>
			{
				double x = mirrorX ? source.MaxX - point.X : point.X;
				double y = point.Y;
				double radians = degrees * Math.PI / 180.0;
				if (Math.Abs(degrees) > 1E-9)
				{
					double cosine = Math.Cos(radians);
					double sine = Math.Sin(radians);
					double rotatedX = cosine * x - sine * y;
					double rotatedY = sine * x + cosine * y;
					x = rotatedX;
					y = rotatedY;
				}
				return new Point2D(x, y);
			};
			foreach (Segment2D segment in source.Segments)
			{
				AddSegment(transformed, transform(segment.Start), transform(segment.End), segment.SourceKey);
			}
			foreach (Arc2D arc in source.Arcs)
			{
				transformed.Arcs.Add(new Arc2D
				{
					Start = transform(arc.Start),
					End = transform(arc.End),
					Center = transform(arc.Center),
					Radius = arc.Radius,
					Bulge = mirrorX ? -arc.Bulge : arc.Bulge,
					SourceKey = arc.SourceKey
				});
			}
			var points = transformed.Segments.SelectMany(segment => new[] { segment.Start, segment.End })
				.Concat(transformed.Arcs.SelectMany(arc => new[] { arc.Start, arc.End }))
				.ToList();
			transformed.MinX = points.Min(point => point.X);
			transformed.MaxX = points.Max(point => point.X);
			transformed.MinY = points.Min(point => point.Y);
			transformed.MaxY = points.Max(point => point.Y);
			return transformed;
		}

		/// <summary>
		/// L-shaped part matching CAD (overall 91×50, left tower width 20, right arm height 20,
		/// chamfer on tower so riser is not a clean [20,50] OS that would form overall partition
		/// with RightStructHeight 20). The right arm height lies on MaxX and must be suppressed
		/// by the higher-priority outer-envelope rule.
		/// </summary>
		private static void RightArmHeightOnOverallMaxXIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 91.0,
				MaxY = 50.0
			};
			// L + top-right chamfer on tower (like C11): riser is not a pure 30 vertical that
			// abuts arm height 20 into overall 50, so StructureOverallPartition does not apply.
			// MaxX coverage is only 20 &lt; overall height 50 → stepped edge keeps arm height.
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(91.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(91.0, 0.0), new Point2D(91.0, 20.0), "right-arm");
			AddSegment(outline, new Point2D(91.0, 20.0), new Point2D(20.0, 20.0), "step-top");
			AddSegment(outline, new Point2D(20.0, 20.0), new Point2D(20.0, 39.0), "step-up");
			AddSegment(outline, new Point2D(20.0, 39.0), new Point2D(9.0, 50.0), "chamfer");
			AddSegment(outline, new Point2D(9.0, 50.0), new Point2D(0.0, 50.0), "top-left");
			AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 50.0) <= config.GeometryTolerance),
				"overall height 50 must remain");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 91.0) <= config.GeometryTolerance),
				"overall width 91 must remain");
			Assert(plan.Dimensions.Any(d =>
					d.DebugRole == "RightStructHeight"
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 20.0) <= config.GeometryTolerance),
				"right arm height 20 on stepped MaxX must be kept");
		}


		/// <summary>
		/// Left-side step stack: keep LeftStructHeight 50+30; suppress right vertical OutlineSegments
		/// 30 (same interval) and 20 (overall residual). Phase-1 left/right symmetry.
		/// </summary>
		private static void LeftStepStructureHeightsPreferOverRightOutlineSegments()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 100.0),
				DebugRole = "OverallHeight"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(100.0, 0.0),
				DebugRole = "OverallWidth"
			});
			var left50 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 50.0),
				DebugRole = "LeftStructHeight"
			};
			var left30 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 50.0),
				SecondPoint = new Point2D(0.0, 80.0),
				DebugRole = "LeftStructHeight"
			};
			var rightOs30 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(50.0, 80.0),
				SecondPoint = new Point2D(50.0, 50.0),
				DebugRole = "OutlineSegment"
			};
			var rightOs20 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(80.0, 100.0),
				SecondPoint = new Point2D(80.0, 80.0),
				DebugRole = "OutlineSegment"
			};
			plan.Add(left50);
			plan.Add(left30);
			plan.Add(rightOs30);
			plan.Add(rightOs20);

			// Mirror then secondary-OS cleanup (same order as SuppressDuplicateDimensions tail).
			// Use full CreateOutlinePlan-equivalent suppress path via public-ish internals:
			// call the two new stages by running envelope-adjacent helpers through reflection-free API:
			// SuppressSecondary is internal; mirror is private — exercise via CreateOutlinePlan geometry below
			// for integration; this unit path calls internal secondary suppress after manual mirror prefer.
			planner.SuppressSecondaryVerticalOutlineSegmentsRedundantWithPrimaryStructureStack(plan);

			Assert(plan.Dimensions.Contains(left50), "left structure height 50 must remain");
			Assert(plan.Dimensions.Contains(left30), "left structure height 30 must remain (primary stack)");
			Assert(!plan.Dimensions.Contains(rightOs30),
				"right OutlineSegment 30 must suppress as primary-structure duplicate");
			Assert(!plan.Dimensions.Contains(rightOs20),
				"right OutlineSegment 20 must suppress as overall residual");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.IsSuppressed
					&& c.SuppressedReason == "SecondaryOutlineSegmentDuplicatesPrimaryStructureHeight"),
				"expected SecondaryOutlineSegmentDuplicatesPrimaryStructureHeight reason");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.IsSuppressed
					&& c.SuppressedReason == "SecondaryOutlineSegmentOverallResidual"),
				"expected SecondaryOutlineSegmentOverallResidual reason");
		}

		/// <summary>
		/// Mirror of left-step case: primary RightStructHeight 50+30; left vertical OS 30/20 drop.
		/// </summary>
		private static void RightStepStructureHeightsPreferOverLeftOutlineSegments()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 100.0),
				DebugRole = "OverallHeight"
			});
			var right50 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 0.0),
				SecondPoint = new Point2D(100.0, 50.0),
				DebugRole = "RightStructHeight"
			};
			var right30 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 50.0),
				SecondPoint = new Point2D(100.0, 80.0),
				DebugRole = "RightStructHeight"
			};
			var leftOs30 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(50.0, 50.0),
				SecondPoint = new Point2D(50.0, 80.0),
				DebugRole = "OutlineSegment"
			};
			var leftOs20 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(20.0, 80.0),
				SecondPoint = new Point2D(20.0, 100.0),
				DebugRole = "OutlineSegment"
			};
			plan.Add(right50);
			plan.Add(right30);
			plan.Add(leftOs30);
			plan.Add(leftOs20);

			planner.SuppressSecondaryVerticalOutlineSegmentsRedundantWithPrimaryStructureStack(plan);

			Assert(plan.Dimensions.Contains(right50), "right structure height 50 must remain");
			Assert(plan.Dimensions.Contains(right30), "right structure height 30 must remain");
			Assert(!plan.Dimensions.Contains(leftOs30),
				"left OutlineSegment 30 must suppress as primary-structure duplicate");
			Assert(!plan.Dimensions.Contains(leftOs20),
				"left OutlineSegment 20 must suppress as overall residual");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.IsSuppressed
					&& c.SuppressedReason == "SecondaryOutlineSegmentDuplicatesPrimaryStructureHeight"),
				"expected SecondaryOutlineSegmentDuplicatesPrimaryStructureHeight reason");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c => c.IsSuppressed
					&& c.SuppressedReason == "SecondaryOutlineSegmentOverallResidual"),
				"expected SecondaryOutlineSegmentOverallResidual reason");
		}

        private static void HorizontalStructurePointsCreateStepHeights()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(10.0, 30.0), new Point2D(80.0, 30.0), "middle");
            AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(100.0, 50.0), "top");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(plan.Dimensions.Any(d =>
                    (d.DebugRole == "LeftStructHeight" || d.DebugRole == "RightStructHeight")
                    && d.Orientation == DimensionOrientation.Vertical
                    && Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 20.0) <= 0.001),
                "expected structure height from middle horizontal to top");
            Assert(!plan.Dimensions.Any(d =>
                    d.DebugRole == "LeftStructHeight"
                    && d.Orientation == DimensionOrientation.Vertical
                    && Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 30.0) <= 0.001),
                "left structure height should remove the longest extension candidate");
        }

        private static void DiagonalFragmentsDoNotCreateStructureDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 73.0,
                MaxY = 28.0
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 20.0), "left");
            AddSegment(outline, new Point2D(50.0, 0.0), new Point2D(50.0, 15.5), "right-step");
            AddSegment(outline, new Point2D(53.0, 28.0), new Point2D(73.0, 27.0), "top-fragment");
            AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(35.0, 20.0), "upper-left");
            AddSegment(outline, new Point2D(53.0, 28.0), new Point2D(73.0, 28.0), "upper-right");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(!plan.Dimensions.Any(d => d.DebugRole == "BottomStructWidth" && Math.Abs(GetSpan(d) - 3.0) <= 0.001),
                "small diagonal horizontal fragment should not create bottom structure width");
        }

        private static void BottomInclinedStructurePointsRequireInnerGrooveChamfer()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(0.0, 50.0), "left");
            AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 50.0), "right");
            AddSegment(outline, new Point2D(30.0, 10.0), new Point2D(40.0, 20.0), "inner-chamfer-left");
            AddSegment(outline, new Point2D(40.0, 20.0), new Point2D(60.0, 20.0), "inner-flat");
            AddSegment(outline, new Point2D(60.0, 20.0), new Point2D(70.0, 10.0), "inner-chamfer-right");
            AddSegment(outline, new Point2D(80.0, 5.0), new Point2D(90.0, 15.0), "isolated-slope");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(plan.Dimensions.Any(d =>
                    d.DebugRole == "BottomStructWidth"
                    && (EndpointXEquals(d, 30.0) || EndpointXEquals(d, 40.0) || EndpointXEquals(d, 60.0) || EndpointXEquals(d, 70.0))),
                "bottom inner groove chamfer endpoints should create bottom structure dimensions");
            Assert(!plan.Dimensions.Any(d =>
                    d.DebugRole == "BottomStructWidth"
                    && (EndpointXEquals(d, 80.0) || EndpointXEquals(d, 90.0))),
                "isolated 45-degree slope should not create bottom structure dimensions");
        }

        private static void SideInclinedStructurePointsRequireInnerGrooveChamfer()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var leftOutline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 100.0
            };

            AddSegment(leftOutline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(leftOutline, new Point2D(0.0, 100.0), new Point2D(100.0, 100.0), "top");
            AddSegment(leftOutline, new Point2D(20.0, 30.0), new Point2D(30.0, 40.0), "left-groove-chamfer-lower");
            AddSegment(leftOutline, new Point2D(30.0, 40.0), new Point2D(30.0, 60.0), "left-groove-vertical");
            AddSegment(leftOutline, new Point2D(30.0, 60.0), new Point2D(20.0, 70.0), "left-groove-chamfer-upper");
            AddSegment(leftOutline, new Point2D(50.0, 10.0), new Point2D(60.0, 20.0), "isolated-slope");

            var leftPlan = new DimensionPlanner(config).CreateOutlinePlan(leftOutline);

            Assert(leftPlan.Dimensions.Any(d =>
                    d.DebugRole == "LeftStructHeight"
                    && (EndpointYEquals(d, 30.0) || EndpointYEquals(d, 40.0) || EndpointYEquals(d, 60.0) || EndpointYEquals(d, 70.0))),
                "left inner groove chamfer endpoints should create side structure dimensions");

            var rightOutline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 100.0
            };

            AddSegment(rightOutline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(rightOutline, new Point2D(0.0, 100.0), new Point2D(100.0, 100.0), "top");
            AddSegment(rightOutline, new Point2D(80.0, 30.0), new Point2D(70.0, 40.0), "right-groove-chamfer-lower");
            AddSegment(rightOutline, new Point2D(70.0, 40.0), new Point2D(70.0, 60.0), "right-groove-vertical");
            AddSegment(rightOutline, new Point2D(70.0, 60.0), new Point2D(80.0, 70.0), "right-groove-chamfer-upper");
            AddSegment(rightOutline, new Point2D(50.0, 10.0), new Point2D(60.0, 20.0), "isolated-slope");

            var rightPlan = new DimensionPlanner(config).CreateOutlinePlan(rightOutline);

            Assert(rightPlan.Dimensions.Any(d =>
                    d.DebugRole == "RightStructHeight"
                    && (EndpointYEquals(d, 30.0) || EndpointYEquals(d, 40.0) || EndpointYEquals(d, 60.0) || EndpointYEquals(d, 70.0))),
                "right inner groove chamfer endpoints should create side structure dimensions");
            Assert(!leftPlan.Dimensions.Concat(rightPlan.Dimensions).Any(d =>
                    (d.DebugRole == "LeftStructHeight" || d.DebugRole == "RightStructHeight")
                    && (EndpointYEquals(d, 10.0) || EndpointYEquals(d, 20.0))),
                "isolated 45-degree slope should not create side structure dimensions");
        }


		/// <summary>
		/// Phase 2: Left structure height that restates OverallHeight must suppress (symmetric of right).
		/// </summary>
		private static void LeftStructureHeightDuplicatingOverallHeightIsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 73.0,
				MaxY = 29.038
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(73.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(0.0, 29.038), new Point2D(73.0, 29.038), "top");
			AddSegment(outline, new Point2D(23.0, 0.0), new Point2D(23.0, 15.5), "left-lower-step");
			AddSegment(outline, new Point2D(0.0, 29.038), new Point2D(0.5, 29.038), "left-top-step");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight),
				"overall height should remain");
			Assert(!plan.Dimensions.Any(d =>
					d.DebugRole == "LeftStructHeight"
					&& Math.Abs(GetSpan(d) - 29.038) <= 0.001),
				"left structure height duplicating overall height should be suppressed");
		}

		/// <summary>
		/// Phase 2: left structure complementary pair — larger remainder (~80 with short 20)
		/// removed at candidate build (same as right RemoveComplementaryOverallRemainderCandidates).
		/// </summary>
		private static void LeftStructureComplementaryRemainderIsRemovedLikeRight()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D { MinX = 0.0, MinY = 0.0, MaxX = 40.0, MaxY = 100.0 };
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(40.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(40.0, 0.0), new Point2D(40.0, 100.0), "right");
			AddSegment(outline, new Point2D(40.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");
			AddSegment(outline, new Point2D(0.0, 20.0), new Point2D(15.0, 20.0), "left-shoulder");

			var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);
			Assert(!plan.Dimensions.Any(d =>
					d.DebugRole == "LeftStructHeight"
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 80.0) <= config.GeometryTolerance),
				"left complementary remainder height ~80 must be removed like right-side path");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 100.0) <= config.GeometryTolerance),
				"overall height 100 must remain");
		}

        private static void RightStructureHeightDuplicatingOverallHeightIsSuppressed()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 73.0,
                MaxY = 29.038
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(73.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(0.0, 29.038), new Point2D(73.0, 29.038), "top");
            AddSegment(outline, new Point2D(50.0, 0.0), new Point2D(50.0, 15.5), "right-lower-step");
            AddSegment(outline, new Point2D(72.5, 29.038), new Point2D(73.0, 29.038), "right-top-step");

            var plan = new DimensionPlanner(config).CreateOutlinePlan(outline);

            Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight),
                "overall height should remain");
            Assert(!plan.Dimensions.Any(d =>
                    d.DebugRole == "RightStructHeight"
                    && Math.Abs(GetSpan(d) - 29.038) <= 0.001),
                "right structure height duplicating overall height should be suppressed");
        }


		/// <summary>
		/// 180°-style bottom closed chain: 75 on MinX + 50 interior + 90 on MaxX.
		/// No-datum rule keeps shorter end 75 (not MaxX 90).
		/// </summary>
		private static void BottomClosedChainFlippedKeepsShorterEnd75Drops90()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				ForceOuterLevel = true,
				DebugRole = "OverallWidth"
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(75.0, 0.0),
				DebugRole = "BottomStructWidth",
				Role = DimensionCandidateRole.Structure
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(75.0, 0.0),
				SecondPoint = new Point2D(125.0, 0.0),
				DebugRole = "BottomStructWidth",
				Role = DimensionCandidateRole.Structure
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(125.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				DebugRole = "BottomStructWidth",
				Role = DimensionCandidateRole.Structure
			});

			new DimensionPlanner(config).SuppressTopStructureClosedChainRedundantPositioning(plan, outline);

			var bottom = plan.Dimensions.Where(d => d.DebugRole == "BottomStructWidth").ToList();
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 50.0) <= config.GeometryTolerance),
				"feature 50 must remain");
			Assert(bottom.Any(d => Math.Abs(GetSpan(d) - 75.0) <= config.GeometryTolerance),
				"shorter end 75 must remain after 180° flip");
			Assert(!bottom.Any(d => Math.Abs(GetSpan(d) - 90.0) <= config.GeometryTolerance),
				"longer end 90 must be suppressed after 180° flip");
		}

		/// <summary>
		/// 180° 215 part: top major 120 + disconnected 87 → drop 87.
		/// </summary>
		private static void TopDisconnectedSecondary87WithMajor120IsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallWidth,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Bottom,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(215.0, 0.0),
				ForceOuterLevel = true,
				DebugRole = "OverallWidth",
				Role = DimensionCandidateRole.Overall
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(0.0, 100.0),
				SecondPoint = new Point2D(120.0, 100.0),
				DebugRole = "TopStructWidth",
				Role = DimensionCandidateRole.Structure
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(128.0, 100.0),
				SecondPoint = new Point2D(215.0, 100.0),
				DebugRole = "TopStructWidth",
				Role = DimensionCandidateRole.Structure
			});

			new DimensionPlanner(config).SuppressDisconnectedSecondaryStructure(plan, outline);

			Assert(plan.Dimensions.Any(d => d.DebugRole == "TopStructWidth"
					&& Math.Abs(GetSpan(d) - 120.0) <= config.GeometryTolerance),
				"major top 120 must remain");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "TopStructWidth"
					&& Math.Abs(GetSpan(d) - 87.0) <= config.GeometryTolerance),
				"disconnected secondary 87 must be suppressed");
		}

		/// <summary>
		/// 90°/270° of the 215 notch part: top 50+75 become left/right heights and must stay
		/// (not cover-killed by opposite major body; closed chain drops longer 90 body).
		/// </summary>
		private static void Rotated215Notch50And75SurviveOnLeftAndRight()
		{
			var config = DimensionRuleConfig.CreateDefault();
			OutlineFeature2D Build0()
			{
				var o = new OutlineFeature2D { MinX = 0, MinY = 0, MaxX = 215, MaxY = 100 };
				AddSegment(o, new Point2D(0, 0), new Point2D(95, 0), "b1");
				AddSegment(o, new Point2D(95, 0), new Point2D(215, 0), "b120");
				AddSegment(o, new Point2D(215, 0), new Point2D(215, 100), "right");
				AddSegment(o, new Point2D(215, 100), new Point2D(140, 100), "t75");
				AddSegment(o, new Point2D(140, 100), new Point2D(140, 90), "nr");
				AddSegment(o, new Point2D(140, 90), new Point2D(90, 90), "n50");
				AddSegment(o, new Point2D(90, 90), new Point2D(90, 100), "nl");
				AddSegment(o, new Point2D(90, 100), new Point2D(10, 100), "tl");
				AddSegment(o, new Point2D(10, 100), new Point2D(0, 90), "ch");
				AddSegment(o, new Point2D(0, 90), new Point2D(0, 58), "lu");
				AddSegment(o, new Point2D(0, 58), new Point2D(95, 58), "pt");
				AddSegment(o, new Point2D(95, 58), new Point2D(95, 0), "pr");
				return o;
			}
			OutlineFeature2D Rot(OutlineFeature2D src, double deg)
			{
				double a = deg * Math.PI / 180.0, c = Math.Cos(a), sn = Math.Sin(a);
				var t = new OutlineFeature2D();
				foreach (var seg in src.Segments)
				{
					t.Segments.Add(new Segment2D(
						new Point2D(c * seg.Start.X - sn * seg.Start.Y, sn * seg.Start.X + c * seg.Start.Y),
						new Point2D(c * seg.End.X - sn * seg.End.Y, sn * seg.End.X + c * seg.End.Y))
					{ SourceKey = seg.SourceKey });
				}
				var pts = t.Segments.SelectMany(sg => new[] { sg.Start, sg.End }).ToList();
				t.MinX = pts.Min(p => p.X);
				t.MaxX = pts.Max(p => p.X);
				t.MinY = pts.Min(p => p.Y);
				t.MaxY = pts.Max(p => p.Y);
				return t;
			}
			var planner = new DimensionPlanner(config);
			var plan90 = planner.CreateOutlinePlan(Rot(Build0(), 90));
			var left = plan90.Dimensions.Where(d => d.DebugRole == "LeftStructHeight").ToList();
			Assert(left.Any(d => Math.Abs(GetSpan(d) - 50.0) <= 1.0),
				"90° must keep left ~50; left=[" + string.Join(",", left.Select(d => Math.Round(GetSpan(d), 1))) + "]");
			Assert(left.Any(d => Math.Abs(GetSpan(d) - 75.0) <= 1.0),
				"90° must keep left ~75 (not cover-killed); left=[" + string.Join(",", left.Select(d => Math.Round(GetSpan(d), 1))) + "]");
			Assert(!left.Any(d => Math.Abs(GetSpan(d) - 90.0) <= 1.0),
				"90° must drop left body ~90; left=[" + string.Join(",", left.Select(d => Math.Round(GetSpan(d), 1))) + "]");

			var plan270 = planner.CreateOutlinePlan(Rot(Build0(), 270));
			var right = plan270.Dimensions.Where(d => d.DebugRole == "RightStructHeight").ToList();
			Assert(right.Any(d => Math.Abs(GetSpan(d) - 50.0) <= 1.0),
				"270° must keep right ~50; right=[" + string.Join(",", right.Select(d => Math.Round(GetSpan(d), 1))) + "]");
			Assert(right.Any(d => Math.Abs(GetSpan(d) - 75.0) <= 1.0),
				"270° must keep right ~75; right=[" + string.Join(",", right.Select(d => Math.Round(GetSpan(d), 1))) + "]");
		}

		/// <summary>
		/// 270° 215 part: left major 120 + lone right 72 residual → drop 72; keep short tip 42.
		/// </summary>
		private static void RightResidual72WithLeftMajor120IsSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 215.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 215.0), "right");
			AddSegment(outline, new Point2D(100.0, 215.0), new Point2D(0.0, 215.0), "top");
			AddSegment(outline, new Point2D(0.0, 215.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 215.0),
				ForceOuterLevel = true,
				DebugRole = "OverallHeight",
				Role = DimensionCandidateRole.Overall
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 120.0),
				DebugRole = "LeftStructHeight",
				Role = DimensionCandidateRole.Structure
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 0.0),
				SecondPoint = new Point2D(100.0, 72.0),
				DebugRole = "RightStructHeight",
				Role = DimensionCandidateRole.Structure
			});

			new DimensionPlanner(config).SuppressOppositeMajorResidualSideHeights(plan, outline);

			Assert(plan.Dimensions.Any(d => d.DebugRole == "LeftStructHeight"
					&& Math.Abs(GetSpan(d) - 120.0) <= config.GeometryTolerance),
				"left major 120 must remain");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "RightStructHeight"),
				"right residual 72 must be suppressed");
		}

		/// <summary>
		/// Rotated 215 part right side 56+72: chain &lt; overall, max 72 just over old 30% floor —
		/// must be orphan tips, not kept as multi-piece "real steps".
		/// </summary>
		private static void RightSplitHeights56And72AreOrphanTipsOn215()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 215.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 215.0), "right");
			AddSegment(outline, new Point2D(100.0, 215.0), new Point2D(0.0, 215.0), "top");
			AddSegment(outline, new Point2D(0.0, 215.0), new Point2D(0.0, 0.0), "left");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 215.0),
				ForceOuterLevel = true,
				DebugRole = "OverallHeight",
				Role = DimensionCandidateRole.Overall
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 0.0),
				SecondPoint = new Point2D(100.0, 72.0),
				DebugRole = "RightStructHeight",
				Role = DimensionCandidateRole.Structure
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(100.0, 72.0),
				SecondPoint = new Point2D(100.0, 128.0),
				DebugRole = "RightStructHeight",
				Role = DimensionCandidateRole.Structure
			});

			new DimensionPlanner(config).SuppressOrphanOuterVerticalStructureHeightTips(plan, outline);

			Assert(!plan.Dimensions.Any(d => d.DebugRole == "RightStructHeight"),
				"56+72-class right split heights must be suppressed as orphan tips on overall 215");
		}

		/// <summary>
		/// last-run top 8: ΔX=8 ΔY=100 — pure cross-axis, must not pass top candidate filter.
		/// </summary>
		private static void TopCrossAxisStructWidth8IsRejected()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 215.0,
				MaxY = 100.0
			};
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(215.0, 0.0), "bottom");
			AddSegment(outline, new Point2D(215.0, 0.0), new Point2D(215.0, 100.0), "right");
			AddSegment(outline, new Point2D(215.0, 100.0), new Point2D(0.0, 100.0), "top");
			AddSegment(outline, new Point2D(0.0, 100.0), new Point2D(0.0, 0.0), "left");
			var rules = new StructureEndpointRules(config);
			var crossAxis = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Horizontal,
				Side = DimensionSide.Top,
				FirstPoint = new Point2D(120.0, 0.0),
				SecondPoint = new Point2D(128.0, 100.0),
				DebugRole = "TopStructWidth"
			};
			Assert(!rules.IsTopSideHorizontalStructureCandidate(crossAxis, outline, new List<Point2D>()),
				"cross-axis TopStructWidth ΔX=8 ΔY=100 must fail IsTopSideHorizontalStructureCandidate");
		}

		/// <summary>
		/// last-run left/tall orientation: abutting left steps 73+92.55≈165.5 are just under
		/// 50% of overall 338 and were wiped as OrphanOuterVerticalStructureHeightTip.
		/// Multi-piece real steps (each ≥15% overall) must survive.
		/// </summary>
		private static void LeftMultiPieceStepsSurviveOrphanTipOnTallOverall()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 201.5,
				MaxY = 338.0
			};
			// Simplified tall-L: left multi-step riser chain 0-73-165.55 plus overall 338.
			AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(20.0, 0.0), "foot");
			AddSegment(outline, new Point2D(20.0, 0.0), new Point2D(20.0, 73.0), "left-step-73");
			AddSegment(outline, new Point2D(20.0, 73.0), new Point2D(100.0, 73.0), "ledge");
			AddSegment(outline, new Point2D(100.0, 73.0), new Point2D(100.0, 165.55), "left-step-92");
			AddSegment(outline, new Point2D(100.0, 165.55), new Point2D(101.5, 165.55), "notch");
			AddSegment(outline, new Point2D(101.5, 165.55), new Point2D(101.5, 338.0), "left-upper");
			AddSegment(outline, new Point2D(101.5, 338.0), new Point2D(201.5, 338.0), "top");
			AddSegment(outline, new Point2D(201.5, 338.0), new Point2D(201.5, 0.0), "right");
			AddSegment(outline, new Point2D(201.5, 0.0), new Point2D(20.0, 0.0), "bottom-close");

			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 338.0),
				ForceOuterLevel = true,
				DebugRole = "OverallHeight",
				Role = DimensionCandidateRole.Overall
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(10.0, 73.0),
				DebugRole = "LeftStructHeight",
				Role = DimensionCandidateRole.Structure
			});
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(10.0, 73.0),
				SecondPoint = new Point2D(101.5, 165.55),
				DebugRole = "LeftStructHeight",
				Role = DimensionCandidateRole.Structure
			});

			new DimensionPlanner(config).SuppressOrphanOuterVerticalStructureHeightTips(plan, outline);

			var left = plan.Dimensions.Where(d => d.DebugRole == "LeftStructHeight").ToList();
			Assert(left.Any(d => Math.Abs(GetSpan(d) - 73.0) <= config.GeometryTolerance),
				"left step 73 must survive orphan-tip on tall overall");
			Assert(left.Any(d => Math.Abs(GetSpan(d) - 92.55) <= config.GeometryTolerance),
				"left step ~92.55 must survive orphan-tip on tall overall");
		}

		/// <summary>
		/// A short structure height is not orphan noise when an actual partial-envelope segment
		/// backs it. Regression: real left-top step 20 on overall height 201.5 was lost.
		/// </summary>
		private static void PartialEnvelopeStructureHeightSurvivesOrphanTipSuppression()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 338.0,
				MaxY = 201.5
			};
			AddSegment(outline, new Point2D(0.0, 181.5), new Point2D(0.0, 201.5), "real-left-top-step");
			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(38.0, 0.0),
				SecondPoint = new Point2D(0.0, 201.5),
				DebugRole = "OverallHeight"
			});
			var left20 = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 181.5),
				SecondPoint = new Point2D(0.0, 201.5),
				DebugRole = "LeftStructHeight"
			};
			plan.Add(left20);

			planner.SuppressOrphanOuterVerticalStructureHeightTips(plan, outline);

			Assert(plan.Dimensions.Contains(left20),
				"real 20-high step on a partial MinX envelope edge must survive orphan-tip suppression");
			Assert(!plan.Diagnostics.DimensionCandidates.Any(candidate => candidate.Id == left20.DiagnosticId
					&& candidate.SuppressedReason == "OrphanOuterVerticalStructureHeightTip"),
				"protected real partial-envelope step must not record orphan-tip suppression");
		}

		/// <summary>
		/// Two short RightStructHeight tips (5+5 on overall 45) are overall residual noise and
		/// must suppress (regression: structure&gt;OS mirror had kept them).
		/// </summary>
		private static void OrphanRightOuterStructureHeightTipsAreSuppressed()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var planner = new DimensionPlanner(config);
			var plan = new DimensionPlan();
			plan.Add(new PlannedDimension
			{
				Kind = DimensionKind.OverallHeight,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Left,
				FirstPoint = new Point2D(0.0, 0.0),
				SecondPoint = new Point2D(0.0, 45.0),
				DebugRole = "OverallHeight"
			});
			var r5a = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(40.0, 35.0),
				SecondPoint = new Point2D(40.0, 40.0),
				DebugRole = "RightStructHeight"
			};
			var r5b = new PlannedDimension
			{
				Kind = DimensionKind.Normal,
				Orientation = DimensionOrientation.Vertical,
				Side = DimensionSide.Right,
				FirstPoint = new Point2D(40.0, 30.0),
				SecondPoint = new Point2D(40.0, 35.0),
				DebugRole = "RightStructHeight"
			};
			plan.Add(r5a);
			plan.Add(r5b);
			planner.SuppressOrphanOuterVerticalStructureHeightTips(plan);
			Assert(!plan.Dimensions.Contains(r5a) && !plan.Dimensions.Contains(r5b),
				"orphan right outer structure height tips 5+5 must be suppressed");
			Assert(plan.Diagnostics.DimensionCandidates.Any(c =>
					c.DebugRole == "RightStructHeight"
					&& c.IsSuppressed
					&& c.SuppressedReason == "OrphanOuterVerticalStructureHeightTip"),
				"expected OrphanOuterVerticalStructureHeightTip reason");
		}

        private static void TwoArcSlotIsRecognized()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var geometry = new DrawingGeometry();
            geometry.Arcs.Add(new Arc2D
            {
                SourceKey = "a1",
                Center = new Point2D(20.0, 10.0),
                Start = new Point2D(20.0, 5.0),
                End = new Point2D(20.0, 15.0),
                Radius = 5.0,
                Bulge = -1.0
            });
            geometry.Arcs.Add(new Arc2D
            {
                SourceKey = "a2",
                Center = new Point2D(60.0, 10.0),
                Start = new Point2D(60.0, 15.0),
                End = new Point2D(60.0, 5.0),
                Radius = 5.0,
                Bulge = -1.0
            });
            geometry.Segments.Add(new Segment2D(new Point2D(20.0, 15.0), new Point2D(60.0, 15.0)) { SourceKey = "l1" });
            geometry.Segments.Add(new Segment2D(new Point2D(20.0, 5.0), new Point2D(60.0, 5.0)) { SourceKey = "l2" });

            var slots = new FeatureRecognizer2D(config).RecognizeSlotFeatures(geometry);

            Assert(slots.Count == 1, "expected one two-arc slot");
            Assert(!slots[0].IsSingleArcSlot, "two-arc slot should not be single-arc");
            Assert(!slots[0].IsVertical, "two-arc horizontal slot should be horizontal");
            Assert(Math.Abs(slots[0].CenterDistance - 40.0) <= 0.001, "two-arc slot center distance should be recognized");
        }

        private static void SingleArcSlotIsRecognized()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var geometry = new DrawingGeometry();
            geometry.Arcs.Add(new Arc2D
            {
                SourceKey = "a1",
                Center = new Point2D(20.0, 20.0),
                Start = new Point2D(20.0, 15.0),
                End = new Point2D(20.0, 25.0),
                Radius = 5.0,
                Bulge = -1.0
            });
            geometry.Segments.Add(new Segment2D(new Point2D(20.0, 15.0), new Point2D(40.0, 15.0)) { SourceKey = "l1" });
            geometry.Segments.Add(new Segment2D(new Point2D(20.0, 25.0), new Point2D(40.0, 25.0)) { SourceKey = "l2" });

            var slots = new FeatureRecognizer2D(config).RecognizeSlotFeatures(geometry);

            Assert(slots.Count == 1, "expected one single-arc U slot");
            Assert(slots[0].IsSingleArcSlot, "single-arc U slot should be marked");
            Assert(!slots[0].IsVertical, "single-arc horizontal U slot should be horizontal");
            Assert(Math.Abs(slots[0].Radius - 5.0) <= 0.001, "single-arc slot radius should be preserved");
        }

        private static void SlotDimensionsUseCenterAndDatumChainsWithoutPins()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(100.0, 50.0);
            var datum = Datum2D.FromOutline(outline);
            var slots = new[]
            {
                new SlotFeature2D
                {
                    GroupId = "SLOT1",
                    FirstCenter = new Point2D(20.0, 20.0),
                    SecondCenter = new Point2D(60.0, 20.0),
                    Radius = 5.0,
                    CenterDistance = 40.0
                },
                new SlotFeature2D
                {
                    GroupId = "SLOT2",
                    FirstCenter = new Point2D(80.0, 30.0),
                    SecondCenter = new Point2D(80.0, 40.0),
                    Radius = 5.0,
                    CenterDistance = 10.0,
                    IsVertical = true
                }
            };

            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new HoleFeature2D[0], slots);

            Assert(plan.Dimensions.Any(d => d.DebugRole == "SlotCenter" && Math.Abs(GetSpan(d) - 40.0) <= 0.001),
                "horizontal slot center distance should be planned");
            Assert(plan.Dimensions.Any(d => d.DebugRole == "SlotCenter" && Math.Abs(GetSpan(d) - 10.0) <= 0.001),
                "vertical slot center distance should be planned");
			var horizontalCenter = plan.Dimensions.Single(d => d.DebugRole == "SlotCenter" && Math.Abs(GetSpan(d) - 40.0) <= 0.001);
			Assert(horizontalCenter.Side == DimensionSide.Bottom
				&& Math.Abs(horizontalCenter.FirstPoint.Y - 15.0) <= 0.001
				&& Math.Abs(horizontalCenter.SecondPoint.Y - 15.0) <= 0.001,
				"horizontal slot center distance should use the nearest real arc-line grips");
			var verticalCenter = plan.Dimensions.Single(d => d.DebugRole == "SlotCenter" && Math.Abs(GetSpan(d) - 10.0) <= 0.001);
			Assert(verticalCenter.Side == DimensionSide.Right
				&& Math.Abs(verticalCenter.FirstPoint.X - 85.0) <= 0.001
				&& Math.Abs(verticalCenter.SecondPoint.X - 85.0) <= 0.001,
				"vertical slot center distance should use the nearest real arc-line grips");
            Assert(plan.Dimensions.Any(d => d.DebugRole == "SlotDatumH"),
                "horizontal slot datum location should be planned without pins");
            Assert(plan.Dimensions.Any(d => d.DebugRole == "SlotDatumV"),
                "vertical slot datum location should be planned without pins");
            Assert(plan.Dimensions.Any(d => d.DebugRole == "SlotChainH" || d.DebugRole == "SlotChainV"),
                "slot datum chain dimensions should be planned without pins");
        }

        private static void HolesAreGroupedByHorizontalRows()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var planner = new DimensionPlanner(config);
            var rows = planner.GroupHolesByHorizontalRow(new[]
            {
                CreateHole(30.0, 20.0, 8.0, HoleKind2D.Normal),
                CreateHole(10.0, 10.0, 8.0, HoleKind2D.Normal),
                CreateHole(20.0, 10.0, 8.0, HoleKind2D.Normal)
            });

            Assert(rows.Count == 2, "expected two horizontal hole rows");
            Assert(rows[0].Count == 2, "first row should contain two holes");
            Assert(Math.Abs(rows[0][0].Center.X - 10.0) <= 0.001, "row holes should be sorted by X");
        }

        private static void NormalHolesLocateFromOutlineDatum()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(100.0, 50.0);
            var datum = Datum2D.FromOutline(outline);
            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
            {
                CreateHole(25.0, 20.0, 8.0, HoleKind2D.Normal)
            });

            Assert(plan.Dimensions.Count(d => d.Kind == DimensionKind.HoleLocation) == 2,
                "normal hole should create horizontal and vertical location dimensions");
            Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.HoleLocation && d.Orientation == DimensionOrientation.Horizontal && d.Side == DimensionSide.Bottom),
                "normal hole horizontal location should use nearest horizontal side");
            Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.HoleLocation && d.Orientation == DimensionOrientation.Vertical && d.Side == DimensionSide.Left),
                "normal hole vertical location should use nearest vertical side");
        }

		private static void CenterlineEndpointIsAllowedForHolePositioning()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var datum = Datum2D.FromOutline(outline);
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D
			{
				Point = new Point2D(25.0005, 20.0005),
				SourceGeometryId = "CENTER-TEST"
			});
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				CreateHole(25.0, 20.0, 8.0, HoleKind2D.Normal)
			});

			var holeDimensions = plan.Dimensions.Where(d => d.DebugRole == "HoleDatumX" || d.DebugRole == "HoleDatumY").ToList();
			Assert(holeDimensions.Count == 2 && holeDimensions.All(d => d.SecondPoint.Equals(new Point2D(25.02, 20.02))),
				"hole positioning may use a selected centerline endpoint");
		Assert(plan.Diagnostics.DimensionCandidates.Where(d => d.DebugRole == "HoleDatumX" || d.DebugRole == "HoleDatumY")
			.All(d => d.TopologyEvidence.IndexOf("CenterlineEndpoint|Status=Applied", StringComparison.Ordinal) >= 0
				&& d.AttachmentKind == "SelectedCenterlineEndpoint"
				&& d.SourceGeometryIds.Contains("CENTER-TEST")),
			"centerline endpoint use must be visible in diagnostics");
			Assert(plan.Diagnostics.DimensionCandidates.Where(d => d.Kind == DimensionKind.OverallWidth.ToString() || d.Kind == DimensionKind.OverallHeight.ToString())
				.All(d => d.TopologyEvidence.IndexOf("CenterlineEndpoint", StringComparison.Ordinal) < 0),
				"centerline endpoints must not affect overall dimensions");
		}

		private static void HoleAndPinChainsUseSideFacingCenterlineEndpoints()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 100.0);
			var normalDatum = Datum2D.FromOutline(outline);
			AddCenterlineCross(normalDatum, new Point2D(20.0, 20.0), "N1");
			AddCenterlineCross(normalDatum, new Point2D(50.0, 40.0), "N2");
			var normalPlan = new DimensionPlanner(config).CreateDimensionPlan(outline, normalDatum, new[]
			{
				CreateHole(20.0, 20.0, 8.0, HoleKind2D.Normal),
				CreateHole(50.0, 40.0, 8.0, HoleKind2D.Normal)
			});
			var normalHorizontal = normalPlan.Dimensions.Where(d => d.DebugRole == "HoleDatumX" || d.DebugRole == "HoleChainH").ToList();
			var normalVertical = normalPlan.Dimensions.Where(d => d.DebugRole == "HoleDatumY" || d.DebugRole == "HoleChainV").ToList();
			Assert(normalHorizontal.Count == 2 && normalHorizontal.All(d => d.Side == DimensionSide.Bottom)
				&& normalHorizontal.Select(d => d.AlignmentKey).Distinct().Count() == 1
				&& normalHorizontal.Single(d => d.DebugRole == "HoleDatumX").FirstPoint.Equals(new Point2D(0.0, 0.0))
				&& normalHorizontal.Any(d => d.SecondPoint.Equals(new Point2D(20.0, 15.0)))
				&& normalHorizontal.Any(d => d.SecondPoint.Equals(new Point2D(50.0, 35.0))),
				"normal-hole horizontal location and center distance must share the bottom vertical-axis endpoints and rooted key");
			Assert(normalVertical.Count == 2 && normalVertical.All(d => d.Side == DimensionSide.Left)
				&& normalVertical.Select(d => d.AlignmentKey).Distinct().Count() == 1
				&& normalVertical.Single(d => d.DebugRole == "HoleDatumY").FirstPoint.Equals(new Point2D(0.0, 0.0))
				&& normalVertical.Any(d => d.SecondPoint.Equals(new Point2D(15.0, 20.0)))
				&& normalVertical.Any(d => d.SecondPoint.Equals(new Point2D(45.0, 40.0))),
				"normal-hole vertical location and center distance must share the left horizontal-axis endpoints and rooted key");
			var normalLayout = normalHorizontal.Select(d => new DimensionLayoutItem
			{
				Kind = d.Kind,
				FirstPoint = d.FirstPoint,
				SecondPoint = d.SecondPoint,
				Span = GetSpan(d),
				AlignmentKey = d.AlignmentKey,
				AlignmentPriority = d.AlignmentPriority,
				ReadingLevel = d.ReadingLevel
			}).ToList();
			var normalPlacements = new DimensionLayoutRules(config)
				.CreateStackingPlan(normalLayout, DimensionSide.Bottom, outline, 2.5, 1.25, 10.0, 6.5, isHorizontal: true);
			Assert(normalPlacements.All(p => p.Level == 0 && p.LayoutBlockType == "RootedAlignmentLane")
				&& normalPlacements.Select(p => p.LayoutBlockId).Distinct().Count() == 1,
				"normal-hole location must anchor its connected center distance in one nearest rooted block");

			var gridDatum = Datum2D.FromOutline(outline);
			var gridHoles = new[]
			{
				CreateHole(20.0, 20.0, 8.0, HoleKind2D.Normal),
				CreateHole(20.0, 40.0, 8.0, HoleKind2D.Normal),
				CreateHole(40.0, 20.0, 8.0, HoleKind2D.Normal),
				CreateHole(40.0, 40.0, 8.0, HoleKind2D.Normal)
			};
			foreach (HoleFeature2D hole in gridHoles)
			{
				AddCenterlineCross(gridDatum, hole.Center, "G" + hole.Center.X + ":" + hole.Center.Y);
			}
			var gridPlan = new DimensionPlanner(config).CreateDimensionPlan(outline, gridDatum, gridHoles);
			var gridHorizontal = gridPlan.Dimensions.Single(d => d.DebugRole == "HoleChainH");
			var gridVertical = gridPlan.Dimensions.Single(d => d.DebugRole == "HoleChainV");
			Assert(gridHorizontal.FirstPoint.Equals(new Point2D(20.0, 15.0))
				&& gridHorizontal.SecondPoint.Equals(new Point2D(40.0, 15.0))
				&& gridVertical.FirstPoint.Equals(new Point2D(15.0, 20.0))
				&& gridVertical.SecondPoint.Equals(new Point2D(15.0, 40.0)),
				"rectangular normal-hole grids must use the row and column facing their inherited layout sides");

			var pinDatum = Datum2D.FromOutline(outline);
			var datumPin = CreateHole(80.0, 80.0, 6.0, HoleKind2D.Pin);
			pinDatum.DatumHole = datumPin;
			var pins = new[]
			{
				datumPin,
				CreateHole(50.0, 80.0, 6.0, HoleKind2D.Pin),
				CreateHole(80.0, 30.0, 6.0, HoleKind2D.Pin),
				CreateHole(50.0, 30.0, 6.0, HoleKind2D.Pin)
			};
			foreach (HoleFeature2D pin in pins)
			{
				AddCenterlineCross(pinDatum, pin.Center, "P" + pin.Center.X + ":" + pin.Center.Y);
			}
			var pinPlan = new DimensionPlanner(config).CreateDimensionPlan(outline, pinDatum, pins);
			var horizontalPinChain = pinPlan.Dimensions.Where(d => d.Kind == DimensionKind.DatumHoleLocationX
				|| (d.Orientation == DimensionOrientation.Horizontal && (d.Kind == DimensionKind.PinDistance || d.Kind == DimensionKind.PinGroupDistance))).ToList();
			var verticalPinChain = pinPlan.Dimensions.Where(d => d.Kind == DimensionKind.DatumHoleLocationY
				|| (d.Orientation == DimensionOrientation.Vertical && (d.Kind == DimensionKind.PinDistance || d.Kind == DimensionKind.PinGroupDistance))).ToList();
			Assert(horizontalPinChain.All(d => d.Side == DimensionSide.Top && d.AttachmentKind == "SelectedCenterlineEndpoint")
				&& horizontalPinChain.Single(d => d.Kind == DimensionKind.DatumHoleLocationX).FirstPoint.Equals(new Point2D(0.0, 100.0))
				&& horizontalPinChain.Select(d => d.AlignmentKey).Distinct().Count() == 1,
				"pin horizontal distances must inherit the datum-pin top side and axis-endpoint chain");
			Assert(verticalPinChain.All(d => d.Side == DimensionSide.Right && d.AttachmentKind == "SelectedCenterlineEndpoint")
				&& verticalPinChain.Single(d => d.Kind == DimensionKind.DatumHoleLocationY).FirstPoint.Equals(new Point2D(100.0, 0.0))
				&& verticalPinChain.Select(d => d.AlignmentKey).Distinct().Count() == 1,
				"pin vertical distances must inherit the datum-pin right side and axis-endpoint chain");

			var fallbackPlan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new[]
			{
				CreateHole(25.0, 20.0, 8.0, HoleKind2D.Normal)
			});
			Assert(fallbackPlan.Dimensions.Where(d => d.DebugRole == "HoleDatumX" || d.DebugRole == "HoleDatumY")
				.All(d => d.SecondPoint.Equals(new Point2D(25.0, 20.0))
					&& d.TopologyEvidence.IndexOf("Status=NoEndpoint", StringComparison.Ordinal) >= 0),
				"missing centerline evidence must retain the hole center and record NoEndpoint");
		}

		private static void AddCenterlineCross(Datum2D datum, Point2D center, string sourceId)
		{
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(center.X, center.Y - 5.0), SourceGeometryId = sourceId + ":V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(center.X, center.Y + 5.0), SourceGeometryId = sourceId + ":V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(center.X - 5.0, center.Y), SourceGeometryId = sourceId + ":H" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(center.X + 5.0, center.Y), SourceGeometryId = sourceId + ":H" });
		}

		private static void OffsetColumnDoesNotStealLowerHoleCenterline()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 80.0);
			var datum = Datum2D.FromOutline(outline);
			AddCenterlineCross(datum, new Point2D(25.0, 25.0), "UPPER");
			AddCenterlineCross(datum, new Point2D(26.0, 10.0), "LOWER");
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				CreateHole(25.0, 25.0, 8.0, HoleKind2D.Normal)
			});
			var horizontal = plan.Dimensions.Single(d => d.DebugRole == "HoleDatumX");
			Assert(horizontal.Side == DimensionSide.Bottom && horizontal.SecondPoint.Equals(new Point2D(25.0, 20.0)),
				"a 1mm column offset is not coaxial, so the bottom grip stays on this hole's centerline");
		}

		private static void PinGroupBasePinLocatesHolesAs14And16()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 80.0);
			var pinA = CreateHole(50.0, 20.0, 6.0, HoleKind2D.Pin);
			var pinB = CreateHole(50.0, 50.0, 6.0, HoleKind2D.Pin);
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = pinA;
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				pinA,
				pinB,
				CreateHole(36.0, 35.0, 8.0, HoleKind2D.Thread),
				CreateHole(66.0, 35.0, 8.0, HoleKind2D.Thread)
			});
			var horizontal = plan.Dimensions.Where(d => d.Orientation == DimensionOrientation.Horizontal
				&& (d.DebugRole == "LooseHole" || d.DebugRole == "FunctionalHole")).ToList();
			Assert(horizontal.Any(d => Math.Abs(GetSpan(d) - 14.0) <= 0.001)
				&& horizontal.Any(d => Math.Abs(GetSpan(d) - 16.0) <= 0.001),
				"holes in a pin group must be located from the base pin as 14 and 16");
			Assert(!horizontal.Any(d => Math.Abs(GetSpan(d) - 15.0) <= 0.001),
				"pin-group holes must not be located by a 15 hole-to-hole chain");
		}

		private static void BottomHoleGripUsesLowerHoleCenterlineInColumn()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 80.0);
			var datum = Datum2D.FromOutline(outline);
			AddCenterlineCross(datum, new Point2D(25.0, 25.0), "UPPER");
			AddCenterlineCross(datum, new Point2D(25.0, 10.0), "LOWER");
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				CreateHole(25.0, 25.0, 8.0, HoleKind2D.Normal)
			});
			var horizontal = plan.Dimensions.Single(d => d.DebugRole == "HoleDatumX");
			Assert(horizontal.Side == DimensionSide.Bottom && horizontal.SecondPoint.Equals(new Point2D(25.0, 5.0)),
				"a bottom-placed hole dimension must take the lower hole's vertical centerline");
		}

		private static void TopLeftRightHoleGripsUsePlacementSideHoleCenterline()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var topOutline = CreateRectangle(100.0, 80.0);
			var topDatum = Datum2D.FromOutline(topOutline);
			AddCenterlineCross(topDatum, new Point2D(25.0, 50.0), "TOP-LOWER");
			AddCenterlineCross(topDatum, new Point2D(25.0, 65.0), "TOP-UPPER");
			var topPlan = new DimensionPlanner(config).CreateDimensionPlan(topOutline, topDatum, new[]
			{
				CreateHole(25.0, 50.0, 8.0, HoleKind2D.Normal)
			});
			var topHorizontal = topPlan.Dimensions.Single(d => d.DebugRole == "HoleDatumX");
			Assert(topHorizontal.Side == DimensionSide.Top && topHorizontal.SecondPoint.Equals(new Point2D(25.0, 70.0)),
				"a top-placed hole dimension must take the upper hole's vertical centerline");

			var leftOutline = CreateRectangle(100.0, 80.0);
			var leftDatum = Datum2D.FromOutline(leftOutline);
			AddCenterlineCross(leftDatum, new Point2D(25.0, 40.0), "LEFT-INNER");
			AddCenterlineCross(leftDatum, new Point2D(10.0, 40.0), "LEFT-OUTER");
			var leftPlan = new DimensionPlanner(config).CreateDimensionPlan(leftOutline, leftDatum, new[]
			{
				CreateHole(25.0, 40.0, 8.0, HoleKind2D.Normal)
			});
			var leftVertical = leftPlan.Dimensions.Single(d => d.DebugRole == "HoleDatumY");
			Assert(leftVertical.Side == DimensionSide.Left && leftVertical.SecondPoint.Equals(new Point2D(5.0, 40.0)),
				"a left-placed hole dimension must take the leftmost hole's horizontal centerline");

			var rightOutline = CreateRectangle(100.0, 80.0);
			var rightDatum = Datum2D.FromOutline(rightOutline);
			AddCenterlineCross(rightDatum, new Point2D(70.0, 40.0), "RIGHT-INNER");
			AddCenterlineCross(rightDatum, new Point2D(85.0, 40.0), "RIGHT-OUTER");
			var rightPlan = new DimensionPlanner(config).CreateDimensionPlan(rightOutline, rightDatum, new[]
			{
				CreateHole(70.0, 40.0, 8.0, HoleKind2D.Normal)
			});
			var rightVertical = rightPlan.Dimensions.Single(d => d.DebugRole == "HoleDatumY");
			Assert(rightVertical.Side == DimensionSide.Right && rightVertical.SecondPoint.Equals(new Point2D(90.0, 40.0)),
				"a right-placed hole dimension must take the rightmost hole's horizontal centerline");
		}

		private static void HoleGripUsesNearCenterlineStubNotFarAxisEnd()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 80.0);
			var datum = Datum2D.FromOutline(outline);
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 0.0), SourceGeometryId = "LONG-V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 80.0), SourceGeometryId = "LONG-V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 16.0), SourceGeometryId = "HOLE-V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 24.0), SourceGeometryId = "HOLE-V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(21.0, 20.0), SourceGeometryId = "HOLE-H" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(29.0, 20.0), SourceGeometryId = "HOLE-H" });
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
			{
				CreateHole(25.0, 20.0, 8.0, HoleKind2D.Normal)
			});
			var horizontal = plan.Dimensions.Single(d => d.DebugRole == "HoleDatumX");
			var vertical = plan.Dimensions.Single(d => d.DebugRole == "HoleDatumY");
			Assert(horizontal.Side == DimensionSide.Bottom && horizontal.SecondPoint.Equals(new Point2D(25.0, 16.0)),
				"a bottom hole grip must use the near vertical-centerline stub, not the far axis end");
			Assert(vertical.Side == DimensionSide.Left && vertical.SecondPoint.Equals(new Point2D(21.0, 20.0)),
				"a left hole grip must use the near horizontal-centerline stub, not the far axis end");
		}

		private static void SingleArcSlotDatumUsesBottomCenterlineEndpoint()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var datum = Datum2D.FromOutline(outline);
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 25.0), SourceGeometryId = "SLOT-CENTER" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 15.0), SourceGeometryId = "SLOT-CENTER" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(15.0, 20.0), SourceGeometryId = "SLOT-HORIZONTAL-CENTER" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 20.0), SourceGeometryId = "SLOT-HORIZONTAL-CENTER" });
			var slot = new SlotFeature2D
			{
				GroupId = "SINGLE-ARC-SLOT",
				FirstCenter = new Point2D(20.0, 20.0),
				SecondCenter = new Point2D(20.0, 20.0),
				Radius = 5.0,
				IsSingleArcSlot = true
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new HoleFeature2D[0], new[] { slot });
			var dimension = plan.Dimensions.Single(d => d.DebugRole == "SingleArcSlotDatum");

			Assert(dimension.Side == DimensionSide.Bottom
				&& dimension.FirstPoint.Equals(new Point2D(0.0, 0.0))
				&& dimension.SecondPoint.Equals(new Point2D(20.0, 15.0)),
				"bottom single-arc slot datum must use the lower vertical centerline endpoint");
			Assert(dimension.AttachmentKind == "SelectedCenterlineEndpoint"
				&& dimension.TopologyEvidence.IndexOf("Mode=VerticalAxisEndpointByPlacementSide", StringComparison.Ordinal) >= 0,
				"single-arc slot centerline endpoint selection must be visible in diagnostics");
			var verticalDimension = plan.Dimensions.Single(d => d.DebugRole == "SingleArcSlotVerticalDatum");
			Assert(verticalDimension.Side == DimensionSide.Left
				&& verticalDimension.FirstPoint.Equals(new Point2D(0.0, 0.0))
				&& verticalDimension.SecondPoint.Equals(new Point2D(15.0, 20.0))
				&& verticalDimension.TopologyEvidence.IndexOf("Mode=HorizontalAxisEndpointByPlacementSide", StringComparison.Ordinal) >= 0,
				"left single-arc slot vertical datum must use the left horizontal centerline endpoint");

			var topDatum = Datum2D.FromOutline(outline);
			topDatum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 45.0), SourceGeometryId = "TOP-SLOT-CENTER" });
			topDatum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 35.0), SourceGeometryId = "TOP-SLOT-CENTER" });
			slot.FirstCenter = new Point2D(20.0, 40.0);
			slot.SecondCenter = slot.FirstCenter;
			var topDimension = new DimensionPlanner(config)
				.CreateDimensionPlan(outline, topDatum, new HoleFeature2D[0], new[] { slot })
				.Dimensions.Single(d => d.DebugRole == "SingleArcSlotDatum");
			Assert(topDimension.Side == DimensionSide.Top
				&& topDimension.FirstPoint.Equals(new Point2D(0.0, 50.0))
				&& topDimension.SecondPoint.Equals(new Point2D(20.0, 45.0)),
				"top single-arc slot datum must use the upper vertical centerline endpoint");

			var rightDatum = Datum2D.FromOutline(outline);
			rightDatum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(75.0, 20.0), SourceGeometryId = "RIGHT-SLOT-CENTER" });
			rightDatum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(85.0, 20.0), SourceGeometryId = "RIGHT-SLOT-CENTER" });
			slot.FirstCenter = new Point2D(80.0, 20.0);
			slot.SecondCenter = slot.FirstCenter;
			var rightDimension = new DimensionPlanner(config)
				.CreateDimensionPlan(outline, rightDatum, new HoleFeature2D[0], new[] { slot })
				.Dimensions.Single(d => d.DebugRole == "SingleArcSlotVerticalDatum");
			Assert(rightDimension.Side == DimensionSide.Right
				&& rightDimension.FirstPoint.Equals(new Point2D(100.0, 0.0))
				&& rightDimension.SecondPoint.Equals(new Point2D(85.0, 20.0)),
				"right single-arc slot vertical datum must use the right horizontal centerline endpoint");
		}

		private static void DoubleArcSlotDatumUsesCenterlineAndOutlineEndpoints()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 50.0);
			var datum = Datum2D.FromOutline(outline);
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 15.0), SourceGeometryId = "DOUBLE-V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 25.0), SourceGeometryId = "DOUBLE-V" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(15.0, 20.0), SourceGeometryId = "DOUBLE-H" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 20.0), SourceGeometryId = "DOUBLE-H" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(15.0, 35.0), SourceGeometryId = "DOUBLE-H-2" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 35.0), SourceGeometryId = "DOUBLE-H-2" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 30.0), SourceGeometryId = "DOUBLE-V-2A" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(20.0, 40.0), SourceGeometryId = "DOUBLE-V-2A" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(40.0, 30.0), SourceGeometryId = "DOUBLE-V-2B" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(40.0, 40.0), SourceGeometryId = "DOUBLE-V-2B" });
			var slot = new SlotFeature2D
			{
				GroupId = "DOUBLE-ARC-SLOT",
				FirstCenter = new Point2D(40.0, 20.0),
				SecondCenter = new Point2D(20.0, 20.0),
				Radius = 5.0,
				CenterDistance = 20.0
			};

			var secondSlot = new SlotFeature2D
			{
				GroupId = "DOUBLE-ARC-SLOT-2",
				FirstCenter = new Point2D(40.0, 35.0),
				SecondCenter = new Point2D(20.0, 35.0),
				Radius = 5.0,
				CenterDistance = 20.0
			};
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new HoleFeature2D[0], new[] { slot, secondSlot });
			var horizontal = plan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotHorizontalDatum");
			var vertical = plan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotVerticalDatum");

			Assert(horizontal.Side == DimensionSide.Top
				&& horizontal.FirstPoint.Equals(new Point2D(0.0, 50.0))
				&& horizontal.SecondPoint.Equals(new Point2D(20.0, 40.0)),
				"double-arc horizontal location must use the nearest-side slot and top endpoints");
			Assert(vertical.Side == DimensionSide.Left
				&& vertical.FirstPoint.Equals(new Point2D(0.0, 50.0))
				&& vertical.SecondPoint.Equals(new Point2D(15.0, 35.0)),
				"double-arc vertical location must use the left horizontal centerline endpoint");
			var linkedCenterDistance = plan.Dimensions.Single(d => d.DebugRole == "SlotChainV");
			Assert(linkedCenterDistance.FirstPoint.Equals(new Point2D(15.0, 35.0))
				&& linkedCenterDistance.SecondPoint.Equals(new Point2D(15.0, 20.0)),
				"linked slot center distance must use centerline endpoints on the inherited side");
			var slotCenter = plan.Dimensions.Single(d => d.DebugRole == "SlotCenter");
			Assert(slotCenter.Side == DimensionSide.Top
				&& Math.Abs(slotCenter.FirstPoint.Y - 40.0) <= 0.001
				&& Math.Abs(slotCenter.SecondPoint.Y - 40.0) <= 0.001
				&& slotCenter.AlignmentKey == horizontal.AlignmentKey
				&& horizontal.AlignmentPriority > slotCenter.AlignmentPriority
				&& !horizontal.PreserveAlignmentLevel
				&& !slotCenter.PreserveAlignmentLevel,
				"slot center distance must inherit the connected datum side and axis endpoints");
			var topChain = new[] { horizontal, slotCenter }.Select(dimension => new DimensionLayoutItem
			{
				Kind = dimension.Kind,
				FirstPoint = dimension.FirstPoint,
				SecondPoint = dimension.SecondPoint,
				Span = GetSpan(dimension),
				AlignmentKey = dimension.AlignmentKey,
				AlignmentPriority = dimension.AlignmentPriority,
				PreserveAlignmentLevel = dimension.PreserveAlignmentLevel,
				ReadingLevel = dimension.ReadingLevel,
				SourceFeatureId = dimension.DebugOwner
			}).ToList();
			var placements = new DimensionLayoutRules(config)
				.CreateStackingPlan(topChain, DimensionSide.Top, outline, 2.5, 1.25, 10.0, 6.5, isHorizontal: true);
			Assert(placements.All(placement => placement.Level == 0
				&& placement.LayoutBlockType == "RootedAlignmentLane")
				&& placements.Select(placement => placement.LayoutBlockId).Distinct().Count() == 1,
				"linked top slot datum and center distance must form one nearest-level rooted layout block");

			var rightDatum = Datum2D.FromOutline(outline);
			foreach (var endpoint in new[]
			{
				new CenterlineEndpoint2D { Point = new Point2D(55.0, 20.0), SourceGeometryId = "RIGHT-1-L" },
				new CenterlineEndpoint2D { Point = new Point2D(65.0, 20.0), SourceGeometryId = "RIGHT-1-L" },
				new CenterlineEndpoint2D { Point = new Point2D(75.0, 20.0), SourceGeometryId = "RIGHT-1-R" },
				new CenterlineEndpoint2D { Point = new Point2D(85.0, 20.0), SourceGeometryId = "RIGHT-1-R" },
				new CenterlineEndpoint2D { Point = new Point2D(55.0, 35.0), SourceGeometryId = "RIGHT-2-L" },
				new CenterlineEndpoint2D { Point = new Point2D(65.0, 35.0), SourceGeometryId = "RIGHT-2-L" },
				new CenterlineEndpoint2D { Point = new Point2D(75.0, 35.0), SourceGeometryId = "RIGHT-2-R" },
				new CenterlineEndpoint2D { Point = new Point2D(85.0, 35.0), SourceGeometryId = "RIGHT-2-R" }
			})
			{
				rightDatum.HoleCenterlineEndpoints.Add(endpoint);
			}
			var rightSlots = new[]
			{
				new SlotFeature2D { GroupId = "RIGHT-1", FirstCenter = new Point2D(80.0, 20.0), SecondCenter = new Point2D(60.0, 20.0), Radius = 5.0, CenterDistance = 20.0 },
				new SlotFeature2D { GroupId = "RIGHT-2", FirstCenter = new Point2D(80.0, 35.0), SecondCenter = new Point2D(60.0, 35.0), Radius = 5.0, CenterDistance = 20.0 }
			};
			var rightPlan = new DimensionPlanner(config).CreateDimensionPlan(outline, rightDatum, new HoleFeature2D[0], rightSlots);
			var rightVertical = rightPlan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotVerticalDatum");
			var rightLinked = rightPlan.Dimensions.Single(d => d.DebugRole == "SlotChainV");
			Assert(rightVertical.SecondPoint.Equals(new Point2D(85.0, 35.0))
				&& rightLinked.FirstPoint.Equals(new Point2D(85.0, 35.0))
				&& rightLinked.SecondPoint.Equals(new Point2D(85.0, 20.0)),
				"right double-arc slot chain must use the outermost right centerline endpoints");
		}

		private static void MultipleSlotGroupsFormContinuousChains()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(100.0, 100.0);
			var datum = Datum2D.FromOutline(outline);
			var slots = new[]
			{
				new SlotFeature2D { GroupId = "VL-B", FirstCenter = new Point2D(20.0, 15.0), SecondCenter = new Point2D(20.0, 25.0), Radius = 5.0, CenterDistance = 10.0 },
				new SlotFeature2D { GroupId = "VL-T", FirstCenter = new Point2D(20.0, 35.0), SecondCenter = new Point2D(20.0, 45.0), Radius = 5.0, CenterDistance = 10.0 },
				new SlotFeature2D { GroupId = "VR-B", FirstCenter = new Point2D(60.0, 15.0), SecondCenter = new Point2D(60.0, 25.0), Radius = 5.0, CenterDistance = 10.0 },
				new SlotFeature2D { GroupId = "VR-T", FirstCenter = new Point2D(60.0, 35.0), SecondCenter = new Point2D(60.0, 45.0), Radius = 5.0, CenterDistance = 10.0 }
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new HoleFeature2D[0], slots);
			var verticalChain = plan.Dimensions.Single(d => d.DebugRole == "SlotChainV"
				&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 10.0) <= 0.001);
			Assert(verticalChain.FirstPoint.Equals(new Point2D(20.0, 25.0))
				&& verticalChain.SecondPoint.Equals(new Point2D(20.0, 35.0)),
				"multiple slot rows must emit the gap between facing slot endpoints");
			Assert(plan.Dimensions.Count(d => d.DebugRole == "SlotCenter"
				&& d.Orientation == DimensionOrientation.Vertical
				&& (d.DebugOwner == "VL-B" || d.DebugOwner == "VL-T")) == 2
				&& plan.Dimensions.Where(d => d.DebugRole == "SlotCenter"
					&& d.Orientation == DimensionOrientation.Vertical
					&& (d.DebugOwner == "VL-B" || d.DebugOwner == "VL-T"))
					.All(d => d.AlignmentKey == verticalChain.AlignmentKey),
				"slot-internal distances must join the same continuous chain lane");
			Assert(plan.Dimensions.Any(d => d.DebugRole == "DoubleArcSlotVerticalDatum"
				&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 15.0) <= 0.001)
				&& !plan.Dimensions.Any(d => d.DebugRole == "DoubleArcSlotVerticalDatum"
					&& Math.Abs(Math.Abs(d.SecondPoint.Y - d.FirstPoint.Y) - 35.0) <= 0.001),
				"the second row must not retain a redundant outline-to-row datum");
		}

		private static void ChamferSideSlotChainUsesChamferSideDatum()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateTopRightChamferedOutline();
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			var slots = new[]
			{
				new SlotFeature2D { GroupId = "CH-R1", FirstCenter = new Point2D(70.0, 10.0), SecondCenter = new Point2D(70.0, 20.0), Radius = 5.0, CenterDistance = 10.0 },
				new SlotFeature2D { GroupId = "CH-R2", FirstCenter = new Point2D(90.0, 10.0), SecondCenter = new Point2D(90.0, 20.0), Radius = 5.0, CenterDistance = 10.0 }
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new HoleFeature2D[0], slots);
			var datum = plan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotHorizontalDatum");
			var chain = plan.Dimensions.Single(d => d.DebugRole == "SlotChainH");

			Assert(datum.Side == DimensionSide.Top
				&& datum.FirstPoint.Equals(new Point2D(100.0, 40.0))
				&& datum.SecondPoint.Equals(new Point2D(90.0, 20.0))
				&& Math.Abs(GetSpan(datum) - 10.0) <= 0.001,
				"a top outer chamfer must drive the horizontal slot chain to the top side");
			Assert(chain.Side == DimensionSide.Top
				&& chain.FirstPoint.Equals(new Point2D(90.0, 20.0))
				&& chain.SecondPoint.Equals(new Point2D(70.0, 20.0))
				&& Math.Abs(GetSpan(chain) - 20.0) <= 0.001,
				"the slot chain must continue inward from the chamfer-side datum");
		}

		private static void LowerChamferSlotChainUsesBottomPlacement()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateBottomLeftChamferedOutline();
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			var slots = new[]
			{
				new SlotFeature2D { GroupId = "CH-B1", FirstCenter = new Point2D(70.0, 30.0), SecondCenter = new Point2D(70.0, 40.0), Radius = 5.0, CenterDistance = 10.0 },
				new SlotFeature2D { GroupId = "CH-B2", FirstCenter = new Point2D(90.0, 30.0), SecondCenter = new Point2D(90.0, 40.0), Radius = 5.0, CenterDistance = 10.0 }
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new HoleFeature2D[0], slots);
			var datum = plan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotHorizontalDatum");
			var chain = plan.Dimensions.Single(d => d.DebugRole == "SlotChainH");

			Assert(datum.Side == DimensionSide.Bottom
				&& datum.FirstPoint.Equals(new Point2D(0.0, 10.0))
				&& datum.SecondPoint.Equals(new Point2D(70.0, 30.0)),
				"a lower-left chamfer must drive horizontal slot location to the bottom side");
			Assert(chain.Side == DimensionSide.Bottom
				&& chain.FirstPoint.Equals(new Point2D(70.0, 30.0))
				&& chain.SecondPoint.Equals(new Point2D(90.0, 30.0)),
				"the lower chamfer slot chain must keep its bottom-side center endpoints aligned");
		}

		private static void VerticalSlotDatumUsesLayoutFacingChamferPoint()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateBottomLeftChamferedOutline();
			new FeatureRecognizer2D(config).RecognizeOutlineCornerFeatures(outline);
			var datum = Datum2D.FromOutline(outline);
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(25.0, 30.0), SourceGeometryId = "CHAMFER-SLOT-H" });
			datum.HoleCenterlineEndpoints.Add(new CenterlineEndpoint2D { Point = new Point2D(35.0, 30.0), SourceGeometryId = "CHAMFER-SLOT-H" });
			var slot = new SlotFeature2D
			{
				GroupId = "CHAMFER-SINGLE-ARC",
				FirstCenter = new Point2D(30.0, 30.0),
				SecondCenter = new Point2D(30.0, 30.0),
				Radius = 5.0,
				IsSingleArcSlot = true,
				IsVertical = true
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new HoleFeature2D[0], new[] { slot });
			var dimension = plan.Dimensions.Single(d => d.DebugRole == "SlotDatumV");

			Assert(dimension.Side == DimensionSide.Left
				&& dimension.FirstPoint.Equals(new Point2D(10.0, 0.0))
				&& dimension.SecondPoint.Equals(new Point2D(25.0, 30.0)),
				"vertical slot datum must use the lower layout-facing chamfer endpoint and the left centerline endpoint");
		}

		private static void FilletedOuterDatumUsesLayoutFacingFilletEndpoint()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var segments = new[]
			{
				new Segment2D(new Point2D(0.0, 0.0), new Point2D(100.0, 0.0)),
				new Segment2D(new Point2D(100.0, 0.0), new Point2D(100.0, 50.0)),
				new Segment2D(new Point2D(10.0, 50.0), new Point2D(100.0, 50.0)),
				new Segment2D(new Point2D(0.0, 40.0), new Point2D(0.0, 0.0))
			};
			var arcs = new[]
			{
				new Arc2D
				{
					Start = new Point2D(0.0, 40.0),
					End = new Point2D(10.0, 50.0),
					Center = new Point2D(10.0, 40.0),
					Radius = 10.0,
					Bulge = Math.Tan(Math.PI / 8.0)
				}
			};
			var outline = new FeatureRecognizer2D(config).RecognizeOutlineFromSegments(segments, arcs);
			var slots = new[]
			{
				new SlotFeature2D { GroupId = "FILLET-L", FirstCenter = new Point2D(30.0, 15.0), SecondCenter = new Point2D(30.0, 25.0), Radius = 5.0, CenterDistance = 10.0 },
				new SlotFeature2D { GroupId = "FILLET-R", FirstCenter = new Point2D(70.0, 15.0), SecondCenter = new Point2D(70.0, 25.0), Radius = 5.0, CenterDistance = 10.0 }
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new HoleFeature2D[0], slots);
			var datum = plan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotHorizontalDatum");
			var chain = plan.Dimensions.Single(d => d.DebugRole == "SlotChainH");

			Assert(outline.Fillets.Count == 1
				&& datum.Side == DimensionSide.Top
				&& datum.FirstPoint.Equals(new Point2D(0.0, 40.0))
				&& datum.SecondPoint.Equals(new Point2D(30.0, 25.0)),
				"horizontal slot datum must use the outer fillet endpoint nearest the layout-facing rounded side");
			Assert(chain.Side == DimensionSide.Top
				&& chain.FirstPoint.Equals(new Point2D(30.0, 25.0))
				&& chain.SecondPoint.Equals(new Point2D(70.0, 25.0)),
				"horizontal slot chain must follow the fillet-facing datum side");
		}

		private static void FilletedSlotGridKeepsContinuousVerticalChain()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var segments = new[]
			{
				new Segment2D(new Point2D(0.0, 0.0), new Point2D(100.0, 0.0)),
				new Segment2D(new Point2D(100.0, 0.0), new Point2D(100.0, 90.0)),
				new Segment2D(new Point2D(10.0, 100.0), new Point2D(90.0, 100.0)),
				new Segment2D(new Point2D(0.0, 90.0), new Point2D(0.0, 0.0))
			};
			var arcs = new[]
			{
				new Arc2D
				{
					Start = new Point2D(0.0, 90.0),
					End = new Point2D(10.0, 100.0),
					Center = new Point2D(10.0, 90.0),
					Radius = 10.0,
					Bulge = Math.Tan(Math.PI / 8.0)
				},
				new Arc2D
				{
					Start = new Point2D(90.0, 100.0),
					End = new Point2D(100.0, 90.0),
					Center = new Point2D(90.0, 90.0),
					Radius = 10.0,
					Bulge = Math.Tan(Math.PI / 8.0)
				}
			};
			var outline = new FeatureRecognizer2D(config).RecognizeOutlineFromSegments(segments, arcs);
			var slots = new[]
			{
				new SlotFeature2D { GroupId = "GRID-L-B", FirstCenter = new Point2D(30.0, 20.0), SecondCenter = new Point2D(30.0, 40.0), Radius = 5.0, CenterDistance = 20.0 },
				new SlotFeature2D { GroupId = "GRID-R-B", FirstCenter = new Point2D(70.0, 20.0), SecondCenter = new Point2D(70.0, 40.0), Radius = 5.0, CenterDistance = 20.0 },
				new SlotFeature2D { GroupId = "GRID-L-T", FirstCenter = new Point2D(30.0, 70.0), SecondCenter = new Point2D(30.0, 90.0), Radius = 5.0, CenterDistance = 20.0 },
				new SlotFeature2D { GroupId = "GRID-R-T", FirstCenter = new Point2D(70.0, 70.0), SecondCenter = new Point2D(70.0, 90.0), Radius = 5.0, CenterDistance = 20.0 }
			};

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new HoleFeature2D[0], slots);
			var verticalChain = plan.Dimensions.Single(d => d.DebugRole == "SlotChainV" && d.Side == DimensionSide.Left);
			var verticalDatum = plan.Dimensions.Single(d => d.DebugRole == "DoubleArcSlotVerticalDatum" && d.Side == DimensionSide.Left);

			Assert(verticalDatum.FirstPoint.Equals(new Point2D(10.0, 100.0))
				&& verticalDatum.SecondPoint.Equals(new Point2D(30.0, 90.0)),
				"top vertical datum must attach to the slot endpoint facing the rounded top");
			Assert(verticalChain.FirstPoint.Equals(new Point2D(30.0, 70.0))
				&& verticalChain.SecondPoint.Equals(new Point2D(30.0, 40.0))
				&& Math.Abs(GetSpan(verticalChain) - 30.0) <= 0.001,
				"vertical slot chain must keep the local inter-row span instead of a cross-grid long span");
			List<PlannedDimension> verticalChainMembers = plan.Dimensions
				.Where(d => d.Side == DimensionSide.Left
					&& d.Orientation == DimensionOrientation.Vertical
					&& (d.DebugRole == "DoubleArcSlotVerticalDatum"
						|| d.DebugRole == "SlotCenter"
						|| d.DebugRole == "SlotChainV"))
				.ToList();
			Assert(verticalChainMembers.Count == 4
				&& !string.IsNullOrEmpty(verticalChain.AlignmentKey)
				&& verticalChainMembers.All(d => d.AlignmentKey == verticalChain.AlignmentKey),
				"vertical slot datum and center chain members must share one alignment key");
			var topHorizontalChain = plan.Dimensions.Single(d => d.DebugRole == "SlotChainH" && d.Side == DimensionSide.Top);
			Assert(topHorizontalChain.FirstPoint.Equals(new Point2D(30.0, 90.0))
				&& topHorizontalChain.SecondPoint.Equals(new Point2D(70.0, 90.0)),
				"top horizontal slot chain must use the upper slot centerline");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "SlotChainV" && Math.Abs(GetSpan(d) - 70.0) <= 0.001),
				"vertical slot chain must not use the full cross-grid span");
		}

		private static void NonPinHorizontalHoleChainSharesAlignmentKey()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(200.0, 100.0);
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, Datum2D.FromOutline(outline), new[]
			{
				CreateHole(20.0, 20.0, 8.0, HoleKind2D.Normal),
				CreateHole(60.0, 20.0, 8.0, HoleKind2D.Normal),
				CreateHole(100.0, 70.0, 8.0, HoleKind2D.Normal),
				CreateHole(130.0, 70.0, 8.0, HoleKind2D.Normal),
				CreateHole(160.0, 70.0, 8.0, HoleKind2D.Normal)
			});
			var horizontalChain = plan.Dimensions.Where(d => d.Orientation == DimensionOrientation.Horizontal
				&& (d.DebugRole == "HoleDatumX" || d.DebugRole == "HoleChainH")).ToList();

			Assert(horizontalChain.Count(d => d.DebugRole == "HoleDatumX") == 1 && horizontalChain.Count(d => d.DebugRole == "HoleChainH") == 4,
				"a non-pin chain should contain one datum location and four center distances");
			Assert(horizontalChain.All(d => !string.IsNullOrEmpty(d.AlignmentKey)) && horizontalChain.Select(d => d.AlignmentKey).Distinct().Count() == 1,
				"a non-pin horizontal chain must share one alignment key");
		}

        private static void PinGroupsPlanBaseAndPairDistances()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(200.0, 100.0);
            var datumPin = CreateHole(20.0, 20.0, 6.0, HoleKind2D.Pin);
            var holes = new List<HoleFeature2D>
            {
                datumPin,
                CreateHole(60.0, 20.0, 6.0, HoleKind2D.Pin),
                CreateHole(140.0, 80.0, 6.0, HoleKind2D.Pin),
                CreateHole(170.0, 80.0, 6.0, HoleKind2D.Pin)
            };
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = datumPin;
			datum.DatumHoleLocationBaseX = 200.0;
			datum.DatumHoleLocationBaseY = 100.0;
			datum.DatumHoleLocationUseToleranceX = true;
			datum.DatumHoleLocationUseToleranceY = true;

            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);

			Assert(plan.PinGroups.Count == 2, "expected two pin groups");
			Assert(plan.PinGroups[0].BasePin == datumPin, "first pin group should keep user datum pin as base");
			var datumX = plan.Dimensions.Single(d => d.Kind == DimensionKind.DatumHoleLocationX);
			var datumY = plan.Dimensions.Single(d => d.Kind == DimensionKind.DatumHoleLocationY);
			Assert(Math.Abs(datumX.FirstPoint.X - 200.0) <= 0.001 && datumX.FirstPointMustLieOnOutline,
				"datum pin X location should preserve the selected real X datum");
			Assert(Math.Abs(datumY.FirstPoint.Y - 100.0) <= 0.001 && datumY.FirstPointMustLieOnOutline,
				"datum pin Y location should preserve the selected real Y datum");
			Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.PinDistance), "expected same-group pin distance");
            Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.PinGroupDistance), "expected pin group transfer distance");
			Assert(plan.Dimensions.Where(d => d.Kind == DimensionKind.PinDistance).All(d => d.ReadingLevel == DimensionReadingLevel.IntraGroup),
				"same-group pin distances must carry the intra-group reading level");
			Assert(plan.Dimensions.Where(d => d.Kind == DimensionKind.PinGroupDistance).All(d => d.ReadingLevel == DimensionReadingLevel.DatumTransfer),
				"pin-group transfer distances must carry the datum-transfer reading level");
			var horizontalTransfer = plan.Dimensions.Single(d => d.Kind == DimensionKind.PinGroupDistance && d.Orientation == DimensionOrientation.Horizontal);
			var horizontalPg2Direct = plan.Dimensions.Single(d => d.Kind == DimensionKind.PinDistance && d.DebugOwner == "PG2" && d.Orientation == DimensionOrientation.Horizontal);
			var verticalTransfer = plan.Dimensions.Single(d => d.Kind == DimensionKind.PinGroupDistance && d.Orientation == DimensionOrientation.Vertical);
			Assert(!string.IsNullOrEmpty(horizontalTransfer.AlignmentKey)
				&& datumX.AlignmentKey == horizontalTransfer.AlignmentKey
				&& horizontalTransfer.AlignmentKey == horizontalPg2Direct.AlignmentKey,
				"PG1 datum, PG1-to-PG2 transfer, and PG2 direct dimensions must share one rooted datum chain");
			Assert(datumX.AlignmentPriority > horizontalTransfer.AlignmentPriority
				&& horizontalTransfer.AlignmentPriority > horizontalPg2Direct.AlignmentPriority,
				"the rooted chain must fall back from PG1 datum to transfer and then to PG2 direct dimensions");
			Assert(horizontalTransfer.AlignmentKey != verticalTransfer.AlignmentKey,
				"horizontal and vertical transfer dimensions must never share an alignment key");
			Assert(datumX.ReadingLevel == DimensionReadingLevel.DatumTransfer && datumY.ReadingLevel == DimensionReadingLevel.DatumTransfer,
				"datum-hole locations must carry the datum-transfer reading level");
			Assert(plan.Dimensions.Where(d => d.Kind == DimensionKind.OverallWidth || d.Kind == DimensionKind.OverallHeight).All(d => d.ReadingLevel == DimensionReadingLevel.Overall),
				"overall dimensions must carry the outermost reading level");
			Assert(plan.Diagnostics.DimensionCandidates.Any(d => d.Kind == DimensionKind.PinDistance.ToString() && d.ReadingLevel == DimensionReadingLevel.IntraGroup.ToString()),
				"dimension diagnostics must expose the explicit reading level");
        }

		private static void PinAlignmentGroupsRespectSideAndOrientation()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var horizontal = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(0.0, 30.0),
					SecondPoint = new Point2D(40.0, 30.0),
					Span = 40.0,
					PreferFeatureLocalPlacement = true,
					AlignmentKey = "PG1-PG2:H",
					AlignmentPriority = 100
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinDistance,
					FirstPoint = new Point2D(40.0, 10.0),
					SecondPoint = new Point2D(60.0, 10.0),
					Span = 20.0,
					PreferFeatureLocalPlacement = true,
					AlignmentKey = "PG1-PG2:H",
					AlignmentPriority = 90
				}
			};
			var top = rules.CreateStackingPlan(horizontal, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var bottom = rules.CreateStackingPlan(horizontal, DimensionSide.Bottom, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var vertical = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(80.0, 0.0),
					SecondPoint = new Point2D(80.0, 40.0),
					Span = 40.0,
					PreferFeatureLocalPlacement = true,
					AlignmentKey = "PG1-PG2:H",
					AlignmentPriority = 100
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinDistance,
					FirstPoint = new Point2D(60.0, 40.0),
					SecondPoint = new Point2D(60.0, 60.0),
					Span = 20.0,
					PreferFeatureLocalPlacement = true,
					AlignmentKey = "PG1-PG2:H",
					AlignmentPriority = 90
				}
			};
			var left = rules.CreateStackingPlan(vertical, DimensionSide.Left, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: false);

			Assert(top.All(p => p.DimLineCoordinateOverride.HasValue)
				&& top.Select(p => p.DimLineCoordinateOverride.Value).Distinct().Count() == 1,
				"same-key dimensions on the same side and orientation must align");
			Assert(Math.Abs(top[0].DimLineCoordinateOverride.Value - bottom[0].DimLineCoordinateOverride.Value) > config.GeometryTolerance,
				"same keys on different sides must be resolved independently");
			Assert(Math.Abs(top[0].DimLineCoordinateOverride.Value - left[0].DimLineCoordinateOverride.Value) > config.GeometryTolerance,
				"same keys in different orientations must be resolved independently");
		}

		private static void RootedDatumChainMergesTransitiveAlignmentLanes()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(30.0, 0.0), Span = 30.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(145.0, 0.0), SecondPoint = new Point2D(205.0, 0.0), Span = 60.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(30.0, 0.0), SecondPoint = new Point2D(145.0, 0.0), Span = 115.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var coordinates = placements.Select(item => item.DimLineCoordinateOverride).ToList();

			Assert(coordinates.All(coordinate => coordinate.HasValue)
				&& coordinates.Select(coordinate => coordinate.Value).Distinct().Count() == 1,
				"a rooted DX-to-GD-to-PD datum chain must merge transitively into one shared dimension line");
		}

		private static void FunctionalHoleAlignmentUsesSeparateSameOrientationLane()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(140.0, 85.0), SecondPoint = new Point2D(95.0, 10.0), Span = 45.0, PreferLocalBoundary = true, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(140.0, 85.0), SecondPoint = new Point2D(185.0, 10.0), Span = 45.0, PreferLocalBoundary = true, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(200.0, 85.0), SecondPoint = new Point2D(140.0, 85.0), Span = 60.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var functionalHole1 = placements.Single(item => item.Index == 0);
			var functionalHole2 = placements.Single(item => item.Index == 1);
			var datum = placements.Single(item => item.Index == 2);

			Assert(functionalHole1.DimLineCoordinateOverride.HasValue && functionalHole2.DimLineCoordinateOverride.HasValue
				&& Math.Abs(functionalHole1.DimLineCoordinateOverride.Value - functionalHole2.DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
				"functional holes from one pin group and orientation must share a dimension line");
			Assert(functionalHole1.AlignmentLaneMemberCount == 2 && functionalHole2.AlignmentLaneMemberCount == 2
				&& functionalHole1.AlignmentLaneKey == functionalHole2.AlignmentLaneKey,
				"functional-hole placements must expose their resolved diagnostic alignment lane");
			Assert(Math.Abs(functionalHole1.DimLineCoordinateOverride.Value - datum.DimLineCoordinateOverride.Value) > config.GeometryTolerance,
				"functional-hole alignment must remain separate from the datum chain");
		}

		private static void FunctionalHoleAlignmentPreservesV198Stacking()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(40.0, 0.0), SecondPoint = new Point2D(25.0, 0.0), Span = 15.0, AlignmentKey = "PG2:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(40.0, 0.0), SecondPoint = new Point2D(55.0, 0.0), Span = 15.0, AlignmentKey = "PG2:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(40.0, 0.0), SecondPoint = new Point2D(10.0, 0.0), Span = 30.0, OverrideText = @"30\H0.8x;±0.02\H1x;", AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(155.0, 0.0), SecondPoint = new Point2D(110.0, 0.0), Span = 45.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(155.0, 0.0), SecondPoint = new Point2D(200.0, 0.0), Span = 45.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(90.0, 0.0), SecondPoint = new Point2D(140.0, 0.0), Span = 50.0, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(215.0, 0.0), SecondPoint = new Point2D(155.0, 0.0), Span = 60.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(140.0, 0.0), SecondPoint = new Point2D(215.0, 0.0), Span = 75.0, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(155.0, 0.0), SecondPoint = new Point2D(40.0, 0.0), Span = 115.0, OverrideText = @"115\H0.8x;±0.05\H1x;", AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.25, 5.0, 5.0, isHorizontal: true);
			var byIndex = placements.ToDictionary(item => item.Index);

			Assert(byIndex[0].Level == 0 && byIndex[1].Level == 0 && byIndex[3].Level == 0 && byIndex[4].Level == 0,
				"functional-hole alignment must preserve the v198 innermost stacking level");
			Assert(byIndex[5].Level == 1 && byIndex[7].Level == 1,
				"structure dimensions must retain the v198 middle stacking level");
			Assert(byIndex[2].Level == 2 && byIndex[6].Level == 2 && byIndex[8].Level == 2,
				"the rooted datum chain must retain the v198 outer stacking level");
			Assert(placements.Select(item => item.Level).Distinct().OrderBy(level => level).SequenceEqual(new[] { 0, 1, 2 }),
				"functional-hole alignment must not create empty stacking levels or enlarge spacing");
			Assert(byIndex[0].DimLineCoordinateOverride.HasValue && byIndex[1].DimLineCoordinateOverride.HasValue
				&& Math.Abs(byIndex[0].DimLineCoordinateOverride.Value - byIndex[1].DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
				"safe PG2 functional-hole dimensions must remain collinear without moving outward");
			Assert(byIndex[3].DimLineCoordinateOverride.HasValue && byIndex[4].DimLineCoordinateOverride.HasValue
				&& Math.Abs(byIndex[3].DimLineCoordinateOverride.Value - byIndex[4].DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
				"safe PG1 functional-hole dimensions must remain collinear without moving outward");
		}

		/// <summary>
		/// Two functional-hole dimensions share an alignment key with PreserveAlignmentLevel, so
		/// BuildLayoutBlocks gives them separate SingleDimension blocks while BuildAlignmentLanes
		/// still unifies their dimension-line coordinate. When only one of them collides with an
		/// inner block, EnsureLayoutBlockPhysicalOutwardOrder pushes that BLOCK outward and the
		/// shared lane coordinate is silently lost - AGENTS.md requires functional-hole dimensions
		/// to stay with their owning pin group.
		/// </summary>
		/// <summary>
		/// Baseline chain 41 (datum) + 30 (pin) must stay inside a same-group functional hole 45
		/// that reaches past the far pin, even though raw span 45 &lt; chain effective span 71.
		/// </summary>
		private static void FunctionalHoleBeyondPinChainStacksOutsideDatumChain()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(41.0, 0.0), SecondPoint = new Point2D(56.0, 0.0), Span = 15.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(41.0, 0.0), SecondPoint = new Point2D(86.0, 0.0), Span = 45.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(41.0, 0.0), Span = 41.0, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(41.0, 0.0), SecondPoint = new Point2D(71.0, 0.0), Span = 30.0, OverrideText = @"30\H0.8x;±0.02\H1x;", AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.OverallWidth, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(96.0, 0.0), Span = 96.0, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Bottom, null, 2.5, 1.25, 5.0, 5.0, isHorizontal: true);
			var byIndex = placements.ToDictionary(item => item.Index);

			Assert(byIndex[2].Level == byIndex[3].Level,
				"41 and 30 must remain on one datum/pin chain level");
			Assert(byIndex[0].Level < byIndex[2].Level,
				"15 must stay inside (lower level than) the 41-30 chain");
			Assert(byIndex[1].Level > byIndex[2].Level,
				"45 must sit outside the 41-30 chain");
			Assert(byIndex[4].Level > byIndex[1].Level,
				"overall 96 must remain outermost");
		}

		/// <summary>
		/// last-run: 16 above and 16 below datum hole must not ride outside DatumY 28±0.05
		/// just because their union (11–43) sticks past the 28 interval (27–55).
		/// </summary>
		private static void LocalFunctionalHolesStraddlingDatumStayInsideDatumLocation()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(92.5, 27.0), SecondPoint = new Point2D(92.5, 43.0), Span = 16.0, AlignmentKey = "PG1:FunctionalHoles:V", AlignmentPriority = 90, PreserveAlignmentLevel = true, PreferLocalBoundary = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(92.5, 27.0), SecondPoint = new Point2D(92.5, 11.0), Span = 16.0, AlignmentKey = "PG1:FunctionalHoles:V", AlignmentPriority = 90, PreserveAlignmentLevel = true, PreferLocalBoundary = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationY, FirstPoint = new Point2D(92.5, 55.0), SecondPoint = new Point2D(92.5, 27.0), Span = 28.0, OverrideText = @"28\H0.8x;±0.05\H1x;", AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 120, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG1" }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Right, null, 2.5, 1.25, 5.0, 5.0, isHorizontal: false);
			var byIndex = placements.ToDictionary(item => item.Index);
			Assert(byIndex[0].Level == byIndex[1].Level,
				"the two 16s must stay on one functional-hole lane");
			Assert(byIndex[0].Level < byIndex[2].Level,
				"16/16 must stack inside DatumY 28; levels 16=" + byIndex[0].Level + "/" + byIndex[1].Level + " 28=" + byIndex[2].Level);
		}

		/// <summary>
		/// RF110 left stack: tiny pin-group gap 1.28 must occupy lvl 0 (~FirstDimOffset from
		/// the left outline). A local 15 that only continues past 1.28's shared max, and a
		/// second 15 that extends past the unshared min, share the next outer lane. Then 50,
		/// then overall 55. The upper 15 must not steal innermost just because it is "not beyond".
		/// </summary>
		private static void TinyPinGroupGapStaysInsideAlignedFunctionalHolesOnLeft()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(110.0, 55.0);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(22.0, 27.0), SecondPoint = new Point2D(22.0, 28.28), Span = 1.28, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(22.0, 28.28), SecondPoint = new Point2D(22.0, 43.28), Span = 15.0, AlignmentKey = "PG1:FunctionalHoles:V", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(22.0, 28.0), SecondPoint = new Point2D(22.0, 13.0), Span = 15.0, AlignmentKey = "PG1:FunctionalHoles:V", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(22.0, 5.0), SecondPoint = new Point2D(22.0, 55.0), Span = 50.0, AlignmentKey = "PG1:DatumChain:V", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG2" },
				new DimensionLayoutItem { Kind = DimensionKind.OverallHeight, FirstPoint = new Point2D(0.0, 0.0), SecondPoint = new Point2D(0.0, 55.0), Span = 55.0, ForceOuterLevel = true, ReadingLevel = DimensionReadingLevel.Overall }
			};
			const double firstOffset = 10.0;
			const double perLevel = 6.5;
			var placements = new DimensionLayoutRules(config)
				.CreateStackingPlan(dimensions, DimensionSide.Left, outline, 2.5, 1.25, firstOffset, perLevel, isHorizontal: false)
				.ToDictionary(item => item.Index);

			Assert(placements[0].Level == 0,
				"tiny pin-group gap 1.28 must occupy leftmost lvl 0; got level=" + placements[0].Level
				+ " 15s=" + placements[1].Level + "/" + placements[2].Level
				+ " 50=" + placements[3].Level + " 55=" + placements[4].Level);
			Assert(placements[1].Level == placements[2].Level && placements[1].Level == 1,
				"the two 15s must share the next outer lane; got " + placements[1].Level + "/" + placements[2].Level);
			Assert(placements[3].Level > placements[1].Level,
				"50 must sit outside the aligned 15s; 50=" + placements[3].Level + " 15=" + placements[1].Level);
			Assert(placements[4].Level > placements[3].Level,
				"overall 55 must remain outermost");
			Assert(Math.Abs(placements[0].PhysicalOutwardDistance - firstOffset) <= config.GeometryTolerance,
				"1.28 must sit ~FirstDimOffset from the left outline; got " + placements[0].PhysicalOutwardDistance);
			Assert(!string.IsNullOrEmpty(placements[1].AlignmentLaneKey)
				&& string.Equals(placements[1].AlignmentLaneKey, placements[2].AlignmentLaneKey, StringComparison.Ordinal),
				"the two 15s must keep one functional-hole alignment lane");
			double fifteenCoordinate = placements[1].DimLineCoordinateOverride
				?? new DimensionLayoutRules(config).GetDimLineCoordinate(dimensions[1], DimensionSide.Left, outline, placements[1].Offset);
			double otherFifteenCoordinate = placements[2].DimLineCoordinateOverride
				?? new DimensionLayoutRules(config).GetDimLineCoordinate(dimensions[2], DimensionSide.Left, outline, placements[2].Offset);
			Assert(Math.Abs(fifteenCoordinate - otherFifteenCoordinate) <= config.GeometryTolerance,
				"both 15s must share one physical dimension line");
			Assert(placements[1].PhysicalOutwardDistance > placements[0].PhysicalOutwardDistance + config.GeometryTolerance,
				"aligned 15s must sit outside 1.28; 15=" + placements[1].PhysicalOutwardDistance
				+ " 1.28=" + placements[0].PhysicalOutwardDistance);
		}

		private static void Dl01TopStructureFunctionalHoleDatumChainOrder()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(7.0, 0.0), SecondPoint = new Point2D(22.0, 0.0), Span = 15.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(9.0, 0.0), SecondPoint = new Point2D(24.0, 0.0), Span = 15.0, LooseChainId = 6, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "L6" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(22.0, 0.0), SecondPoint = new Point2D(24.0, 0.0), Span = 2.0, LooseChainId = 6, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "L6" },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(-8.0, 0.0), SecondPoint = new Point2D(22.0, 0.0), Span = 30.0, OverrideText = @"30\H0.8x;±0.02\H1x;", AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 100, ReadingLevel = DimensionReadingLevel.IntraGroup, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(22.0, 0.0), SecondPoint = new Point2D(245.5, 0.0), Span = 223.5, AlignmentKey = "PG1:DatumChain:H", AlignmentPriority = 110, ReadingLevel = DimensionReadingLevel.DatumTransfer, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(-23.0, 0.0), SecondPoint = new Point2D(22.0, 0.0), Span = 45.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "PG1" },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(-33.0, 0.0), SecondPoint = new Point2D(40.0, 0.0), Span = 73.0, AlignmentKey = "Structure:T:H", AlignmentPriority = 70, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "TopStructWidth" },
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(40.0, 0.0), SecondPoint = new Point2D(127.554, 0.0), Span = 87.554, AlignmentKey = "Structure:T:H", AlignmentPriority = 70, ReadingLevel = DimensionReadingLevel.LocalSpacing, SourceFeatureId = "TopStructWidth" }
			};
			var placements = new DimensionLayoutRules(config)
				.CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.25, 5.0, 5.0, isHorizontal: true)
				.ToDictionary(item => item.Index);

			Assert(placements[0].Level == 0 && placements[1].Level == 1 && placements[2].Level == 1,
				"DL01 Top local Functional15 and LooseChain 15/2 must retain levels 0 and 1");
			Assert(placements[3].Level == 2 && placements[4].Level == 2,
				"DL01 Top 30±0.02 and 223.5 must remain one datum-chain block");
			Assert(placements[5].Level == 3,
				"DL01 Top FunctionalHole 45 must occupy level 3");
			Assert(placements[6].Level == 4 && placements[7].Level == 4,
				"DL01 Top 73 and 87.554 must remain one TopStructWidth block (levels: "
				+ string.Join(",", placements.OrderBy(item => item.Key).Select(item => item.Value.Level))
				+ ")");
			Assert(placements[6].Level > placements[5].Level && placements[5].Level > placements[3].Level,
				"DL01 Top outer three levels must be TopStructWidth 73/87.554, FunctionalHole 45, DatumChain 30/223.5");
		}

		private static void FunctionalHoleAlignmentLaneSurvivesOutwardPromotion()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(10.0, 0.0), SecondPoint = new Point2D(40.0, 0.0), Span = 30.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				new DimensionLayoutItem { Kind = DimensionKind.HoleLocation, FirstPoint = new Point2D(100.0, 0.0), SecondPoint = new Point2D(130.0, 0.0), Span = 30.0, AlignmentKey = "PG1:FunctionalHoles:H", AlignmentPriority = 90, PreserveAlignmentLevel = true, ReadingLevel = DimensionReadingLevel.LocalSpacing },
				// Smaller span, so it sorts inner; its arrow interval strictly overlaps member 0
				// only, which is what makes the promotion asymmetric.
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(25.0, 0.0), SecondPoint = new Point2D(45.0, 0.0), Span = 20.0, ReadingLevel = DimensionReadingLevel.LocalSpacing }
			};
			var placements = new DimensionLayoutRules(config).CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.25, 5.0, 5.0, isHorizontal: true);
			var byIndex = placements.ToDictionary(item => item.Index);

			// Non-vacuity guard: if the outward promotion never fires, this scenario proves
			// nothing and must fail loudly rather than pass by accident.
			Assert(!string.IsNullOrEmpty(byIndex[0].PromotedByConflictWith) || !string.IsNullOrEmpty(byIndex[1].PromotedByConflictWith),
				"scenario did not trigger an outward promotion - the repro no longer covers the lane-splitting path");

			Assert(byIndex[0].DimLineCoordinateOverride.HasValue && byIndex[1].DimLineCoordinateOverride.HasValue,
				"both functional-hole lane members must keep an alignment coordinate override");
			Assert(Math.Abs(byIndex[0].DimLineCoordinateOverride.Value - byIndex[1].DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
				"functional-hole alignment lane must move as one when a member is pushed outward");
			Assert(string.Equals(byIndex[0].AlignmentLaneKey, byIndex[1].AlignmentLaneKey, StringComparison.Ordinal)
				&& !string.IsNullOrEmpty(byIndex[0].AlignmentLaneKey),
				"both lane members must still report the same alignment lane key");
		}

		private static void PinAlignmentAnchorFallsBackWithStableOrdering()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var fallbackMembers = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 40.0), SecondPoint = new Point2D(10.0, 40.0), Span = 10.0, PreferFeatureLocalPlacement = true, AlignmentKey = "fallback", AlignmentPriority = 90 },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(10.0, 20.0), SecondPoint = new Point2D(20.0, 20.0), Span = 10.0, PreferFeatureLocalPlacement = true, AlignmentKey = "fallback", AlignmentPriority = 80 }
			};
			var fallback = rules.CreateStackingPlan(fallbackMembers, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			double fallbackExpected = rules.GetDimLineCoordinate(fallbackMembers[0], DimensionSide.Top, null, fallback.Single(p => p.Index == 0).Offset);

			var equalPriority = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 10.0), SecondPoint = new Point2D(40.0, 10.0), Span = 40.0, PreferFeatureLocalPlacement = true, AlignmentKey = "stable-span", AlignmentPriority = 90 },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(40.0, 30.0), SecondPoint = new Point2D(60.0, 30.0), Span = 20.0, PreferFeatureLocalPlacement = true, AlignmentKey = "stable-span", AlignmentPriority = 90 }
			};
			var bySpan = rules.CreateStackingPlan(equalPriority, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			double spanExpected = rules.GetDimLineCoordinate(equalPriority[1], DimensionSide.Top, null, bySpan.Single(p => p.Index == 1).Offset);

			var equalSpan = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(0.0, 50.0), SecondPoint = new Point2D(20.0, 50.0), Span = 20.0, PreferFeatureLocalPlacement = true, AlignmentKey = "stable-order", AlignmentPriority = 90 },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(20.0, 30.0), SecondPoint = new Point2D(40.0, 30.0), Span = 20.0, PreferFeatureLocalPlacement = true, AlignmentKey = "stable-order", AlignmentPriority = 90 }
			};
			var byOrder = rules.CreateStackingPlan(equalSpan, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			double orderExpected = rules.GetDimLineCoordinate(equalSpan[0], DimensionSide.Top, null, byOrder.Single(p => p.Index == 0).Offset);

			Assert(fallback.All(p => Math.Abs(p.DimLineCoordinateOverride.Value - fallbackExpected) <= config.GeometryTolerance),
				"when the preferred anchor is suppressed, the next-highest-priority remaining member must anchor the group");
			Assert(bySpan.All(p => Math.Abs(p.DimLineCoordinateOverride.Value - spanExpected) <= config.GeometryTolerance),
				"equal-priority members must choose the smaller span as the stable anchor");
			Assert(byOrder.All(p => Math.Abs(p.DimLineCoordinateOverride.Value - orderExpected) <= config.GeometryTolerance),
				"equal-priority equal-span members must choose the earlier generated member as the stable anchor");
		}

		private static void PinAlignmentGroupMovesTogetherOnConflict()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.Normal, FirstPoint = new Point2D(40.0, 0.0), SecondPoint = new Point2D(50.0, 0.0), Span = 10.0 },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(0.0, 20.0), SecondPoint = new Point2D(35.0, 20.0), Span = 35.0, PreferFeatureLocalPlacement = true, AlignmentKey = "move-together", AlignmentPriority = 100 },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(35.0, 10.0), SecondPoint = new Point2D(70.0, 10.0), Span = 35.0, PreferFeatureLocalPlacement = true, AlignmentKey = "move-together", AlignmentPriority = 90 }
			};
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var anchor = placements.Single(p => p.Index == 1);
			var follower = placements.Single(p => p.Index == 2);

			Assert(anchor.Level == follower.Level && Math.Abs(anchor.Offset - follower.Offset) <= config.GeometryTolerance,
				"a conflict affecting one member must move the entire alignment group to the same layer");
			Assert(anchor.Level > 0,
				"the aligned group must move outward when a member conflicts with an existing dimension");
			Assert(Math.Abs(anchor.DimLineCoordinateOverride.Value - follower.DimLineCoordinateOverride.Value) <= config.GeometryTolerance,
				"moving an alignment group must preserve its unbroken shared dimension line");
		}

		private static void PinAlignmentGroupAvoidsResolvedCoordinateConflicts()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimensions = new[]
			{
				new DimensionLayoutItem
				{
					Kind = DimensionKind.Normal,
					FirstPoint = new Point2D(0.0, 30.0),
					SecondPoint = new Point2D(20.0, 30.0),
					Span = 20.0,
					PreferFeatureLocalPlacement = true
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.DatumHoleLocationX,
					FirstPoint = new Point2D(0.0, 25.0),
					SecondPoint = new Point2D(20.0, 25.0),
					Span = 20.0,
					PreferFeatureLocalPlacement = true,
					AlignmentKey = "resolved-conflict",
					AlignmentPriority = 120
				},
				new DimensionLayoutItem
				{
					Kind = DimensionKind.PinGroupDistance,
					FirstPoint = new Point2D(20.0, 10.0),
					SecondPoint = new Point2D(40.0, 10.0),
					Span = 20.0,
					PreferFeatureLocalPlacement = true,
					AlignmentKey = "resolved-conflict",
					AlignmentPriority = 110
				}
			};
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Top, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			var external = placements.Single(p => p.Index == 0);
			var anchor = placements.Single(p => p.Index == 1);
			var follower = placements.Single(p => p.Index == 2);
			double externalCoordinate = rules.GetDimLineCoordinate(dimensions[0], DimensionSide.Top, null, external.Offset);

			Assert(anchor.Level == follower.Level && anchor.Level >= 2,
				"a group must move again when different abstract levels resolve to the same physical dimension line");
			Assert(Math.Abs(anchor.DimLineCoordinateOverride.Value - externalCoordinate) >= 5.0 - config.GeometryTolerance,
				"resolved group coordinates must retain one full stacking interval from overlapping external dimensions");
		}

		private static void PinAlignmentKeySplitsStrictHorizontalOverlapsIntoLanes()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationX, FirstPoint = new Point2D(205.0, 40.0), SecondPoint = new Point2D(265.0, 40.0), Span = 60.0, AlignmentKey = "multi-group:H", AlignmentPriority = 120 },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(81.0, 30.0), SecondPoint = new Point2D(205.0, 30.0), Span = 124.0, AlignmentKey = "multi-group:H", AlignmentPriority = 110 },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(31.0, 20.0), SecondPoint = new Point2D(81.0, 20.0), Span = 50.0, AlignmentKey = "multi-group:H", AlignmentPriority = 100 },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(31.0, 10.0), SecondPoint = new Point2D(205.0, 10.0), Span = 174.0, AlignmentKey = "multi-group:H", AlignmentPriority = 110 }
			};
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Bottom, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: true);
			double chainCoordinate = placements.Single(p => p.Index == 0).DimLineCoordinateOverride.Value;

			Assert(placements.Where(p => p.Index < 3).All(p => Math.Abs(p.DimLineCoordinateOverride.Value - chainCoordinate) <= config.GeometryTolerance),
				"endpoint-connected horizontal dimensions must remain on one continuous lane");
			Assert(Math.Abs(placements.Single(p => p.Index == 3).DimLineCoordinateOverride.Value - chainCoordinate) >= 5.0 - config.GeometryTolerance,
				"a strictly overlapping horizontal dimension must move to a separate lane");
		}

		private static void PinAlignmentKeySplitsStrictVerticalOverlapsIntoLanes()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var dimensions = new[]
			{
				new DimensionLayoutItem { Kind = DimensionKind.DatumHoleLocationY, FirstPoint = new Point2D(40.0, 205.0), SecondPoint = new Point2D(40.0, 265.0), Span = 60.0, AlignmentKey = "multi-group:V", AlignmentPriority = 120 },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(30.0, 81.0), SecondPoint = new Point2D(30.0, 205.0), Span = 124.0, AlignmentKey = "multi-group:V", AlignmentPriority = 110 },
				new DimensionLayoutItem { Kind = DimensionKind.PinDistance, FirstPoint = new Point2D(20.0, 31.0), SecondPoint = new Point2D(20.0, 81.0), Span = 50.0, AlignmentKey = "multi-group:V", AlignmentPriority = 100 },
				new DimensionLayoutItem { Kind = DimensionKind.PinGroupDistance, FirstPoint = new Point2D(10.0, 31.0), SecondPoint = new Point2D(10.0, 205.0), Span = 174.0, AlignmentKey = "multi-group:V", AlignmentPriority = 110 }
			};
			var placements = rules.CreateStackingPlan(dimensions, DimensionSide.Left, null, 2.5, 1.0, 5.0, 5.0, isHorizontal: false);
			double chainCoordinate = placements.Single(p => p.Index == 0).DimLineCoordinateOverride.Value;

			Assert(placements.Where(p => p.Index < 3).All(p => Math.Abs(p.DimLineCoordinateOverride.Value - chainCoordinate) <= config.GeometryTolerance),
				"endpoint-connected vertical dimensions must remain on one continuous lane");
			Assert(Math.Abs(placements.Single(p => p.Index == 3).DimLineCoordinateOverride.Value - chainCoordinate) >= 5.0 - config.GeometryTolerance,
				"a strictly overlapping vertical dimension must move to a separate lane");
		}

		private static void EquivalentPinGroupTransfersSuppressAcrossDebugOwners()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(200.0, 100.0);
			var datumPin = CreateHole(180.0, 10.0, 6.0, HoleKind2D.Pin);
			var holes = new[]
			{
				datumPin,
				CreateHole(190.0, 10.0, 6.0, HoleKind2D.Pin),
				CreateHole(100.0, 10.0, 7.0, HoleKind2D.Pin),
				CreateHole(110.0, 10.0, 7.0, HoleKind2D.Pin),
				CreateHole(50.0, 10.0, 8.0, HoleKind2D.Pin),
				CreateHole(60.0, 10.0, 8.0, HoleKind2D.Pin),
				CreateHole(50.0, 30.0, 9.0, HoleKind2D.Pin),
				CreateHole(60.0, 30.0, 9.0, HoleKind2D.Pin)
			};
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = datumPin;
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);
			var equivalentTransfers = plan.Diagnostics.DimensionCandidates
				.Where(candidate => candidate.Kind == DimensionKind.PinGroupDistance.ToString()
					&& candidate.Orientation == DimensionOrientation.Horizontal.ToString()
					&& Math.Abs(candidate.MeasurementMinimum - 60.0) <= config.GeometryTolerance
					&& Math.Abs(candidate.MeasurementMaximum - 180.0) <= config.GeometryTolerance)
				.ToList();

			Assert(equivalentTransfers.Count == 2 && equivalentTransfers.Select(candidate => candidate.SourceFeatureId).Distinct().Count() == 2,
				"the fixture must generate equivalent transfers owned by two different pin groups");
			Assert(equivalentTransfers.Count(candidate => candidate.IsSelected) == 1
				&& equivalentTransfers.Count(candidate => candidate.IsSuppressed && candidate.SuppressedReason == "DuplicateMeasuredDimension") == 1,
				"equivalent pin-group coordinates must retain one stable member and diagnose the other as suppressed regardless of DebugOwner");
		}

        private static void FunctionalHolesAttachToPinGroup()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(200.0, 100.0);
            var datumPin = CreateHole(20.0, 20.0, 6.0, HoleKind2D.Pin);
            var holes = new List<HoleFeature2D>
            {
                datumPin,
                CreateHole(60.0, 20.0, 6.0, HoleKind2D.Pin),
                CreateHole(20.0, 40.0, 8.0, HoleKind2D.Normal),
                CreateHole(60.0, 40.0, 8.0, HoleKind2D.Normal)
            };
            var datum = Datum2D.FromOutline(outline);
            datum.DatumHole = datumPin;

            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);

            Assert(plan.Dimensions.Any(d => d.DebugRole == "FunctionalHole" && d.DebugOwner == "PG1"),
                "functional holes should attach to the pin group");
			var functionalHoles = plan.Dimensions.Where(d => d.DebugRole == "FunctionalHole").ToList();
			var verticalFunctionalHoles = functionalHoles.Where(d => d.Orientation == DimensionOrientation.Vertical).ToList();
			Assert(functionalHoles.Count > 0
				&& functionalHoles.All(d => d.PreservePreferredSide && !d.PreferFeatureLocalPlacement && d.PreferLocalBoundary),
				"functional-hole dimensions must stay with their pin group and prefer a nearby local boundary");
			Assert(functionalHoles.GroupBy(d => d.Orientation).All(group => group.Select(d => d.AlignmentKey).Distinct().Count() == 1
				&& group.All(d => !string.IsNullOrEmpty(d.AlignmentKey) && d.AlignmentPriority == 90 && d.PreserveAlignmentLevel)),
				"functional-hole dimensions in one pin group must receive a same-orientation alignment key");
			Assert(verticalFunctionalHoles.All(d => d.Side == plan.PinGroups[0].VerticalSide),
				"functional-hole dimensions must inherit their pin group's vertical side");
        }

		private static void HoleBetweenPinPairAttachesAsFunctionalHole()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(300.0, 40.0);
			// Two pin pairs, each with one normal hole strictly between the pins (repro of the bar fixture).
			var datumPin = CreateHole(210.0, 20.0, 6.0, HoleKind2D.Pin);
			var holes = new List<HoleFeature2D>
			{
				// Right pin group (datum): pins at 180/210, hole at midpoint 195
				CreateHole(180.0, 20.0, 6.0, HoleKind2D.Pin),
				datumPin,
				CreateHole(195.0, 20.0, 8.0, HoleKind2D.Normal),
				// Left pin group: pins at 80/110, hole at midpoint 95
				CreateHole(80.0, 20.0, 6.0, HoleKind2D.Pin),
				CreateHole(110.0, 20.0, 6.0, HoleKind2D.Pin),
				CreateHole(95.0, 20.0, 8.0, HoleKind2D.Normal),
				// Far-left isolated hole should remain loose (not between any pin pair)
				CreateHole(30.0, 20.0, 8.0, HoleKind2D.Normal)
			};
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = datumPin;
			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);

			var functional = plan.Dimensions.Where(d => d.DebugRole == "FunctionalHole").ToList();
			var loose = plan.Dimensions.Where(d => d.DebugRole == "LooseHole").ToList();

			Assert(plan.PinGroups.Count == 2, "fixture must form two pin groups");
			Assert(functional.Count > 0 && functional.All(d => d.DebugOwner == "PG1" || d.DebugOwner == "PG2"),
				"holes between pin pairs must become FunctionalHole owned by a pin group");
			// Each between-pin hole should be located from its group's base pin (horizontal span 15 = half of pin distance 30).
			Assert(functional.Count(d => d.Orientation == DimensionOrientation.Horizontal
					&& Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 15.0) <= config.GeometryTolerance) >= 2,
				"each between-pin hole must be dimensioned 15 from the owning base pin");
			Assert(functional.All(d =>
					plan.PinGroups.Any(g => g.BasePin != null
						&& (IsNear(d.FirstPoint, g.BasePin.Center, config) || IsNear(d.SecondPoint, g.BasePin.Center, config)))),
				"functional-hole dimensions must use the pin-group base pin as one endpoint");
			Assert(!loose.Any(d => Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 100.0) <= 1.0
					|| Math.Abs(Math.Abs(d.SecondPoint.X - d.FirstPoint.X) - 93.0) <= 1.0),
				"between-pin holes must not form a long loose chain across pin groups");
			// Isolated left hole may still emit a short location, but not re-chain the pin-pair midpoints.
			Assert(!loose.Any(d =>
					Math.Abs(d.FirstPoint.X - 95.0) <= config.GeometryTolerance
					|| Math.Abs(d.SecondPoint.X - 95.0) <= config.GeometryTolerance
					|| Math.Abs(d.FirstPoint.X - 195.0) <= config.GeometryTolerance
					|| Math.Abs(d.SecondPoint.X - 195.0) <= config.GeometryTolerance),
				"between-pin holes must not appear in LooseHole dimensions");
		}

		private static bool IsNear(Point2D a, Point2D b, DimensionRuleConfig config)
		{
			return Math.Abs(a.X - b.X) <= config.GeometryTolerance && Math.Abs(a.Y - b.Y) <= config.GeometryTolerance;
		}

		private static void PreferredSideLockedHoleLocationUsesLocalBoundary()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var functionalHole = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(20.0, 30.0),
				SecondPoint = new Point2D(20.0, 70.0),
				Span = 40.0,
				PreferLocalBoundary = true,
				PreservePreferredSide = true
			};
			var crowdedRight = Enumerable.Range(0, 4).Select(index => new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(10.0 + index, 30.0),
				SecondPoint = new Point2D(10.0 + index, 70.0),
				Span = 40.0
			}).ToList();

			var selectedSide = rules.ChooseVerticalHoleLocationSide(functionalHole, DimensionSide.Right, crowdedRight, new DimensionLayoutItem[0], 10.0);
			var moves = rules.SelectVerticalHoleLocationRebalanceMoves(new[] { functionalHole }, new DimensionLayoutItem[0], 1.0);
			var outline = CreateRightNotchOutline();
			var datumY = new DimensionLayoutItem
			{
				Kind = DimensionKind.DatumHoleLocationY,
				FirstPoint = new Point2D(20.0, 30.0),
				SecondPoint = new Point2D(20.0, 70.0),
				Span = 40.0
			};
			double functionalCoordinate = rules.GetDimLineCoordinate(functionalHole, DimensionSide.Right, outline, 5.0);
			double datumCoordinate = rules.GetDimLineCoordinate(datumY, DimensionSide.Right, outline, 5.0);

			Assert(selectedSide == DimensionSide.Right,
				"side-locked functional holes must keep the pin group's preferred vertical side during initial placement");
			Assert(!rules.CanRebalanceVerticalHoleLocation(functionalHole, 1.0) && moves.Count == 0,
				"side-locked functional holes must not move during later vertical-side rebalancing");
			Assert(Math.Abs(functionalCoordinate - 65.0) <= config.GeometryTolerance
				&& Math.Abs(datumCoordinate - 205.0) <= config.GeometryTolerance,
				"local functional-hole dimensions must use the nearby notch while global datum dimensions remain outside the full outline");
		}

		/// <summary>
		/// last-run left stack sat 36mm off the outline because hole-column ticks at X=40
		/// were used as the Left local boundary. Fall back to the outer wall.
		/// </summary>
		private static void LeftHoleLocalBoundaryDoesNotUseInnerHoleColumn()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var outline = CreateSteppedPlate102Outline();
			outline.Segments.Add(new Segment2D(new Point2D(40.0, 10.0), new Point2D(40.0, 45.0)) { SourceKey = "hole-tick" });
			var hole = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(40.0, 13.0),
				SecondPoint = new Point2D(40.0, 43.0),
				Span = 15.0,
				PreferLocalBoundary = true
			};
			double coordinate = rules.GetDimLineCoordinate(hole, DimensionSide.Left, outline, 10.0);
			Assert(Math.Abs(coordinate - (outline.MinX - 10.0)) <= config.GeometryTolerance,
				"left functional-hole dim line must sit 10 outside MinX, not beside the hole column; got " + coordinate);
		}

		private static void ExplicitLocalLooseChainUsesNearbyConcaveBoundary()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var rules = new DimensionLayoutRules(config);
			var outline = CreateRightNotchOutline();
			var loose = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = new Point2D(20.0, 30.0),
				SecondPoint = new Point2D(22.0, 70.0),
				Span = 40.0,
				LooseChainId = 6,
				PreferLocalBoundary = true
			};
			var legacyGlobalLoose = new DimensionLayoutItem
			{
				Kind = DimensionKind.HoleLocation,
				FirstPoint = loose.FirstPoint,
				SecondPoint = loose.SecondPoint,
				Span = loose.Span,
				LooseChainId = loose.LooseChainId
			};
			var crowdedSource = new List<DimensionLayoutItem> { loose };
			crowdedSource.AddRange(Enumerable.Range(0, 3).Select(index => new DimensionLayoutItem
			{
				Kind = DimensionKind.Normal,
				FirstPoint = new Point2D(10.0 + index, 30.0),
				SecondPoint = new Point2D(10.0 + index, 70.0),
				Span = 40.0
			}));
			var moves = rules.SelectVerticalHoleLocationRebalanceMoves(crowdedSource, new DimensionLayoutItem[0], 1.0);

			Assert(rules.TryGetDimensionLocalBoundary(loose, DimensionSide.Right, outline, out var boundary)
				&& Math.Abs(boundary - 60.0) <= config.GeometryTolerance,
				"an explicitly local loose chain must find the nearby concave boundary");
			Assert(Math.Abs(rules.GetDimLineCoordinate(loose, DimensionSide.Right, outline, 5.0) - 65.0) <= config.GeometryTolerance,
				"a rebalanced loose chain must stay beside its holes instead of using the distant global side");
			Assert(!rules.TryGetDimensionLocalBoundary(legacyGlobalLoose, DimensionSide.Right, outline, out _)
				&& Math.Abs(rules.GetDimLineCoordinate(legacyGlobalLoose, DimensionSide.Right, outline, 5.0) - 205.0) <= config.GeometryTolerance,
				"unmarked legacy loose chains must still fall back to the global boundary");
			Assert(moves.Any(move => move.SourceIndex == 0),
				"local placement must remain compatible with moving a crowded loose chain to the nearer notch side");
		}

        private static void LooseHolesUseChainDimensions()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(240.0, 120.0);
            var datumPin = CreateHole(20.0, 20.0, 6.0, HoleKind2D.Pin);
            var holes = new List<HoleFeature2D>
            {
                datumPin,
                CreateHole(60.0, 20.0, 6.0, HoleKind2D.Pin),
                CreateHole(100.0, 70.0, 8.0, HoleKind2D.Normal),
                CreateHole(130.0, 70.0, 8.0, HoleKind2D.Normal),
                CreateHole(160.0, 70.0, 8.0, HoleKind2D.Normal)
            };
            var datum = Datum2D.FromOutline(outline);
            datum.DatumHole = datumPin;

            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);

            Assert(plan.Dimensions.Any(d => d.DebugRole == "LooseHole" && d.DebugOwner.StartsWith("L", StringComparison.Ordinal)),
                "loose holes should use chained hole-location dimensions");
			Assert(plan.Dimensions.Count(d => d.DebugRole == "LooseHole") >= 3,
				"loose hole chain should include center distances and pin/location references");
			Assert(plan.Dimensions.Where(d => d.DebugRole == "LooseHole").All(d => d.ChainId > 0),
				"loose hole dimensions must preserve their generated chain identifiers through planning");
			Assert(plan.Dimensions.Where(d => d.DebugRole == "LooseHole").All(d => d.PreferLocalBoundary),
				"loose hole chains must prefer a nearby valid boundary to avoid full-part extension lines");
        }

		private static void PinGroupAnchoredLooseHolePreservesPreferredSide()
		{
			var config = DimensionRuleConfig.CreateDefault();
			var outline = CreateRectangle(240.0, 120.0);
			var datumPin = CreateHole(20.0, 20.0, 6.0, HoleKind2D.Pin);
			var holes = new List<HoleFeature2D>
			{
				datumPin,
				CreateHole(60.0, 20.0, 6.0, HoleKind2D.Pin),
				CreateHole(100.0, 70.0, 8.0, HoleKind2D.Normal),
				CreateHole(130.0, 70.0, 8.0, HoleKind2D.Normal),
				CreateHole(160.0, 70.0, 8.0, HoleKind2D.Normal)
			};
			var datum = Datum2D.FromOutline(outline);
			datum.DatumHole = datumPin;

			var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);
			var loose = plan.Dimensions.Where(d => d.DebugRole == "LooseHole").ToList();

			Assert(loose.Count > 0 && loose.All(d => d.PreservePreferredSide),
				"PinGroup-anchored loose-hole dimensions must preserve their planner-selected side");
			Assert(loose.Where(d => d.Orientation == DimensionOrientation.Vertical)
				.All(d => d.Side == plan.PinGroups[0].VerticalSide),
				"PinGroup-anchored vertical loose-hole dimensions must retain the pin group's side");
		}

        private static void ConcentricLooseHolesShareOneLocationDimension()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(73.0, 20.0);
            var datumPin = CreateHole(10.0, 10.0, 8.0, HoleKind2D.Pin);
            var holes = new List<HoleFeature2D>
            {
                datumPin,
                CreateHole(40.0, 10.0, 8.0, HoleKind2D.Pin),
                CreateHole(25.0, 10.0, 14.0, HoleKind2D.Normal),
                CreateHole(25.0, 10.0, 9.0, HoleKind2D.Normal)
            };
            var datum = Datum2D.FromOutline(outline);
            datum.DatumHole = holes[1];
            datum.DatumHoleLocationBaseX = 73.0;
            datum.DatumHoleLocationBaseY = 20.0;

            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, holes);

			// Concentric non-pin holes sit between the pin pair → claimed as FunctionalHole from base pin.
			// Same measured span should collapse to one selected location (duplicate suppressed).
			var functionalHorizontal = plan.Diagnostics.DimensionCandidates
				.Where(d => d.DebugRole == "FunctionalHole"
					&& d.Orientation == DimensionOrientation.Horizontal.ToString()
					&& Math.Abs(d.Value - 15.0) <= 0.001)
				.ToList();
			Assert(functionalHorizontal.Count >= 1, "concentric between-pin holes must locate from the pin-group base as FunctionalHole");
			Assert(functionalHorizontal.Count(d => d.IsSelected) == 1,
				"concentric between-pin holes that share the same center must keep a single selected location dimension");
			Assert(!plan.Dimensions.Any(d => d.DebugRole == "LooseHole"),
				"between-pin concentric holes must not fall through to LooseHole");
        }

        private static void HoleLocationDimensionsUseSegmentedExtensionLines()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var outline = CreateRectangle(100.0, 50.0);
            var datum = Datum2D.FromOutline(outline);
            var plan = new DimensionPlanner(config).CreateDimensionPlan(outline, datum, new[]
            {
                CreateHole(25.0, 20.0, 8.0, HoleKind2D.Normal)
            });

            Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallWidth && !d.UseSegmentedExtensionLines),
                "overall width should not use segmented extension lines");
            Assert(plan.Dimensions.Any(d => d.Kind == DimensionKind.OverallHeight && !d.UseSegmentedExtensionLines),
                "overall height should not use segmented extension lines");
            Assert(plan.Dimensions.Count(d => d.Kind == DimensionKind.HoleLocation && d.UseSegmentedExtensionLines) == 2,
                "hole location dimensions should use segmented extension lines");
        }

        private static void HoleCalloutsGroupByRowsWithoutPins()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var holes = new List<HoleFeature2D>
            {
                CreateHole(10.0, 10.0, 6.0, HoleKind2D.Normal),
                CreateHole(30.0, 10.0, 6.0, HoleKind2D.Normal),
                CreateHole(10.0, 40.0, 8.0, HoleKind2D.Thread)
            };
            holes[2].ThreadCallout = "M8";

            var plans = new HoleCalloutPlanner(config).CreatePlans(holes, null);

            Assert(plans.Count == 2, "hole callouts without pins should group compatible holes by spatial rows");
            Assert(plans.Any(p => p.Kind == HoleCalloutKind.Normal && p.Text == "2-%%c6"),
                "two equal normal holes should share one diameter callout");
            Assert(plans.Any(p => p.Kind == HoleCalloutKind.Thread && p.Text == "M8"),
                "thread holes should use explicit thread callout text");
        }

        private static void HoleCalloutsUsePinClustersAndFitText()
        {
            var config = DimensionRuleConfig.CreateDefault();
            var datumPin = CreateHole(10.0, 10.0, 8.0, HoleKind2D.Pin);
            datumPin.FitTolerance = "H7";
            var secondPin = CreateHole(40.0, 10.0, 8.0, HoleKind2D.Pin);
            secondPin.FitTolerance = "H7";
            var holes = new List<HoleFeature2D>
            {
                datumPin,
                secondPin,
                CreateHole(25.0, 10.0, 14.0, HoleKind2D.Normal),
                CreateHole(25.0, 10.0, 9.0, HoleKind2D.Normal)
            };

            var plans = new HoleCalloutPlanner(config).CreatePlans(holes, secondPin);

            Assert(plans.Any(p => p.Kind == HoleCalloutKind.Pin && p.DebugOwner == "PG1" && p.Text == "2-%%c8H7"),
                "pin callout plan should include count and fit tolerance");
            Assert(plans.Any(p => p.Kind == HoleCalloutKind.Normal && p.DebugOwner == "PG1" && p.Text == "%%c14"),
                "counterbore outer diameter should stay as a separate normal callout");
            Assert(plans.Any(p => p.Kind == HoleCalloutKind.Normal && p.DebugOwner == "PG1" && p.Text == "%%c9"),
                "counterbore inner diameter should stay as a separate normal callout");
        }

        private static Point2D RotatePoint(Point2D point, double angle)
        {
            double cos = Math.Cos(angle);
            double sin = Math.Sin(angle);
            return new Point2D(point.X * cos - point.Y * sin, point.X * sin + point.Y * cos);
        }

        private static OutlineFeature2D RotateOutline(OutlineFeature2D outline, double angle)
        {
            var rotated = new OutlineFeature2D();
            foreach (Segment2D segment in outline.Segments)
            {
                Point2D start = RotatePoint(segment.Start, angle);
                Point2D end = RotatePoint(segment.End, angle);
                rotated.Segments.Add(new Segment2D(start, end));
                rotated.MinX = rotated.Segments.Count == 1 ? Math.Min(start.X, end.X) : Math.Min(rotated.MinX, Math.Min(start.X, end.X));
                rotated.MinY = rotated.Segments.Count == 1 ? Math.Min(start.Y, end.Y) : Math.Min(rotated.MinY, Math.Min(start.Y, end.Y));
                rotated.MaxX = rotated.Segments.Count == 1 ? Math.Max(start.X, end.X) : Math.Max(rotated.MaxX, Math.Max(start.X, end.X));
                rotated.MaxY = rotated.Segments.Count == 1 ? Math.Max(start.Y, end.Y) : Math.Max(rotated.MaxY, Math.Max(start.Y, end.Y));
            }
            return rotated;
        }

        private static OutlineFeature2D CreateRectangle(double width, double height)
        {
            return CreateRectangleAt(0.0, 0.0, width, height);
        }

        private static OutlineFeature2D CreateRectangleAt(double minX, double minY, double width, double height)
        {
            var outline = new OutlineFeature2D
            {
                MinX = minX,
                MinY = minY,
                MaxX = minX + width,
                MaxY = minY + height
            };

            AddSegment(outline, new Point2D(minX, minY), new Point2D(minX + width, minY), "bottom");
            AddSegment(outline, new Point2D(minX + width, minY), new Point2D(minX + width, minY + height), "right");
            AddSegment(outline, new Point2D(minX + width, minY + height), new Point2D(minX, minY + height), "top");
            AddSegment(outline, new Point2D(minX, minY + height), new Point2D(minX, minY), "left");
            return outline;
        }

		private static OutlineFeature2D CreateRightNotchOutline()
		{
			var outline = new OutlineFeature2D
			{
				MinX = 0.0,
				MinY = 0.0,
				MaxX = 200.0,
				MaxY = 100.0
			};
			var points = new[]
			{
				new Point2D(0.0, 0.0),
				new Point2D(200.0, 0.0),
				new Point2D(200.0, 20.0),
				new Point2D(60.0, 20.0),
				new Point2D(60.0, 80.0),
				new Point2D(200.0, 80.0),
				new Point2D(200.0, 100.0),
				new Point2D(0.0, 100.0),
				new Point2D(0.0, 0.0)
			};
			for (int i = 1; i < points.Length; i++)
			{
				AddSegment(outline, points[i - 1], points[i], "right-notch");
			}
			return outline;
		}

		private static OutlineFeature2D CreateTopLeftShoulderOutline()
		{
			var outline = new OutlineFeature2D
			{
				MinX = -33.0,
				MinY = 0.0,
				MaxX = 100.0,
				MaxY = 201.5
			};
			var points = new[]
			{
				new Point2D(0.0, 0.0),
				new Point2D(100.0, 0.0),
				new Point2D(100.0, 201.5),
				new Point2D(-33.0, 201.5),
				new Point2D(-33.0, 181.5),
				new Point2D(0.0, 181.5),
				new Point2D(0.0, 0.0)
			};
			for (int i = 1; i < points.Length; i++)
			{
				AddSegment(outline, points[i - 1], points[i], "top-left-shoulder");
			}
			return outline;
		}

        private static OutlineFeature2D CreateTopRightChamferedOutline()
        {
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(0.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 40.0), "right-local");
            AddSegment(outline, new Point2D(100.0, 40.0), new Point2D(90.0, 50.0), "chamfer");
            AddSegment(outline, new Point2D(90.0, 50.0), new Point2D(0.0, 50.0), "top-local");
            AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 0.0), "left");
            return outline;
        }

        private static OutlineFeature2D CreateBottomLeftChamferedOutline()
        {
            var outline = new OutlineFeature2D
            {
                MinX = 0.0,
                MinY = 0.0,
                MaxX = 100.0,
                MaxY = 50.0
            };

            AddSegment(outline, new Point2D(10.0, 0.0), new Point2D(100.0, 0.0), "bottom");
            AddSegment(outline, new Point2D(100.0, 0.0), new Point2D(100.0, 50.0), "right");
            AddSegment(outline, new Point2D(100.0, 50.0), new Point2D(0.0, 50.0), "top");
            AddSegment(outline, new Point2D(0.0, 50.0), new Point2D(0.0, 10.0), "left");
            AddSegment(outline, new Point2D(0.0, 10.0), new Point2D(10.0, 0.0), "chamfer");
            return outline;
        }

        private static void AddSegment(OutlineFeature2D outline, Point2D start, Point2D end, string sourceKey)
        {
            outline.Vertices.Add(start);
            outline.Segments.Add(new Segment2D(start, end) { SourceKey = sourceKey });
        }

        private static HoleFeature2D CreateHole(double x, double y, double diameter, HoleKind2D kind)
        {
            return new HoleFeature2D
            {
                Center = new Point2D(x, y),
                Diameter = diameter,
                Kind = kind
            };
        }

        private static PlannedDimension CreateTestDimension(
            DimensionKind kind,
            DimensionOrientation orientation,
            DimensionSide side,
            Point2D firstPoint,
            Point2D secondPoint,
            string debugRole)
        {
            return new PlannedDimension
            {
                Kind = kind,
                Orientation = orientation,
                Side = side,
                FirstPoint = firstPoint,
                SecondPoint = secondPoint,
                DebugRole = debugRole
            };
        }

        private static void ThreeViewFirstAngleKeepsLengthAndHeightOnFrontAndWidthOnTop()
        {
            var frames = new[]
            {
                ViewFrame("front", 0, 80, 100, 120, 2),
                ViewFrame("top", 0, 0, 100, 30, 0),
                ViewFrame("left", 130, 80, 160, 120, 0)
            };
            OrthographicViewSetAssignment assignment = OrthographicViewSetAssigner.Assign(frames, 0.5);
            Assert(assignment.LengthOwnerViewId == "front", "length stays on the front view");
            Assert(assignment.HeightOwnerViewId == "front", "height stays on the front view");
            Assert(assignment.WidthOwnerViewId == "top", "width stays on the top view");
            Assert(assignment.PinOwnerViewId == "front", "pin chain stays on the front view");
            AssertOwnership(assignment, "front", keepHorizontal: true, keepVertical: true, keepPins: true);
            AssertOwnership(assignment, "top", keepHorizontal: false, keepVertical: true, keepPins: false);
            AssertOwnership(assignment, "left", keepHorizontal: false, keepVertical: false, keepPins: false);

            var config = DimensionRuleConfig.CreateDefault();
            DimensionPlan frontPlan = PlanRectangle(config, 0, 80, 100, 120);
            DimensionPlan topPlan = PlanRectangle(config, 0, 0, 100, 30);
            DimensionPlan leftPlan = PlanRectangle(config, 130, 80, 160, 120);
            OrthographicViewSetAssigner.Apply(frontPlan, assignment.Find("front"));
            OrthographicViewSetAssigner.Apply(topPlan, assignment.Find("top"));
            OrthographicViewSetAssigner.Apply(leftPlan, assignment.Find("left"));
            AssertHasDimension(frontPlan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0, "front length");
            AssertHasDimension(frontPlan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 40.0, "front height");
            Assert(!HasDimension(topPlan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 100.0), "top view must not repeat the length");
            AssertHasDimension(topPlan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 30.0, "top width");
            Assert(!HasDimension(leftPlan, DimensionKind.OverallWidth, DimensionOrientation.Horizontal, 30.0), "left view must not repeat the width");
            Assert(!HasDimension(leftPlan, DimensionKind.OverallHeight, DimensionOrientation.Vertical, 40.0), "left view must not repeat the height");
        }

        private static void ThreeViewPinChainStaysOnTheViewThatShowsThePins()
        {
            var frames = new[]
            {
                ViewFrame("front", 0, 80, 100, 120, 0),
                ViewFrame("top", 0, 0, 100, 30, 0),
                ViewFrame("left", 130, 80, 160, 120, 2)
            };
            OrthographicViewSetAssignment assignment = OrthographicViewSetAssigner.Assign(frames, 0.5);
            Assert(assignment.PinOwnerViewId == "left", "pins visible only on the left view stay there");
            DimensionPlan frontPlan = new DimensionPlan();
            frontPlan.Add(new PlannedDimension
            {
                Kind = DimensionKind.PinDistance,
                Orientation = DimensionOrientation.Horizontal,
                Role = DimensionCandidateRole.Pin,
                FirstPoint = new Point2D(0, 0),
                SecondPoint = new Point2D(20, 0)
            });
            frontPlan.Add(new PlannedDimension
            {
                Kind = DimensionKind.HoleLocation,
                Orientation = DimensionOrientation.Horizontal,
                Role = DimensionCandidateRole.Hole,
                FirstPoint = new Point2D(0, 0),
                SecondPoint = new Point2D(15, 0)
            });
            frontPlan.CaptureFinalDimensions();
            int removed = OrthographicViewSetAssigner.Apply(frontPlan, assignment.Find("front"));
            Assert(removed == 1, "only the pin chain leaves the view that does not own the pins");
            Assert(frontPlan.Dimensions.Count == 1 && frontPlan.Dimensions[0].Kind == DimensionKind.HoleLocation, "hole location on that view remains");
        }

        private static void TwoViewTopAndLeftSplitLengthHeightAndWidth()
        {
            var frames = new[]
            {
                ViewFrame("lower", 0, 0, 100, 30, 0),
                ViewFrame("side", 130, 80, 160, 120, 0)
            };
            OrthographicViewSetAssignment assignment = OrthographicViewSetAssigner.Assign(frames, 0.5);
            ViewExtentOwnership top = assignment.Find("lower");
            ViewExtentOwnership left = assignment.Find("side");
            Assert(top.Role == OrthographicViewRole.Top, "the 100 by 30 view is the top view");
            Assert(left.Role == OrthographicViewRole.Left, "the 30 by 40 view is the left view");
            Assert(top.KeepHorizontalOverall && top.HorizontalExtent == PartExtentKind.Length, "length is kept on the top view");
            Assert(top.KeepVerticalOverall && top.VerticalExtent == PartExtentKind.Width, "width is kept on the top view");
            Assert(!left.KeepHorizontalOverall, "left view does not repeat the width");
            Assert(left.KeepVerticalOverall && left.VerticalExtent == PartExtentKind.Height, "height is kept on the left view");
        }

        private static void MismatchedViewEnvelopesDoNotAssign()
        {
            var frames = new[]
            {
                ViewFrame("a", 0, 0, 80, 40, 0),
                ViewFrame("b", 0, 60, 50, 90, 0),
                ViewFrame("c", 120, 0, 150, 20, 0)
            };
            bool rejected = false;
            try
            {
                OrthographicViewSetAssigner.Assign(frames, 0.5);
            }
            catch (InvalidOperationException)
            {
                rejected = true;
            }
            Assert(rejected, "unrelated envelopes must not be treated as one part");
        }

        private static OrthographicViewFrame ViewFrame(string id, double minX, double minY, double maxX, double maxY, int pinHoleCount)
        {
            return new OrthographicViewFrame
            {
                Id = id,
                MinX = minX,
                MinY = minY,
                MaxX = maxX,
                MaxY = maxY,
                PinHoleCount = pinHoleCount
            };
        }

        private static DimensionPlan PlanRectangle(DimensionRuleConfig config, double minX, double minY, double maxX, double maxY)
        {
            var outline = new FeatureRecognizer2D(config).RecognizeOutlineFromClosedPath(new[]
            {
                new Point2D(minX, minY),
                new Point2D(maxX, minY),
                new Point2D(maxX, maxY),
                new Point2D(minX, maxY)
            });
            return new DimensionPlanner(config).CreateOutlinePlan(outline);
        }

        private static void AssertOwnership(OrthographicViewSetAssignment assignment, string viewId, bool keepHorizontal, bool keepVertical, bool keepPins)
        {
            ViewExtentOwnership ownership = assignment.Find(viewId);
            Assert(ownership != null, "missing ownership for " + viewId);
            Assert(ownership.KeepHorizontalOverall == keepHorizontal, viewId + " horizontal overall ownership");
            Assert(ownership.KeepVerticalOverall == keepVertical, viewId + " vertical overall ownership");
            Assert(ownership.KeepPinDimensions == keepPins, viewId + " pin ownership");
        }

        private static bool HasDimension(DimensionPlan plan, DimensionKind kind, DimensionOrientation orientation, double expectedSpan)
        {
            return plan.Dimensions.Any(d =>
                d.Kind == kind
                && d.Orientation == orientation
                && Math.Abs(GetSpan(d) - expectedSpan) <= 0.001);
        }

        private static void AssertHasDimension(
            DimensionPlan plan,
            DimensionKind kind,
            DimensionOrientation orientation,
            double expectedSpan,
            string message)
        {
            var found = plan.Dimensions.Any(d =>
                d.Kind == kind
                && d.Orientation == orientation
                && Math.Abs(GetSpan(d) - expectedSpan) <= 0.001);

            Assert(found, "missing " + message);
        }

        private static double GetSpan(PlannedDimension dimension)
        {
            return dimension.Orientation == DimensionOrientation.Horizontal
                ? Math.Abs(dimension.SecondPoint.X - dimension.FirstPoint.X)
                : Math.Abs(dimension.SecondPoint.Y - dimension.FirstPoint.Y);
        }

        private static bool EndpointXEquals(PlannedDimension dimension, double x)
        {
            return Math.Abs(dimension.FirstPoint.X - x) <= 0.001
                || Math.Abs(dimension.SecondPoint.X - x) <= 0.001;
        }

        private static bool EndpointYEquals(PlannedDimension dimension, double y)
        {
            return Math.Abs(dimension.FirstPoint.Y - y) <= 0.001
                || Math.Abs(dimension.SecondPoint.Y - y) <= 0.001;
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition)
            {
                throw new InvalidOperationException(message);
            }
        }
    }
}

